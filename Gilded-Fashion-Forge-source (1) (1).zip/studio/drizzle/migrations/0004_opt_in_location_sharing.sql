CREATE TABLE public.location_shares (
  user_id uuid PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  consent_given_at timestamptz,
  revoked_at timestamptz,
  latitude numeric(6,2),
  longitude numeric(6,2),
  accuracy_m integer,
  captured_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT location_coords_need_consent CHECK (latitude IS NULL OR (consent_given_at IS NOT NULL AND revoked_at IS NULL)),
  CONSTRAINT location_lat_range CHECK (latitude IS NULL OR latitude BETWEEN -90 AND 90),
  CONSTRAINT location_lng_range CHECK (longitude IS NULL OR longitude BETWEEN -180 AND 180)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.location_shares TO authenticated;
GRANT ALL ON public.location_shares TO service_role;
ALTER TABLE public.location_shares ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.normalize_location_share()
RETURNS trigger LANGUAGE plpgsql SET search_path TO 'public' AS $$
BEGIN
  -- Minimise precision (~1 km) and clear coordinates when sharing is revoked.
  IF NEW.revoked_at IS NOT NULL THEN NEW.latitude := NULL; NEW.longitude := NULL; NEW.accuracy_m := NULL; NEW.captured_at := NULL; END IF;
  IF NEW.latitude IS NOT NULL THEN NEW.latitude := round(NEW.latitude, 2); NEW.longitude := round(NEW.longitude, 2); NEW.captured_at := now(); END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
REVOKE EXECUTE ON FUNCTION public.normalize_location_share() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER location_shares_normalize BEFORE INSERT OR UPDATE ON public.location_shares FOR EACH ROW EXECUTE FUNCTION public.normalize_location_share();

CREATE POLICY "Require active session" ON public.location_shares AS RESTRICTIVE FOR ALL TO authenticated USING (public.session_is_active()) WITH CHECK (public.session_is_active());
CREATE POLICY "Users read own location" ON public.location_shares FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users insert own location" ON public.location_shares FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own location" ON public.location_shares FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users delete own location" ON public.location_shares FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins read consenting locations" ON public.location_shares FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin') AND consent_given_at IS NOT NULL AND revoked_at IS NULL AND latitude IS NOT NULL);