-- Least-privilege grants: RLS already blocks writes, this removes them at grant level too.
REVOKE ALL ON public.profiles, public.user_roles, public.entitlements, public.credit_wallets, public.credit_ledger, public.payment_intents FROM anon;
REVOKE ALL ON public.profiles, public.user_roles, public.entitlements, public.credit_wallets, public.credit_ledger, public.payment_intents FROM authenticated;
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT ON public.user_roles, public.entitlements, public.credit_wallets, public.credit_ledger TO authenticated;
GRANT SELECT, INSERT ON public.payment_intents TO authenticated;
GRANT ALL ON public.profiles, public.user_roles, public.entitlements, public.credit_wallets, public.credit_ledger, public.payment_intents TO service_role;

-- Trigger function must not be callable by clients.
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;

-- Idempotency: unique provider reference; one grant per payment.
ALTER TABLE public.payment_intents ADD COLUMN IF NOT EXISTS reference text NOT NULL DEFAULT ('test_' || replace(gen_random_uuid()::text,'-',''));
ALTER TABLE public.payment_intents ADD CONSTRAINT payment_intents_reference_key UNIQUE (reference);
ALTER TABLE public.payment_intents ADD COLUMN IF NOT EXISTS verified_at timestamptz;
CREATE UNIQUE INDEX IF NOT EXISTS entitlements_source_payment_key ON public.entitlements(source_payment_id) WHERE source_payment_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS credit_ledger_source_payment_kind_key ON public.credit_ledger(source_payment_id, kind) WHERE source_payment_id IS NOT NULL;

-- Client-created intents must use an exact listed price and cannot set server fields.
CREATE OR REPLACE FUNCTION public.validate_payment_intent()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE expected integer;
BEGIN
  IF current_user = 'service_role' THEN RETURN NEW; END IF;
  expected := CASE NEW.plan_id
    WHEN 'pro-4d' THEN 10000 WHEN 'pro-8d' THEN 20000 WHEN 'pro-14d' THEN 30000 WHEN 'pro-monthly' THEN 60000
    WHEN 'video-5s' THEN 5000 WHEN 'video-10s' THEN 10000 WHEN 'video-15s' THEN 15000 WHEN 'video-20s' THEN 20000
    ELSE NULL END;
  IF expected IS NULL THEN RAISE EXCEPTION 'Unknown plan'; END IF;
  IF NEW.amount_ngn <> expected THEN RAISE EXCEPTION 'Amount does not match listed price'; END IF;
  NEW.status := 'pending';
  NEW.verified_at := NULL;
  NEW.reference := 'test_' || replace(gen_random_uuid()::text,'-','');
  RETURN NEW;
END $$;
REVOKE EXECUTE ON FUNCTION public.validate_payment_intent() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER payment_intents_validate BEFORE INSERT ON public.payment_intents
FOR EACH ROW EXECUTE FUNCTION public.validate_payment_intent();