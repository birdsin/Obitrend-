ALTER TABLE public.credit_wallets
  ADD COLUMN IF NOT EXISTS free_image_credits integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS free_period_resets_at timestamptz;

CREATE TABLE public.generation_charges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  tool_id text NOT NULL,
  source text NOT NULL,
  status text NOT NULL DEFAULT 'reserved',
  created_at timestamptz NOT NULL DEFAULT now(),
  settled_at timestamptz,
  CONSTRAINT generation_charges_source_chk CHECK (source IN ('free','plan')),
  CONSTRAINT generation_charges_status_chk CHECK (status IN ('reserved','completed','refunded'))
);
GRANT SELECT ON public.generation_charges TO authenticated;
GRANT ALL ON public.generation_charges TO service_role;
ALTER TABLE public.generation_charges ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Require active session" ON public.generation_charges AS RESTRICTIVE FOR ALL TO authenticated USING (public.session_is_active()) WITH CHECK (public.session_is_active());
CREATE POLICY "Users read own charges" ON public.generation_charges FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.user_is_pro(_user_id uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.entitlements WHERE user_id = _user_id AND starts_at <= now() AND expires_at > now())
$$;

-- Weekly free-credit refresh for the caller. Idempotent: grants only when the period has expired.
CREATE OR REPLACE FUNCTION public.refresh_free_credits()
RETURNS TABLE (free_image_credits integer, free_period_resets_at timestamptz, is_pro boolean)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE uid uuid := auth.uid(); pro boolean; w public.credit_wallets%ROWTYPE;
BEGIN
  IF uid IS NULL OR NOT public.session_is_active() THEN RAISE EXCEPTION 'not authenticated' USING ERRCODE = '42501'; END IF;
  INSERT INTO public.credit_wallets (user_id) VALUES (uid) ON CONFLICT (user_id) DO NOTHING;
  SELECT * INTO w FROM public.credit_wallets WHERE user_id = uid FOR UPDATE;
  pro := public.user_is_pro(uid);
  IF pro THEN
    IF w.free_image_credits <> 0 OR w.free_period_resets_at IS NOT NULL THEN
      UPDATE public.credit_wallets SET free_image_credits = 0, free_period_resets_at = NULL, updated_at = now() WHERE user_id = uid;
    END IF;
    RETURN QUERY SELECT 0, NULL::timestamptz, true; RETURN;
  END IF;
  IF w.free_period_resets_at IS NULL OR now() >= w.free_period_resets_at THEN
    UPDATE public.credit_wallets SET free_image_credits = 2, free_period_resets_at = now() + interval '7 days', updated_at = now()
      WHERE user_id = uid RETURNING * INTO w;
    INSERT INTO public.credit_ledger (user_id, kind, delta, reason) VALUES (uid, 'image_free', 2, 'free_weekly_reset');
  END IF;
  RETURN QUERY SELECT w.free_image_credits, w.free_period_resets_at, false;
END $$;

-- Reserve one image credit for an accepted job. Server-only (service_role). Non-Pro users have no
-- tool that may spend credits yet, so only Pro plan credits are reservable.
CREATE OR REPLACE FUNCTION public.reserve_generation_credit(_user_id uuid, _tool_id text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE cid uuid; n integer;
BEGIN
  IF NOT public.user_is_pro(_user_id) THEN RAISE EXCEPTION 'pro plan required' USING ERRCODE = '42501'; END IF;
  UPDATE public.credit_wallets SET image_credits = image_credits - 1, updated_at = now()
    WHERE user_id = _user_id AND image_credits > 0;
  GET DIAGNOSTICS n = ROW_COUNT;
  IF n = 0 THEN RAISE EXCEPTION 'no credits left' USING ERRCODE = 'P0001'; END IF;
  INSERT INTO public.generation_charges (user_id, tool_id, source) VALUES (_user_id, _tool_id, 'plan') RETURNING id INTO cid;
  INSERT INTO public.credit_ledger (user_id, kind, delta, reason) VALUES (_user_id, 'image', -1, 'generation_reserved:' || cid);
  RETURN cid;
END $$;

CREATE OR REPLACE FUNCTION public.complete_generation_charge(_charge_id uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE n integer;
BEGIN
  UPDATE public.generation_charges SET status = 'completed', settled_at = now() WHERE id = _charge_id AND status = 'reserved';
  GET DIAGNOSTICS n = ROW_COUNT; RETURN n = 1;
END $$;

-- Refund exactly once: only a still-reserved charge can be refunded.
CREATE OR REPLACE FUNCTION public.refund_generation_charge(_charge_id uuid)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE c public.generation_charges%ROWTYPE;
BEGIN
  UPDATE public.generation_charges SET status = 'refunded', settled_at = now()
    WHERE id = _charge_id AND status = 'reserved' RETURNING * INTO c;
  IF c.id IS NULL THEN RETURN false; END IF;
  IF c.source = 'free' THEN
    UPDATE public.credit_wallets SET free_image_credits = free_image_credits + 1, updated_at = now() WHERE user_id = c.user_id;
  ELSE
    UPDATE public.credit_wallets SET image_credits = image_credits + 1, updated_at = now() WHERE user_id = c.user_id;
  END IF;
  INSERT INTO public.credit_ledger (user_id, kind, delta, reason) VALUES (c.user_id, CASE WHEN c.source='free' THEN 'image_free' ELSE 'image' END, 1, 'generation_refund:' || c.id);
  RETURN true;
END $$;

REVOKE ALL ON FUNCTION public.user_is_pro(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.refresh_free_credits() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.refresh_free_credits() TO authenticated;
REVOKE ALL ON FUNCTION public.reserve_generation_credit(uuid, text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.complete_generation_charge(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.refund_generation_charge(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.user_is_pro(uuid), public.reserve_generation_credit(uuid, text), public.complete_generation_charge(uuid), public.refund_generation_charge(uuid) TO service_role;