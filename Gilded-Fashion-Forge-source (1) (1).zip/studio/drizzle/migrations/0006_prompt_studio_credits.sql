ALTER TABLE public.generation_charges ADD COLUMN IF NOT EXISTS request_id uuid;
CREATE UNIQUE INDEX IF NOT EXISTS generation_charges_user_request_uidx ON public.generation_charges (user_id, request_id) WHERE request_id IS NOT NULL;

-- Idempotent credit reservation for one generation request. Free accounts spend their
-- weekly free credits (renewed only after 7 days); Pro accounts spend plan credits only.
CREATE OR REPLACE FUNCTION public.reserve_request_credit(_user_id uuid, _tool_id text, _request_id uuid)
RETURNS TABLE(charge_id uuid, charge_status text, charge_source text, duplicate boolean)
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE existing public.generation_charges%ROWTYPE; pro boolean; w public.credit_wallets%ROWTYPE; cid uuid; src text;
BEGIN
  INSERT INTO public.credit_wallets (user_id) VALUES (_user_id) ON CONFLICT (user_id) DO NOTHING;
  SELECT * INTO w FROM public.credit_wallets WHERE user_id = _user_id FOR UPDATE;
  SELECT * INTO existing FROM public.generation_charges WHERE user_id = _user_id AND request_id = _request_id;
  IF existing.id IS NOT NULL THEN
    RETURN QUERY SELECT existing.id, existing.status, existing.source, true; RETURN;
  END IF;
  pro := public.user_is_pro(_user_id);
  IF pro THEN
    IF w.image_credits <= 0 THEN RAISE EXCEPTION 'no credits left' USING ERRCODE = 'P0001'; END IF;
    UPDATE public.credit_wallets SET image_credits = image_credits - 1, updated_at = now() WHERE user_id = _user_id;
    src := 'plan';
  ELSE
    IF w.free_period_resets_at IS NULL OR now() >= w.free_period_resets_at THEN
      UPDATE public.credit_wallets SET free_image_credits = 2, free_period_resets_at = now() + interval '7 days', updated_at = now()
        WHERE user_id = _user_id RETURNING * INTO w;
      INSERT INTO public.credit_ledger (user_id, kind, delta, reason) VALUES (_user_id, 'image_free', 2, 'free_weekly_reset');
    END IF;
    IF w.free_image_credits <= 0 THEN RAISE EXCEPTION 'no credits left' USING ERRCODE = 'P0001'; END IF;
    UPDATE public.credit_wallets SET free_image_credits = free_image_credits - 1, updated_at = now() WHERE user_id = _user_id;
    src := 'free';
  END IF;
  INSERT INTO public.generation_charges (user_id, tool_id, source, request_id) VALUES (_user_id, _tool_id, src, _request_id) RETURNING id INTO cid;
  INSERT INTO public.credit_ledger (user_id, kind, delta, reason) VALUES (_user_id, CASE WHEN src='free' THEN 'image_free' ELSE 'image' END, -1, 'generation_reserved:' || cid);
  RETURN QUERY SELECT cid, 'reserved'::text, src, false;
END $$;
REVOKE ALL ON FUNCTION public.reserve_request_credit(uuid, text, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.reserve_request_credit(uuid, text, uuid) TO service_role;