CREATE UNIQUE INDEX IF NOT EXISTS entitlements_source_payment_unique ON public.entitlements(source_payment_id) WHERE source_payment_id IS NOT NULL;

-- Settles a payment ONLY from server-verified Paystack data. Idempotent: a paid intent is never granted twice.
CREATE OR REPLACE FUNCTION public.settle_paystack_payment(_reference text, _paystack_status text, _amount_kobo bigint, _currency text, _days integer, _credits integer)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE pi public.payment_intents%ROWTYPE; start_at timestamptz;
BEGIN
  SELECT * INTO pi FROM public.payment_intents WHERE reference = _reference FOR UPDATE;
  IF NOT FOUND THEN RETURN 'unknown_reference'; END IF;
  IF pi.status = 'paid' THEN RETURN 'already_paid'; END IF;
  IF _paystack_status <> 'success' THEN
    IF _paystack_status IN ('failed','abandoned','reversed') AND pi.status = 'pending' THEN
      UPDATE public.payment_intents SET status = CASE WHEN _paystack_status='abandoned' THEN 'cancelled' ELSE 'failed' END WHERE id = pi.id;
      RETURN 'marked_failed';
    END IF;
    RETURN 'pending';
  END IF;
  IF upper(_currency) <> 'NGN' OR _amount_kobo <> pi.amount_ngn::bigint * 100 THEN RETURN 'amount_mismatch'; END IF;
  IF pi.plan_id NOT LIKE 'pro-%' OR _days <= 0 OR _credits < 0 THEN RETURN 'unsupported_plan'; END IF;
  SELECT GREATEST(now(), COALESCE(MAX(expires_at), now())) INTO start_at FROM public.entitlements WHERE user_id = pi.user_id AND expires_at > now();
  UPDATE public.payment_intents SET status = 'paid', verified_at = now() WHERE id = pi.id;
  INSERT INTO public.entitlements(user_id, plan_id, source_payment_id, starts_at, expires_at)
    VALUES (pi.user_id, pi.plan_id, pi.id, start_at, start_at + make_interval(days => _days));
  IF _credits > 0 THEN
    INSERT INTO public.credit_wallets(user_id) VALUES (pi.user_id) ON CONFLICT (user_id) DO NOTHING;
    UPDATE public.credit_wallets SET image_credits = image_credits + _credits, free_image_credits = 0, updated_at = now() WHERE user_id = pi.user_id;
    INSERT INTO public.credit_ledger(user_id, kind, delta, reason, source_payment_id) VALUES (pi.user_id, 'image', _credits, 'pro_purchase', pi.id);
  END IF;
  RETURN 'activated';
END $$;
REVOKE ALL ON FUNCTION public.settle_paystack_payment(text,text,bigint,text,integer,integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.settle_paystack_payment(text,text,bigint,text,integer,integer) TO service_role;