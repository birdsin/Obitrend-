ALTER TABLE public.credit_ledger DROP CONSTRAINT credit_ledger_kind_check;
ALTER TABLE public.credit_ledger ADD CONSTRAINT credit_ledger_kind_check CHECK (kind IN ('image','video','image_free'));