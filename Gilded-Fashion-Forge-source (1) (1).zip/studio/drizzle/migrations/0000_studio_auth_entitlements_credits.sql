create type public.app_role as enum ('admin', 'user');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "Users read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "Users insert own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "Users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "Users read own roles" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = _user_id and role = _role
  )
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1)));
  insert into public.credit_wallets (user_id) values (new.id);
  return new;
end;
$$;

create table public.entitlements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  plan_id text not null,
  source_payment_id uuid,
  starts_at timestamptz not null default now(),
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
grant select on public.entitlements to authenticated;
grant all on public.entitlements to service_role;
alter table public.entitlements enable row level security;
create policy "Users read own entitlements" on public.entitlements for select to authenticated using (auth.uid() = user_id);

create table public.credit_wallets (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  image_credits int not null default 0 check (image_credits >= 0),
  video_credits int not null default 0 check (video_credits >= 0),
  updated_at timestamptz not null default now()
);
grant select on public.credit_wallets to authenticated;
grant all on public.credit_wallets to service_role;
alter table public.credit_wallets enable row level security;
create policy "Users read own wallet" on public.credit_wallets for select to authenticated using (auth.uid() = user_id);

create table public.credit_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  kind text not null check (kind in ('image', 'video')),
  delta int not null check (delta <> 0),
  reason text not null,
  source_payment_id uuid,
  created_at timestamptz not null default now()
);
grant select on public.credit_ledger to authenticated;
grant all on public.credit_ledger to service_role;
alter table public.credit_ledger enable row level security;
create policy "Users read own ledger" on public.credit_ledger for select to authenticated using (auth.uid() = user_id);

create table public.payment_intents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  plan_id text not null,
  amount_ngn int not null check (amount_ngn > 0),
  status text not null default 'pending' check (status in ('pending', 'paid', 'failed', 'cancelled')),
  created_at timestamptz not null default now()
);
grant select, insert on public.payment_intents to authenticated;
grant all on public.payment_intents to service_role;
alter table public.payment_intents enable row level security;
create policy "Users read own intents" on public.payment_intents for select to authenticated using (auth.uid() = user_id);
create policy "Users create own pending intents" on public.payment_intents for insert to authenticated with check (auth.uid() = user_id and status = 'pending');

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();