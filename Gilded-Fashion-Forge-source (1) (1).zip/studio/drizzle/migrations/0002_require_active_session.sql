-- A signed-in token is only honoured while its auth session still exists.
-- Sign-out deletes the session row, so copied tokens stop working immediately.
CREATE OR REPLACE FUNCTION public.session_is_active()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
  SELECT CASE
    WHEN (auth.jwt() ->> 'session_id') IS NULL THEN auth.role() = 'authenticated'
    ELSE EXISTS (
      SELECT 1 FROM auth.sessions s
      WHERE s.id = (auth.jwt() ->> 'session_id')::uuid
        AND s.user_id = auth.uid()
        AND (s.not_after IS NULL OR s.not_after > now())
    )
  END
$$;
REVOKE EXECUTE ON FUNCTION public.session_is_active() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.session_is_active() TO authenticated;

CREATE POLICY "Require active session" ON public.profiles AS RESTRICTIVE FOR ALL TO authenticated USING (public.session_is_active()) WITH CHECK (public.session_is_active());
CREATE POLICY "Require active session" ON public.user_roles AS RESTRICTIVE FOR ALL TO authenticated USING (public.session_is_active()) WITH CHECK (public.session_is_active());
CREATE POLICY "Require active session" ON public.entitlements AS RESTRICTIVE FOR ALL TO authenticated USING (public.session_is_active()) WITH CHECK (public.session_is_active());
CREATE POLICY "Require active session" ON public.credit_wallets AS RESTRICTIVE FOR ALL TO authenticated USING (public.session_is_active()) WITH CHECK (public.session_is_active());
CREATE POLICY "Require active session" ON public.credit_ledger AS RESTRICTIVE FOR ALL TO authenticated USING (public.session_is_active()) WITH CHECK (public.session_is_active());
CREATE POLICY "Require active session" ON public.payment_intents AS RESTRICTIVE FOR ALL TO authenticated USING (public.session_is_active()) WITH CHECK (public.session_is_active());