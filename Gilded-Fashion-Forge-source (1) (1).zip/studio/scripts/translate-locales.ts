// Drafts missing translations for every non-English locale with the Lovable AI Gateway.
// Only fills keys that are missing or whose {placeholders} no longer match English; never
// overwrites existing (e.g. hand-written Igbo/Chinese) strings. Usage: bun scripts/translate-locales.ts [lang...]
import { readFileSync, writeFileSync } from 'node:fs';
import { en } from '../src/lib/locales/en';
import { languages } from '../src/lib/i18n';

const key = process.env['LOVABLE_API_KEY'];
if (!key) throw new Error('LOVABLE_API_KEY missing');
const ph = (s: string) => (s.match(/\{\w+\}/g) ?? []).sort().join(',');
const only = process.argv.slice(2);
const BATCH = 120;

const schema = { type: 'object', additionalProperties: false, required: ['items'], properties: { items: { type: 'array', items: { type: 'object', additionalProperties: false, required: ['key', 'text'], properties: { key: { type: 'string' }, text: { type: 'string' } } } } } };

async function draft(langName: string, entries: [string, string][]): Promise<Record<string, string>> {
  const body = {
    model: 'openai/gpt-6-astra', stream: true, store: false, reasoning: { effort: 'low' },
    text: { format: { type: 'json_schema', name: 'translations', strict: true, schema } },
    input: [
      { role: 'system', content: `You translate UI strings for a luxury fashion design studio web app into ${langName}. Return JSON {items:[{key,text}]} with one item per given key. Rules: natural, concise UI wording for native speakers; keep {placeholders} exactly; keep brand names OBITREND, OBITREND AI, Pro, WAT, Naira/₦ amounts, numbers, emoji and symbols unchanged; keep the meaning of "Demo mode" (no real AI generation happened).` },
      { role: 'user', content: JSON.stringify(Object.fromEntries(entries)) },
    ],
  };
  for (let attempt = 1; attempt <= 3; attempt++) {
    const r = await fetch('https://ai.gateway.lovable.dev/v1/responses', { method: 'POST', headers: { 'Lovable-API-Key': key!, Authorization: `Bearer ${key}`, 'X-Lovable-AIG-SDK': 'fetch', 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (r.ok && r.body) {
      let text = '', buf = '';
      const reader = r.body.getReader(); const dec = new TextDecoder();
      for (;;) { const { done, value } = await reader.read(); if (done) break; buf += dec.decode(value, { stream: true });
        let i; while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
          if (!line.startsWith('data:')) continue; const d = line.slice(5).trim(); if (d === '[DONE]') continue;
          try { const ev = JSON.parse(d); if (ev.type === 'response.output_text.delta') text += ev.delta; } catch { /* partial */ } } }
      try { const j = JSON.parse(text) as { items: { key: string; text: string }[] }; return Object.fromEntries(j.items.map(x => [x.key, x.text])); } catch { console.warn('  bad JSON'); }
    } else console.warn(`  attempt ${attempt} failed: ${r.status} ${await r.text().catch(() => '')}`.slice(0, 300));
    await new Promise(res => setTimeout(res, 2000 * attempt));
  }
  throw new Error('gateway failed');
}

for (const l of languages) {
  if (l.code === 'en' || (only.length && !only.includes(l.code))) continue;
  const file = `src/lib/locales/${l.code}.json`;
  const cur: Record<string, string> = JSON.parse(readFileSync(file, 'utf8'));
  for (const k of Object.keys(cur)) if (!(k in en)) delete cur[k];
  const todo = (Object.entries(en) as [string, string][]).filter(([k, v]) => !cur[k] || ph(cur[k]!) !== ph(v));
  console.log(`${l.code}: ${todo.length} to draft`);
  const batches: [string, string][][] = []; for (let i = 0; i < todo.length; i += BATCH) batches.push(todo.slice(i, i + BATCH));
  const results = await Promise.all(batches.map(b => draft(`${l.english} (${l.label})`, b)));
  for (const res of results) for (const [k, v] of Object.entries(res)) if (k in en && typeof v === 'string' && v.trim() && ph(v) === ph(en[k as keyof typeof en])) cur[k] = v;
  const sorted = Object.fromEntries(Object.keys(en).filter(k => cur[k]).map(k => [k, cur[k]]));
  writeFileSync(file, JSON.stringify(sorted, null, 1) + '\n');
  console.log(`${l.code}: ${Object.keys(sorted).length}/${Object.keys(en).length}`);
}
