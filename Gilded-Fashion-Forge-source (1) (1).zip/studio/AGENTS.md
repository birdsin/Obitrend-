<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Studio architecture
- Keep all demo state in the shared React session provider; only demo jobs persist, locally on the device, with no external services, so production remains isolated.
- Define all twenty tools in the shared typed registry and render them through the `/tools/$toolId` route with a reusable workspace, so controls and validation stay consistent.
- Resolve visible option defaults in the shared request builder and keep camera option values untranslated, so submitted demo briefs match the displayed controls in every language.
- Demo generation selects bundled inspiration samples only and exports clearly labelled briefs; it must not imply model inference or image editing.
- Keep metallic finishes in CSS tokens and the shared Button; settings stay single-column for consistent behavior.
- Mobile navigation uses a modal Radix dialog and shared desktop menu content to contain focus and scrolling.
- Show shared camera ratio before Generate, not twice in fine-tuning, to keep controls consistent with requests.
- Keep plans/prices/profiles in `plans.ts` and camera glyphs in presentation-only `camera-icons.tsx`; only server-verified entitlements unlock features, never icon cards or client flags.
- Pro purchases go through Paystack (test-mode keys only, enforced in `src/lib/paystack.ts`): checkout and redirects grant nothing; every grant re-verifies the transaction with Paystack and settles via the service-role `settle_paystack_payment` function, which checks amount/currency and is idempotent per reference.
- UI strings use keys from `src/lib/locales/en/*.ts` (English source) with per-language JSON in `src/lib/locales/`, read via `useLang()`; `src/test/i18n.test.ts` fails on missing keys, placeholder drift or hard-coded JSX English, and `scripts/translate-locales.ts` drafts only missing keys, so hand-written strings are never overwritten.
- Interface language never changes stored data: option values, validation messages and requests stay English internally and are translated only at render, and dates always use `formatLagos(iso, locale)`, so language cannot alter behaviour or times.
- Transient interface notices retain translation keys until rendering, and language menus use a collision-aware portalled popover, so language changes update visible feedback and narrow viewports cannot clip the selector.
- Ad placements are configured in `src/lib/ad-slots.ts` and render nothing while disabled, so no ad code runs without explicit configuration.
- Tool thumbnails are presentation-only, separate from demo outputs to avoid implying inference.

- Centralize illustrative samples in the browser-safe visual registry, distinct from uploads and model inference.
- Render the welcome campaign in an accessible dismissible first-entry dialog with a versioned session marker and static reduced-motion state, so it never stacks above dashboard content or repeats on navigation.
- Use the shared StudioImage for editorial presentation with fixed aspect ratios and accessible failure states, so image loading cannot shift the layout or leave blank controls.
- Accounts, entitlements and credits live in Lovable Cloud (profiles, user_roles, entitlements, credit_wallets, credit_ledger, payment_intents); clients may only read their own rows and create pending payment intents — all grants and status changes are server-side only, so the UI can never unlock plans or add credits by itself.
- Every account table carries a restrictive RLS policy requiring public.session_is_active(), so signed-out (revoked) session tokens cannot read or write account data even before they expire.
- Generation runs as durable jobs (`src/lib/demo-jobs.ts`) persisted on the device and owned by the shared studio provider, never by tool components, so navigation/reload restores jobs and a future server runner can replace `JobRunner` without UX changes.
- Auth state comes from one shared subscription in `src/lib/use-auth.ts` and auth forms stay disabled until hydration, so focus/refocus events or slow mobile loads cannot remount forms or trigger native page-reloading submits.
- Image tools build their payload through the shared typed request builder in `src/lib/generation-request.ts` (garment fidelity first, camera as structured data + prompt text), and submission goes through a nullable provider adapter, so a real service can be plugged in without touching tool components or faking results.
- Location sharing lives in `location_shares` (one row per user, ~1 km precision, cleared on revoke by a trigger); only the owner reads/writes it and admins (via `has_role`, never a client flag) read active-consent rows, so no user can see another's location.
- Account dates/times render through `src/lib/lagos-time.ts` (Africa/Lagos, labelled WAT); balances always come from `getAccountState`, with only countdowns computed on the client.
- Charged generations go through `src/lib/prompt-charge.ts` + the service-role `reserve_request_credit` function keyed by a client request id, so retries never double-charge and failures refund exactly once via `refund_generation_charge`.
