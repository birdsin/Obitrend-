import { describe, expect, it } from 'vitest';
import { shouldShowWelcome } from '@/lib/welcome-session';

describe('Optional workflow welcome', () => {
  it('is eligible only before being seen in the session', () => {
    expect(shouldShowWelcome(null, false)).toBe(true);
    expect(shouldShowWelcome('1', false)).toBe(false);
  });
  it('allows a static first entry when reduced motion is requested', () => {
    expect(shouldShowWelcome(null, true)).toBe(true);
    expect(shouldShowWelcome('1', true)).toBe(false);
  });
});