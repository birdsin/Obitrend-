import { describe, expect, it } from 'vitest';
import { countdown, formatLagos, spendableCredits } from '@/lib/lagos-time';
import { canViewLocation, mayCaptureLocation, minimizeCoord, revoke } from '@/lib/location-policy';
import { refreshFreeWallet, FREE_PERIOD_MS } from '@/lib/credit-policy';

describe('credit panel values', () => {
  it('shows times in Lagos (UTC+1) with WAT label', () => {
    expect(formatLagos('2026-10-12T23:30:00Z')).toBe('13 Oct 2026, 00:30 WAT');
  });
  it('never shows a date when no valid expiry exists', () => {
    expect(formatLagos(null)).toBeNull();
    expect(formatLagos('not-a-date')).toBeNull();
    expect(countdown(null, Date.now())).toBeNull();
  });
  it('counts down to the server reset time', () => {
    const now = Date.UTC(2026, 9, 12);
    expect(countdown(new Date(now + 2 * 86400000 + 3 * 3600000 + 5 * 60000).toISOString(), now)).toBe('2d 3h 5m');
  });
  it('free users spend only free credits; Pro only plan credits', () => {
    expect(spendableCredits({ isPro: false, imageCredits: 50, freeImageCredits: 2 })).toBe(2);
    expect(spendableCredits({ isPro: true, imageCredits: 50, freeImageCredits: 2 })).toBe(50);
  });
  it('weekly reset gives 2 only after expiry, and Pro gets none', () => {
    const t = Date.UTC(2026, 9, 1);
    expect(refreshFreeWallet({ freeCredits: 0, resetsAt: t + FREE_PERIOD_MS }, false, t + 1).freeCredits).toBe(0);
    expect(refreshFreeWallet({ freeCredits: 0, resetsAt: t }, false, t).freeCredits).toBe(2);
    expect(refreshFreeWallet({ freeCredits: 0, resetsAt: null }, true, t).freeCredits).toBe(0);
  });
});

describe('location consent', () => {
  const on = { consentGivenAt: '2026-10-12T10:00:00Z', revokedAt: null, latitude: 6.45, longitude: 3.39 };
  it('no capture without consent', () => {
    expect(mayCaptureLocation(null)).toBe(false);
    expect(mayCaptureLocation({ ...on, consentGivenAt: null })).toBe(false);
    expect(mayCaptureLocation(on)).toBe(true);
  });
  it('revoking removes coordinates and blocks capture', () => {
    const r = revoke(on, '2026-10-12T11:00:00Z');
    expect(r.latitude).toBeNull();
    expect(mayCaptureLocation(r)).toBe(false);
  });
  it('precision is rounded to about 1 km', () => {
    expect(minimizeCoord(6.524379)).toBe(6.52);
  });
  it('other users can never view; admins only with active consent', () => {
    expect(canViewLocation('u2', 'u1', false, on)).toBe(false);
    expect(canViewLocation('u1', 'u1', false, on)).toBe(true);
    expect(canViewLocation('admin', 'u1', true, on)).toBe(true);
    expect(canViewLocation('admin', 'u1', true, revoke(on, 'x'))).toBe(false);
  });
});
