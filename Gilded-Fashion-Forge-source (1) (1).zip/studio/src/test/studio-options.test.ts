import { describe, expect, it } from 'vitest';
import { tools } from '@/lib/studio-tools';
import { applyPreset, buildPrompt, defaultCamera, emptyPrompt, toolFields } from '@/lib/studio-options';
import { adSlots } from '@/lib/ad-slots';

describe('Master dashboard rules', () => {
  it('keeps the 20 tool names in their original order', () => {
    expect(tools[0]?.id).toBe('fashion-image');
    expect(tools[19]?.id).toBe('collection-planner');
  });
  it('gives each tool its own field config', () => {
    expect(toolFields('colour-variations')).toContain('colour');
    expect(toolFields('virtual-try-on')).toContain('camera');
    expect(toolFields('image-enhancer')).toEqual([]);
  });
  it('leads every prompt with garment fidelity', () => {
    expect(buildPrompt(emptyPrompt).startsWith('Reproduce the uploaded garment exactly')).toBe(true);
  });
  it('adds head-to-feet wording for full-body framing', () => {
    expect(buildPrompt({ ...emptyPrompt, composition: 'Full body' })).toContain('head to feet');
  });
  it('applies camera presets', () => {
    expect(applyPreset(defaultCamera, 'Portrait').aperture).toBe('f/1.8');
  });
  it('keeps every advertising slot disabled by default', () => {
    expect(Object.values(adSlots).every(s => !s.enabled)).toBe(true);
  });
});
import { imagePlans, videoOptions, cameraProfiles, canUseCamera, paymentsConnected } from '@/lib/plans';
describe('Exact prices and gating', () => {
  it('keeps image plan prices, credits and days', () => {
    expect(imagePlans.map(p => [p.name, p.priceNgn, p.imageCredits, p.days])).toEqual([['4 Day Pro',10000,5,4],['8 Day Pro',20000,10,8],['14 Day Pro',30000,15,14],['Monthly Full Pro',60000,30,30]]);
  });
  it('keeps video prices at 1 credit each', () => {
    expect(videoOptions.map(v => [v.seconds, v.priceNgn, v.videoCredits])).toEqual([[5,5000,1],[10,10000,1],[15,15000,1],[20,20000,1]]);
  });
  it('locks every camera without a verified entitlement', () => {
    for (const c of cameraProfiles) expect(canUseCamera(null, c)).toBe(false);
    expect(paymentsConnected).toBe(false);
  });
  it('locks cameras when the plan has expired', () => {
    const c = cameraProfiles[0]!;
    expect(canUseCamera({ verified: true, planId: 'pro-monthly', imageCreditsLeft: 5, videoCreditsLeft: 0, expiresAt: '2000-01-01' }, c)).toBe(false);
  });
});
