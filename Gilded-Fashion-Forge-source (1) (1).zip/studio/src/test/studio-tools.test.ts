import { describe, expect, it } from 'vitest';
import { tools, validateDemoInput, validateUpload } from '@/lib/studio-tools';

describe('Independent demo studio rules', () => {
  it('provides exactly 20 unique workspaces', () => {
    expect(tools).toHaveLength(20);
    expect(new Set(tools.map(tool => tool.id)).size).toBe(20);
  });
  it('requires a brief for every Generate action', () => {
    for (const tool of tools) expect(validateDemoInput(tool, '   ', true)).not.toBeNull();
  });
  it('requires reference images for garment editing workspaces', () => {
    const tool = tools.find(item => item.id === 'colour-variations');
    if (!tool) throw new Error('Colour variations workspace missing');
    expect(validateDemoInput(tool, 'Emerald colourway', false)).toBe('Upload a reference image for this tool.');
    expect(validateDemoInput(tool, 'Emerald colourway', true)).toBeNull();
  });
  it('accepts valid input across all twenty tools', () => {
    for (const tool of tools) expect(validateDemoInput(tool, 'A modern fashion brief', true)).toBeNull();
  });
  it('rejects unsafe uploads and images exceeding the 10 MB demo limit', () => {
    expect(validateUpload({type:'text/html',size:1})).not.toBeNull();
    expect(validateUpload({type:'image/jpeg',size:10*1024*1024+1})).not.toBeNull();
    expect(validateUpload({type:'image/png',size:1024})).toBeNull();
  });
});