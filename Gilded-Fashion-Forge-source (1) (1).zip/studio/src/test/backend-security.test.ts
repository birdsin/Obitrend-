/**
 * Live regression tests against the TEST backend. They run only when a test
 * session file exists (minted with `lovable auth-session --json`); otherwise
 * they are skipped. Every write attempt here is expected to be refused, so the
 * suite creates no data except rejected requests.
 */
import { existsSync, readFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { describe, expect, it } from 'vitest';

const sessionPath = `${homedir()}/.cache/lovable-auth/session.json`;
const envPath = `${process.cwd()}/.env`;
const ready = existsSync(sessionPath) && existsSync(envPath);
const env = ready ? readFileSync(envPath, 'utf8') : '';
const read = (k: string) => env.match(new RegExp(`^${k}="?([^"\\n]+)"?`, 'm'))?.[1] ?? '';
const url = read('VITE_SUPABASE_URL');
const key = read('VITE_SUPABASE_PUBLISHABLE_KEY');
const session = ready ? JSON.parse(readFileSync(sessionPath, 'utf8')).session : null;
const uid: string = session?.user?.id ?? '';
const other = '00000000-0000-0000-0000-000000000001';

const auth = { apikey: key, Authorization: `Bearer ${session?.access_token}`, 'Content-Type': 'application/json', Prefer: 'return=representation' };
const anon = { apikey: key, 'Content-Type': 'application/json' };
const rest = (path: string, init: RequestInit & { headers?: Record<string, string> } = {}) =>
  fetch(`${url}/rest/v1/${path}`, { ...init, headers: init.headers ?? auth });

describe.skipIf(!ready || !url || !key)('Backend security (live test environment)', () => {
  it('reads only the signed-in user\'s profile', async () => {
    const rows = await (await rest('profiles?select=id')).json();
    expect(rows.map((r: { id: string }) => r.id)).toEqual([uid]);
  });
  it('reads only own wallet, entitlements, ledger, roles and intents', async () => {
    for (const t of ['credit_wallets', 'entitlements', 'credit_ledger', 'user_roles', 'payment_intents']) {
      const rows = await (await rest(`${t}?select=user_id`)).json();
      expect(rows.every((r: { user_id: string }) => r.user_id === uid)).toBe(true);
    }
  });
  it('denies unauthenticated reads of every account table', async () => {
    for (const t of ['profiles', 'credit_wallets', 'entitlements', 'credit_ledger', 'user_roles', 'payment_intents']) {
      const res = await rest(`${t}?select=*`, { headers: anon });
      expect(res.ok).toBe(false);
    }
  });
  it('refuses raising credits', async () => {
    expect((await rest(`credit_wallets?user_id=eq.${uid}`, { method: 'PATCH', body: JSON.stringify({ image_credits: 99, video_credits: 99 }) })).ok).toBe(false);
  });
  it('refuses self-granted plans', async () => {
    expect((await rest('entitlements', { method: 'POST', body: JSON.stringify({ user_id: uid, plan_id: 'pro-monthly', expires_at: '2030-01-01' }) })).ok).toBe(false);
  });
  it('refuses writing credit history', async () => {
    expect((await rest('credit_ledger', { method: 'POST', body: JSON.stringify({ user_id: uid, kind: 'image', delta: 30, reason: 'x' }) })).ok).toBe(false);
  });
  it('refuses self-granted admin', async () => {
    expect((await rest('user_roles', { method: 'POST', body: JSON.stringify({ user_id: uid, role: 'admin' }) })).ok).toBe(false);
  });
  it('refuses marking payment requests paid', async () => {
    expect((await rest(`payment_intents?user_id=eq.${uid}`, { method: 'PATCH', body: JSON.stringify({ status: 'paid' }) })).ok).toBe(false);
  });
  it('rejects payment requests that do not match the server price', async () => {
    const res = await rest('payment_intents', { method: 'POST', body: JSON.stringify({ user_id: uid, plan_id: 'pro-monthly', amount_ngn: 1 }) });
    expect(res.status).toBe(400);
  });
  it('rejects payment requests for unknown plans', async () => {
    const res = await rest('payment_intents', { method: 'POST', body: JSON.stringify({ user_id: uid, plan_id: 'free-forever', amount_ngn: 60000 }) });
    expect(res.ok).toBe(false);
  });
  it('rejects payment requests for another user', async () => {
    const res = await rest('payment_intents', { method: 'POST', body: JSON.stringify({ user_id: other, plan_id: 'pro-4d', amount_ngn: 10000 }) });
    expect(res.ok).toBe(false);
  });
  it('every existing payment request is still unpaid and unverified', async () => {
    const rows = await (await rest('payment_intents?select=status,verified_at')).json();
    expect(rows.every((r: { status: string; verified_at: string | null }) => r.status === 'pending' && r.verified_at === null)).toBe(true);
  });
  it('account still has zero credits and no plan', async () => {
    const [w] = await (await rest('credit_wallets?select=image_credits,video_credits')).json();
    expect(w).toEqual({ image_credits: 0, video_credits: 0 });
    expect(await (await rest('entitlements?select=id')).json()).toEqual([]);
  });
  it('rejects forged or tampered session tokens', async () => {
    const forged = { apikey: key, Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ4In0.forged' };
    expect((await fetch(`${url}/auth/v1/user`, { headers: forged })).ok).toBe(false);
    const tampered = String(session.access_token).slice(0, -4) + 'abcd';
    expect((await fetch(`${url}/rest/v1/credit_wallets?select=*`, { headers: { apikey: key, Authorization: `Bearer ${tampered}` } })).ok).toBe(false);
  });
  it('rejects sign-in for unknown accounts without revealing existence', async () => {
    const res = await fetch(`${url}/auth/v1/token?grant_type=password`, { method: 'POST', headers: anon, body: JSON.stringify({ email: 'nobody-x@obitrend-test.dev', password: 'Whatever-123' }) });
    expect(res.status).toBe(400);
    expect((await res.json()).error_code).toBe('invalid_credentials');
  });
});
