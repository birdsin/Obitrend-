import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { dictionaries, languages, matchBrowserLang, translate } from '@/lib/i18n';
import { en } from '@/lib/locales/en';
import { tools as toolKeys } from '@/lib/locales/en/tools';
import { tools } from '@/lib/studio-tools';
import { countdown, formatLagos } from '@/lib/lagos-time';
import legacyIg from './fixtures/legacy-ig.json';
import legacyZh from './fixtures/legacy-zh.json';

const keys = Object.keys(en);
const ph = (s: string) => (s.match(/\{\w+\}/g) ?? []).sort().join(',');

describe('Languages', () => {
  it('offers exactly the 12 requested languages', () => {
    expect(languages.map(l => l.code).sort()).toEqual(['ar', 'en', 'es', 'fr', 'ha', 'hi', 'ig', 'ja', 'ko', 'pt', 'yo', 'zh']);
  });
  it('only Arabic is right-to-left', () => {
    expect(languages.filter(l => l.dir === 'rtl').map(l => l.code)).toEqual(['ar']);
  });
  it('flags every non-English language for native review', () => {
    for (const l of languages) expect(l.review === 'source').toBe(l.code === 'en');
  });
});

describe.each(languages.filter(l => l.code !== 'en').map(l => l.code))('Translations: %s', code => {
  const d = dictionaries[code];
  it('has every English key (no missing strings)', () => {
    expect(keys.filter(k => !d[k]?.trim())).toEqual([]);
  });
  it('has no unknown keys', () => {
    expect(Object.keys(d).filter(k => !(k in en))).toEqual([]);
  });
  it('keeps every {placeholder}', () => {
    expect(keys.filter(k => d[k] && ph(d[k]!) !== ph(en[k as keyof typeof en]))).toEqual([]);
  });
});

describe('Preserved hand-written translations', () => {
  it('keeps the original Igbo strings', () => { for (const [k, v] of Object.entries(legacyIg)) expect(dictionaries.ig[k]).toBe(v); });
  it('keeps the original Chinese strings', () => { for (const [k, v] of Object.entries(legacyZh)) expect(dictionaries.zh[k]).toBe(v); });
});

describe('Tool text keys', () => {
  it('match the tool registry exactly', () => {
    for (const t of tools) {
      expect(toolKeys[`tool.${t.id}.title` as keyof typeof toolKeys]).toBe(t.title);
      expect(toolKeys[`tool.${t.id}.description` as keyof typeof toolKeys]).toBe(t.description);
      t.options.forEach((o, i) => expect(toolKeys[`tool.${t.id}.option${i}` as keyof typeof toolKeys]).toBe(o));
    }
  });
});

describe('Lookup and browser suggestion', () => {
  it('interpolates variables', () => { expect(translate('en', 'time.dhm', { d: 6, h: 3, m: 5 })).toBe('6d 3h 5m'); });
  it('suggests a supported browser language', () => {
    expect(matchBrowserLang(['fr-CA', 'en'])).toBe('fr');
    expect(matchBrowserLang(['de-DE', 'ar-EG'])).toBe('ar');
    expect(matchBrowserLang(['de-DE'])).toBeNull();
  });
});

describe('Lagos time stays exact in every language', () => {
  const iso = '2026-10-19T21:58:10Z'; // 22:58 WAT
  it.each(languages.map(l => [l.code, l.locale]))('%s shows 22:58 WAT', (_c, locale) => {
    const s = formatLagos(iso, locale)!;
    expect(s.endsWith('WAT')).toBe(true);
    const digits = s.replace(/[٠-٩]/g, ch => String(ch.charCodeAt(0) - 0x0660)).replace(/[०-९]/g, ch => String(ch.charCodeAt(0) - 0x0966));
    expect(digits).toMatch(/22[:.]58/);
  });
  it('countdown values do not depend on language', () => {
    const now = Date.parse('2026-10-12T22:00:00Z');
    expect(countdown('2026-10-19T21:58:10Z', now)).toBe('6d 23h 58m');
    for (const l of languages) expect(countdown('2026-10-19T21:58:10Z', now, (k, v) => translate(l.code, k, v))).toMatch(/6.*23.*58/);
  });
});

describe('No hard-coded English in studio screens', () => {
  // Flags JSX text nodes like ">Sign in<" that bypass t(). Brand words are allowed.
  const allowed = /^(OBITREND|AI|CREATOR STUDIO|WAT|Pro|₦|·|—|…)$/;
  const dirs = ['src/components/studio', 'src/routes'];
  const files = dirs.flatMap(d => readdirSync(d, { recursive: true }).map(f => join(d, String(f)))).filter(f => f.endsWith('.tsx'));
  it.each(files)('%s', f => {
    const src = readFileSync(f, 'utf8').replace(/head:\s*\(\)\s*=>\s*\(\{[\s\S]*?\}\),\n/g, '');
    const hits = [...src.matchAll(/(?<![=-])>\s*([A-Za-z][A-Za-z ,.'!?&-]{2,})\s*</g)].map(m => m[1]!.trim()).filter(s => !allowed.test(s) && /[a-z]/.test(s));
    expect(hits).toEqual([]);
  });
});
