import { describe, it, expect } from 'vitest';
import { readFileSync, readdirSync } from 'node:fs';
import { adsAllowedForPlan, canRenderAdSlot } from '@/lib/ad-visibility';
import { observeVerifiedPlan, shouldCelebrate } from '@/lib/upgrade-success';
import { adSlots } from '@/lib/ad-slots';

const on = () => true;
const mem = () => { const m = new Map<string, string>(); return { getItem: (k: string) => m.get(k) ?? null, setItem: (k: string, v: string) => void m.set(k, v) }; };
const pro = { isPro: true, entitlement: { planId: 'pro-monthly', expiresAt: '2026-11-13T00:00:00Z' } };
const free = { isPro: false, entitlement: null };

describe('ad visibility', () => {
  it('Pro users never get an ad slot, even when enabled', () => {
    for (const id of Object.keys(adSlots) as (keyof typeof adSlots)[]) expect(canRenderAdSlot(id, { loaded: true, isPro: true }, on)).toBe(false);
  });
  it('Free users may see enabled designated slots only', () => {
    expect(canRenderAdSlot('dashboard', { loaded: true, isPro: false }, on)).toBe(true);
    expect(canRenderAdSlot('dashboard', { loaded: true, isPro: false }, () => false)).toBe(false);
  });
  it('unknown/loading plan shows no ads', () => expect(adsAllowedForPlan({ loaded: false, isPro: false })).toBe(false));
  it('no rewarded or watch-to-earn ad code exists', () => {
    const files = ['src/lib/ad-slots.ts', 'src/lib/ad-visibility.ts', 'src/components/studio/ad-slot.tsx'];
    for (const f of files) expect(readFileSync(f, 'utf8')).not.toMatch(/reward(ed)?Ad|onReward|watchToEarn|grantCredit/i);
    expect(readdirSync('src/components/studio').some(f => /reward/i.test(f))).toBe(false);
  });
});

describe('upgrade success trigger', () => {
  it('fires on a verified Free -> Pro transition, once', () => {
    const s = mem();
    expect(observeVerifiedPlan(s, 'u1', free)).toBe(false);
    expect(observeVerifiedPlan(s, 'u1', pro)).toBe(true);
    expect(observeVerifiedPlan(s, 'u1', pro)).toBe(false);
  });
  it('does not fire for an already-Pro user seen for the first time', () => {
    expect(observeVerifiedPlan(mem(), 'u2', pro)).toBe(false);
  });
  it('does not fire while the plan stays Free (e.g. opening pricing)', () => {
    const s = mem(); observeVerifiedPlan(s, 'u3', free);
    expect(observeVerifiedPlan(s, 'u3', free)).toBe(false);
  });
  it('requires a verified entitlement', () => {
    expect(shouldCelebrate({ lastIsPro: false, celebrated: [] }, { isPro: true, entitlement: null })).toBe(false);
  });
});
