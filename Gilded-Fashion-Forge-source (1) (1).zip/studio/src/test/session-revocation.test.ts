/**
 * Regression test: a copied access token must stop working once its session is
 * signed out.
 *
 * Uses only the normal password sign-in of a dedicated, already-confirmed test
 * account whose credentials are supplied by the test environment:
 *   SESSION_TEST_EMAIL, SESSION_TEST_PASSWORD
 * No admin keys, sign-in links or other bypasses are used. When those
 * variables are absent the end-to-end test is SKIPPED (not passed).
 */
import { existsSync, readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

const envFile = existsSync(`${process.cwd()}/.env`) ? readFileSync(`${process.cwd()}/.env`, 'utf8') : '';
const fromEnvFile = (k: string) => envFile.match(new RegExp(`^${k}="?([^"\\n]+)"?`, 'm'))?.[1] ?? '';
const url = fromEnvFile('VITE_SUPABASE_URL');
const key = fromEnvFile('VITE_SUPABASE_PUBLISHABLE_KEY');
const email = process.env['SESSION_TEST_EMAIL'] ?? '';
const password = process.env['SESSION_TEST_PASSWORD'] ?? '';
const ready = Boolean(url && key && email && password);

const tables = ['profiles', 'credit_wallets', 'entitlements', 'credit_ledger', 'payment_intents', 'user_roles'];
const headers = (token: string) => ({ apikey: key, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' });

async function signIn(): Promise<{ token: string; userId: string }> {
  const res = await fetch(`${url}/auth/v1/token?grant_type=password`, {
    method: 'POST', headers: { apikey: key, 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }),
  });
  const body = await res.json();
  if (!res.ok || !body.access_token) throw new Error(`test account sign-in failed (${res.status})`);
  return { token: body.access_token, userId: body.user.id };
}
const read = async (token: string, table: string) => {
  const res = await fetch(`${url}/rest/v1/${table}?select=*`, { headers: headers(token) });
  return res.ok ? ((await res.json()) as Record<string, unknown>[]) : [];
};

describe.skipIf(!ready)('Session revocation (dedicated test account, password sign-in)', () => {
  it('copied token works before sign-out and is rejected after', async () => {
    const { token, userId } = await signIn();
    const before = await read(token, 'credit_wallets');
    expect(before.map(r => r['user_id'])).toEqual([userId]);

    const out = await fetch(`${url}/auth/v1/logout?scope=local`, { method: 'POST', headers: headers(token) });
    expect(out.status).toBe(204);

    for (const t of tables) expect(await read(token, t), `${t} readable after sign-out`).toEqual([]);
    const write = await fetch(`${url}/rest/v1/payment_intents`, {
      method: 'POST', headers: headers(token), body: JSON.stringify({ user_id: userId, plan_id: 'pro-4d', amount_ngn: 10000 }),
    });
    expect(write.ok).toBe(false);
  });

  it('a fresh sign-in works and sees only its own records', async () => {
    const { token, userId } = await signIn();
    for (const t of tables) {
      const rows = await read(token, t);
      const owner = t === 'profiles' ? 'id' : 'user_id';
      expect(rows.every(r => r[owner] === userId)).toBe(true);
    }
    expect((await read(token, 'profiles')).length).toBe(1);
    await fetch(`${url}/auth/v1/logout?scope=local`, { method: 'POST', headers: headers(token) });
  });
});

describe('Special credentials stay out of the browser', () => {
  it('no client-visible variable holds a server secret', () => {
    const viteVars = envFile.split('\n').filter(l => l.startsWith('VITE_')).map(l => l.split('=')[0]);
    expect(viteVars.some(v => /SERVICE|SECRET|PASSWORD/i.test(v ?? ''))).toBe(false);
  });
  it.skipIf(!url || !key)('the public key cannot use admin sign-in tools', async () => {
    const res = await fetch(`${url}/auth/v1/admin/users`, { headers: { apikey: key, Authorization: `Bearer ${key}` } });
    expect(res.ok).toBe(false);
  });
});
