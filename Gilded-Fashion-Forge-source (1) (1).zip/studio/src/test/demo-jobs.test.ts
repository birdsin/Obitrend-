import { describe, expect, it } from 'vitest';
import { activeJobFor, addJob, advanceAll, canRetry, createJob, interruptStale, parseJobs, DEMO_DURATION_MS, type JobConfig } from '@/lib/demo-jobs';

const cfg: JobConfig = { toolId: 'fashion-image', title: 'Fashion Image', prompt: 'p', settings: {}, sampleIndex: 2 };

describe('demo generation jobs', () => {
  it('a job stays processing before readyAt (unmount/navigation never fails it)', () => {
    const jobs = [createJob(cfg, 1000, 'a')];
    expect(advanceAll(jobs, 1000 + DEMO_DURATION_MS - 1)[0]!.status).toBe('processing');
  });
  it('completes with a bundled sample reference once ready', () => {
    const j = advanceAll([createJob(cfg, 0, 'a')], DEMO_DURATION_MS)[0]!;
    expect(j.status).toBe('completed');
    expect(j.result).toEqual({ sampleIndex: 2 });
  });
  it('marks a job still processing after reload as interrupted, never completed', () => {
    const j = interruptStale([createJob(cfg, 0, 'a')], 99999)[0]!;
    expect(j.status).toBe('interrupted');
    expect(j.result).toBeUndefined();
    expect(j.config.prompt).toBe('p');
    expect(canRetry(j)).toBe(true);
  });
  it('leaves completed jobs untouched on reload', () => {
    const done = advanceAll([createJob(cfg, 0, 'a')], DEMO_DURATION_MS);
    expect(interruptStale(done, 99999)).toBe(done);
  });
  it('interrupted jobs survive a storage round-trip', () => {
    const jobs = interruptStale([createJob(cfg, 0, 'a')], 5);
    expect(parseJobs(JSON.stringify(jobs))).toEqual(jobs);
  });
  it('does not create a duplicate while a job for the tool is in flight', () => {
    const one = addJob([], createJob(cfg, 0, 'a'));
    const two = addJob(one, createJob(cfg, 5, 'b'));
    expect(two).toHaveLength(1);
    expect(activeJobFor(two, 'fashion-image')!.id).toBe('a');
  });
  it('survives a reload round-trip through storage', () => {
    const jobs = advanceAll([createJob(cfg, 0, 'a')], DEMO_DURATION_MS);
    expect(parseJobs(JSON.stringify(jobs))).toEqual(jobs);
    expect(parseJobs('not json')).toEqual([]);
    expect(parseJobs(JSON.stringify([{ id: 1 }]))).toEqual([]);
  });
  it('allows retry only for failed or interrupted jobs', () => {
    const j = createJob(cfg, 0, 'a');
    expect(canRetry(j)).toBe(false);
    expect(canRetry({ ...j, status: 'completed' })).toBe(false);
    expect(canRetry({ ...j, status: 'failed' })).toBe(true);
    expect(canRetry({ ...j, status: 'interrupted' })).toBe(true);
  });
});
