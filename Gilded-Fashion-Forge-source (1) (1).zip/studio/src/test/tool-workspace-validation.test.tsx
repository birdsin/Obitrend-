import { beforeEach, describe, expect, it, vi } from 'vitest';
import { act, fireEvent, render, screen } from '@testing-library/react';
import { ToolWorkspace } from '@/components/studio/tool-workspace';
import { tools } from '@/lib/studio-tools';

const { startJob, scrollIntoView } = vi.hoisted(() => ({ startJob: vi.fn(() => ({ id: 'demo-job' })), scrollIntoView: vi.fn() }));
vi.mock('@tanstack/react-router', () => ({ Link: ({ children }: { children: React.ReactNode }) => <span>{children}</span> }));
vi.mock('@/components/studio/studio-context', async () => {
  const { defaultCamera } = await import('@/lib/studio-options');
  return {
    useStudio: () => ({ outputs: [], jobs: [], jobsRestored: true, toolState: {}, saveToolState: vi.fn(), startJob }),
    initialToolState: (direction: string) => ({ prompt: '', direction, fields: {}, camera: defaultCamera }),
    jobToOutput: vi.fn(), exportBrief: vi.fn(),
  };
});
vi.mock('@/components/studio/ad-slot', () => ({ AdSlot: () => null }));

function setup() {
  const tool = tools.find(t => t.id === 'fashion-image');
  if (!tool) throw new Error('Fashion image tool missing');
  render(<ToolWorkspace tool={tool} />);
  return screen.getByLabelText(/Describe your vision/);
}

describe('Workspace creative brief validation', () => {
  beforeEach(() => {
    vi.clearAllMocks(); localStorage.clear();
    HTMLElement.prototype.scrollIntoView = scrollIntoView;
  });
  it('blocks whitespace-only briefs and focuses the actual input without native submission', () => {
    const input = setup();
    fireEvent.change(input, { target: { value: '   ' } });
    const form = screen.getByRole('button', { name: 'Generate' }).closest('form');
    if (!form) throw new Error('Generation form missing');
    const event = new Event('submit', { bubbles: true, cancelable: true });
    fireEvent(form, event);
    expect(event.defaultPrevented).toBe(true);
    expect(startJob).not.toHaveBeenCalled();
    expect(document.activeElement).toBe(input);
    input.blur();
    fireEvent.click(screen.getByRole('button', { name: /Add your creative brief/ }));
    expect(document.activeElement).toBe(input);
    expect(scrollIntoView).toHaveBeenCalledWith({ block: 'center', behavior: 'auto' });
    expect(startJob).not.toHaveBeenCalled();
  });
  it('clears the brief error when corrected and starts only one labelled demo job', () => {
    const input = setup();
    fireEvent.click(screen.getByRole('button', { name: 'Generate' }));
    expect(startJob).not.toHaveBeenCalled();
    fireEvent.change(input, { target: { value: '  Ivory gown in a hotel lobby  ' } });
    expect(screen.queryByRole('alert')).toBeNull();
    fireEvent.click(screen.getByRole('button', { name: 'Generate' }));
    expect(startJob).toHaveBeenCalledTimes(1);
    expect(startJob).toHaveBeenCalledWith(expect.objectContaining({ prompt: 'Ivory gown in a hotel lobby', providerStatus: 'not_connected' }));
  });
  it('keeps translated camera controls as English request values', async () => {
    const { setLang } = await import('@/lib/use-lang');
    act(() => setLang('fr'));
    const tool = tools.find(t => t.id === 'fashion-image');
    if (!tool) throw new Error('Missing tool');
    const { container } = render(<ToolWorkspace tool={tool} />);
    const angle = container.querySelector('#cam-angle');
    if (!angle) throw new Error('Missing angle control');
    fireEvent.change(angle, { target: { value: 'Low angle' } });
    expect(screen.getByTestId('generation-request').textContent).toContain('low angle');
    expect(angle).toHaveValue('Low angle');
    act(() => setLang('en'));
  });
});