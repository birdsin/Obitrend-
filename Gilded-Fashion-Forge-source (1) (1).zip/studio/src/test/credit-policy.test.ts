import { describe, expect, it } from 'vitest';
import { FREE_PERIOD_MS, canOpenPath, canUseTool, refreshFreeWallet, refundCharge } from '@/lib/credit-policy';
import { tools } from '@/lib/studio-tools';

const T0 = Date.UTC(2026, 9, 12, 4, 0, 0);
describe('free weekly credits', () => {
  it('first refresh grants exactly 2 credits with a reset 7 days later', () => {
    expect(refreshFreeWallet({ freeCredits: 0, resetsAt: null }, false, T0)).toEqual({ freeCredits: 2, resetsAt: T0 + 7 * 86400000 });
  });
  it('reloading inside the period never adds credits', () => {
    const w = { freeCredits: 1, resetsAt: T0 + FREE_PERIOD_MS };
    expect(refreshFreeWallet(w, false, T0 + 1000)).toEqual(w);
    expect(refreshFreeWallet(w, false, T0 + FREE_PERIOD_MS - 1)).toEqual(w);
  });
  it('after the reset time the balance becomes 2 again, not 3', () => {
    expect(refreshFreeWallet({ freeCredits: 1, resetsAt: T0 }, false, T0).freeCredits).toBe(2);
  });
  it('Pro accounts never hold free credits', () => {
    expect(refreshFreeWallet({ freeCredits: 2, resetsAt: T0 + 5 }, true, T0)).toEqual({ freeCredits: 0, resetsAt: null });
  });
});
describe('refunds', () => {
  it('a failed reserved charge refunds exactly once', () => {
    const first = refundCharge({ status: 'reserved' });
    expect(first.refunded).toBe(true);
    expect(refundCharge(first.charge).refunded).toBe(false);
  });
  it('a completed charge is never refunded', () => {
    expect(refundCharge({ status: 'completed' }).refunded).toBe(false);
  });
});
describe('free vs Pro access', () => {
  it('free accounts are locked out of all 20 tools and video, but keep the prompt studio', () => {
    expect(tools).toHaveLength(20);
    for (const t of tools) { expect(canUseTool(t.id, false)).toBe(false); expect(canOpenPath(`/tools/${t.id}`, false)).toBe(false); }
    expect(canOpenPath('/video', false)).toBe(false);
    expect(canOpenPath('/prompt-studio', false)).toBe(true);
    expect(canUseTool('prompt-studio', false)).toBe(true);
  });
  it('Pro accounts keep access to every tool', () => {
    for (const t of tools) expect(canUseTool(t.id, true)).toBe(true);
    expect(canOpenPath('/video', true)).toBe(true);
  });
});
