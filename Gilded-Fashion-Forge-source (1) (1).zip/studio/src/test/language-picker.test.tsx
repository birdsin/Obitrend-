import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { act, fireEvent, render, screen } from '@testing-library/react';
import { LanguagePicker } from '@/components/studio/language-picker';
import { LANG_STORAGE_KEY, setLang } from '@/lib/use-lang';

describe('Language selection', () => {
  beforeEach(() => { localStorage.clear(); act(() => setLang('en')); });
  afterEach(() => { act(() => setLang('en')); });

  it('stores the selected Japanese language without changing account or prompt data', () => {
    localStorage.setItem('existing-prompt', 'English user input');
    render(<LanguagePicker />);
    fireEvent.click(screen.getByRole('button', { name: 'Choose language' }));
    fireEvent.click(screen.getByRole('option', { name: /日本語/ }).querySelector('button') ?? screen.getByRole('option', { name: /日本語/ }));
    expect(localStorage.getItem(LANG_STORAGE_KEY)).toBe('ja');
    expect(localStorage.getItem('existing-prompt')).toBe('English user input');
    expect(document.documentElement.lang).toBe('ja');
    expect(screen.queryByRole('listbox')).toBeNull();
  });

  it('sets Arabic direction and restores left-to-right when English is chosen', () => {
    const { unmount } = render(<LanguagePicker />);
    fireEvent.click(screen.getByRole('button', { name: 'Choose language' }));
    fireEvent.click(screen.getByRole('option', { name: /العربية/ }).querySelector('button') ?? screen.getByRole('option', { name: /العربية/ }));
    expect(localStorage.getItem(LANG_STORAGE_KEY)).toBe('ar');
    expect(document.documentElement.dir).toBe('rtl');
    unmount();
    act(() => setLang('en'));
    expect(document.documentElement.dir).toBe('ltr');
  });
});