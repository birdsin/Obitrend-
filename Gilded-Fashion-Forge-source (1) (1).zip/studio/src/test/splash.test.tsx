import { describe, expect, it } from 'vitest';
import { render } from '@testing-library/react';
import { Splash } from '@/components/studio/splash';

describe('Unauthenticated startup', () => {
  it('can start before the private studio provider exists', () => {
    expect(() => render(<Splash onDone={() => {}} />)).not.toThrow();
  });
});