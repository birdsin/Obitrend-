import { describe, expect, it } from 'vitest';
import { buildGenerationRequest, CAMERA_PRIORITY_RULE, GARMENT_FIDELITY_RULE, loadCamera, saveCamera, submitGenerationRequest } from '@/lib/generation-request';
import { applyPreset, defaultCamera } from '@/lib/studio-options';

const base = { userPrompt: 'Ivory gown', direction: 'Editorial', fields: { model: 'Female model' }, referenceName: 'gown.jpg' };

describe('Camera settings in the generation request', () => {
  it('records the displayed model, pose and expression defaults when unchanged', () => {
    const r = buildGenerationRequest({ ...base, fields: {}, toolId: 'fashion-image' });
    expect(r.options['model']).toBe('Female model');
    expect(r.options['pose']).toBe('Standing front');
    expect(r.options['expression']).toBe('Neutral');
    expect(r.prompt).toContain('Expression: Neutral.');
  });
  it('keeps the uploaded garment first even with conflicting direction and colour choices', () => {
    const r = buildGenerationRequest({ ...base, toolId: 'colour-variations', fields: { colour: 'Emerald' }, userPrompt: 'Change the garment' });
    expect(r.prompt.indexOf(GARMENT_FIDELITY_RULE)).toBe(0);
    expect(r.prompt.indexOf('Colour: Emerald.')).toBeGreaterThan(GARMENT_FIDELITY_RULE.length);
    expect(r.reference?.name).toBe('gown.jpg');
  });
  it('includes the chosen preset and fine-tune values as data and prompt text', () => {
    const camera = { ...applyPreset(defaultCamera, 'Portrait'), ratio: '9:16', quality: 'Ultra', lightDir: 'Rim' };
    const r = buildGenerationRequest({ ...base, toolId: 'fashion-image', camera });
    expect(r.camera?.aperture).toBe('f/1.8');
    expect(r.output).toEqual({ ratio: '9:16', quality: 'Ultra' });
    expect(r.prompt).toContain('85mm lens');
    expect(r.prompt).toContain('rim light');
    expect(r.prompt).toContain('9:16');
  });
  it('keeps garment fidelity first and camera below it', () => {
    const r = buildGenerationRequest({ ...base, toolId: 'fashion-image', camera: defaultCamera });
    expect(r.prompt.startsWith(GARMENT_FIDELITY_RULE)).toBe(true);
    expect(r.prompt).toContain(CAMERA_PRIORITY_RULE);
    expect(r.reference).toEqual({ name: 'gown.jpg' });
  });
  it('falls back to default camera values when missing', () => {
    const r = buildGenerationRequest({ ...base, toolId: 'fashion-image', camera: null });
    expect(r.camera).toEqual(defaultCamera);
  });
  it('leaves camera out for tools without camera controls', () => {
    const r = buildGenerationRequest({ ...base, toolId: 'colour-variations', camera: defaultCamera });
    expect(r.camera).toBeNull();
    expect(r.prompt).not.toContain('Camera:');
  });
  it('persists camera settings per tool across reloads', () => {
    const m = new Map<string, string>(); const store = { getItem: (k: string) => m.get(k) ?? null, setItem: (k: string, v: string) => void m.set(k, v) };
    saveCamera(store, 'lookbook', { ...defaultCamera, lens: '135mm' });
    expect(loadCamera(store, 'lookbook')?.lens).toBe('135mm');
    expect(loadCamera(store, 'fashion-image')).toBeNull();
  });
  it('reports provider not connected instead of returning an image', async () => {
    const r = await submitGenerationRequest(buildGenerationRequest({ ...base, toolId: 'fashion-image' }));
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.reason).toBe('provider_not_connected');
  });
});
