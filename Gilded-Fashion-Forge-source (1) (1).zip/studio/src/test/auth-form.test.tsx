import { beforeEach, describe, expect, it, vi } from 'vitest';
import { act, fireEvent, render, screen } from '@testing-library/react';
import { AuthForm, resetAuthDraft } from '@/components/studio/auth-form';
import { setLang } from '@/lib/use-lang';
import { translate } from '@/lib/i18n';

function setup() {
  const onSubmit = vi.fn(async () => {});
  const onGoogle = vi.fn(async () => {});
  const utils = render(<AuthForm onSubmit={onSubmit} onGoogle={onGoogle} />);
  return { onSubmit, onGoogle, ...utils };
}

describe('auth form', () => {
  beforeEach(() => { resetAuthDraft(); localStorage.clear(); sessionStorage.clear(); });

  it('keeps typed values if the form is unmounted and remounted, without writing them to storage', () => {
    const first = setup();
    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'keep@me.co' } });
    fireEvent.change(screen.getByLabelText('Password'), { target: { value: 'Secret-123!' } });
    first.unmount();
    setup();
    expect((screen.getByLabelText('Email') as HTMLInputElement).value).toBe('keep@me.co');
    expect((screen.getByLabelText('Password') as HTMLInputElement).value).toBe('Secret-123!');
    const stored = JSON.stringify({ ...localStorage }) + JSON.stringify({ ...sessionStorage });
    expect(stored).not.toContain('Secret-123!');
  });

  it('pressing Enter (Android Go key) submits via the handler, never a native reload', () => {
    const { onSubmit } = setup();
    const form = screen.getByRole('button', { name: 'Sign in' }).closest('form')!;
    const ev = new Event('submit', { bubbles: true, cancelable: true });
    form.dispatchEvent(ev);
    expect(ev.defaultPrevented).toBe(true);
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it('keeps email and password while typing continuously, without submitting', () => {
    const { onSubmit } = setup();
    const email = screen.getByLabelText('Email') as HTMLInputElement;
    const pw = screen.getByLabelText('Password') as HTMLInputElement;
    let typed = '';
    for (const ch of 'tester@example.com') { typed += ch; fireEvent.change(email, { target: { value: typed } }); }
    fireEvent.change(pw, { target: { value: 'Str0ng-pass!' } });
    expect(email.value).toBe('tester@example.com');
    expect(pw.value).toBe('Str0ng-pass!');
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it('preserves values across rerenders', () => {
    const { rerender, onSubmit, onGoogle } = setup();
    fireEvent.change(screen.getByLabelText('Email'), { target: { value: 'a@b.co' } });
    rerender(<AuthForm onSubmit={onSubmit} onGoogle={onGoogle} />);
    expect((screen.getByLabelText('Email') as HTMLInputElement).value).toBe('a@b.co');
  });

  it('runs exactly one auth action per explicit submit, even on double click', async () => {
    let resolve!: () => void;
    const onSubmit = vi.fn(() => new Promise<void>(r => { resolve = r; }));
    render(<AuthForm onSubmit={onSubmit} onGoogle={async () => {}} />);
    fireEvent.change(screen.getByLabelText('Email'), { target: { value: ' a@b.co ' } });
    fireEvent.change(screen.getByLabelText('Password'), { target: { value: 'pw' } });
    const form = screen.getByRole('button', { name: 'Sign in' }).closest('form')!;
    fireEvent.submit(form); fireEvent.submit(form);
    expect(onSubmit).toHaveBeenCalledTimes(1);
    expect(onSubmit).toHaveBeenCalledWith('sign-in', 'a@b.co', 'pw');
    await act(async () => { resolve(); });
  });

  it('does not submit with empty fields', () => {
    const { onSubmit } = setup();
    fireEvent.submit(screen.getByRole('button', { name: 'Sign in' }).closest('form')!);
    expect(onSubmit).not.toHaveBeenCalled();
    expect(screen.getByRole('alert')).toHaveTextContent('Enter your email and password.');
  });

  it('updates existing validation when the interface language changes', () => {
    setup();
    fireEvent.submit(screen.getByRole('button', { name: 'Sign in' }).closest('form') ?? document.createElement('form'));
    act(() => setLang('ja'));
    expect(screen.getByRole('alert')).toHaveTextContent(translate('ja', 'auth.errorMissing'));
    act(() => setLang('en'));
  });
});
