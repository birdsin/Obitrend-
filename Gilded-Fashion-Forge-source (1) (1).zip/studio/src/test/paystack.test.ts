import { describe, expect, it } from 'vitest';
import { isTestSecretKey, planGrant, proPlanForCheckout, signPaystackBody, toKobo, verifyPaystackSignature } from '@/lib/paystack';

const secret = 'sk_test_unit_only_not_a_real_key';
const body = JSON.stringify({ event: 'charge.success', data: { reference: 'test_abc', amount: 1000000, currency: 'NGN' } });

describe('Paystack callbacks', () => {
  it('accepts a correctly signed webhook', async () => {
    expect(await verifyPaystackSignature(body, await signPaystackBody(body, secret), secret)).toBe(true);
  });
  it('rejects a tampered body (amount changed)', async () => {
    const sig = await signPaystackBody(body, secret);
    expect(await verifyPaystackSignature(body.replace('1000000', '100'), sig, secret)).toBe(false);
  });
  it('rejects missing or wrong-key signatures', async () => {
    expect(await verifyPaystackSignature(body, null, secret)).toBe(false);
    expect(await verifyPaystackSignature(body, await signPaystackBody(body, 'sk_test_other'), secret)).toBe(false);
  });
  it('only accepts test-mode secret keys', () => {
    expect(isTestSecretKey('sk_test_x')).toBe(true);
    expect(isTestSecretKey('sk_live_x')).toBe(false);
    expect(isTestSecretKey(undefined)).toBe(false);
  });
});

describe('Pro plan grants come from the listed plans', () => {
  it('4 Day Pro is ₦10,000 = 1,000,000 kobo, 4 days, 5 credits', () => {
    expect(toKobo(proPlanForCheckout('pro-4d')!.priceNgn)).toBe(1_000_000);
    expect(planGrant('pro-4d')).toEqual({ days: 4, credits: 5 });
  });
  it('Monthly Full Pro is ₦60,000, 30 days, 30 credits', () => {
    expect(toKobo(proPlanForCheckout('pro-monthly')!.priceNgn)).toBe(6_000_000);
    expect(planGrant('pro-monthly')).toEqual({ days: 30, credits: 30 });
  });
  it('unknown or video plans cannot be bought as Pro', () => {
    expect(planGrant('video-5s')).toBeNull();
    expect(proPlanForCheckout('pro-free')).toBeNull();
  });
});
