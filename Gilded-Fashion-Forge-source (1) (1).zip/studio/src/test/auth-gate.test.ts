import { QueryClient } from '@tanstack/react-query';
import { createRouter } from '@tanstack/react-router';
import { describe, expect, it } from 'vitest';
import { routeTree } from '@/routeTree.gen';

const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });
describe('auth gate', () => {
  it.each(['/', '/tools/fashion-image', '/prompt-studio', '/video', '/history', '/downloads', '/account', '/cameras', '/pricing'])('%s sits behind the sign-in gate', path => {
    const ids = router.matchRoutes(path).map(m => m.routeId);
    expect(ids).toContain('/_authenticated');
  });
  it('the sign-in page stays public', () => {
    expect(router.matchRoutes('/auth').map(m => m.routeId)).not.toContain('/_authenticated');
  });
});
