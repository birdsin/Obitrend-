import { describe, expect, it } from 'vitest';
import { runChargedPrompt, type ChargeDeps, type PromptProvider, type Reservation } from '@/lib/prompt-charge';
import { refreshFreeWallet, FREE_PERIOD_MS } from '@/lib/credit-policy';

// In-memory mock mirroring reserve_request_credit / complete / refund.
function mockLedger(opts: { isPro: boolean; plan: number; free: number }) {
  const s = { ...opts, charges: new Map<string, { id: string; status: Reservation['status']; source: 'free' | 'plan' }>() };
  const deps: ChargeDeps = {
    async reserve(req) {
      const ex = s.charges.get(req); if (ex) return { chargeId: ex.id, status: ex.status, source: ex.source, duplicate: true };
      const source: 'free' | 'plan' = s.isPro ? 'plan' : 'free';
      if (source === 'plan') { if (s.plan <= 0) throw new Error('no credits left'); s.plan--; } else { if (s.free <= 0) throw new Error('no credits left'); s.free--; }
      const c = { id: 'c-' + req, status: 'reserved' as const, source }; s.charges.set(req, c); return { chargeId: c.id, status: c.status, source, duplicate: false };
    },
    async complete(id) { const c = [...s.charges.values()].find(x => x.id === id)!; if (c.status !== 'reserved') return false; c.status = 'completed'; return true; },
    async refund(id) { const c = [...s.charges.values()].find(x => x.id === id)!; if (c.status !== 'reserved') return false; c.status = 'refunded'; if (c.source === 'free') s.free++; else s.plan++; return true; },
  };
  return { s, deps };
}
const okProvider: PromptProvider = { generate: async p => ({ ok: true, text: 'Enhanced: ' + p }) };
const badProvider: PromptProvider = { generate: async () => { throw new Error('boom'); } };

describe('Text-to-prompt credit charging', () => {
  it('a successful generation costs exactly 1 free credit', async () => {
    const { s, deps } = mockLedger({ isPro: false, plan: 0, free: 2 });
    const r = await runChargedPrompt('r1', 'dress', deps, okProvider);
    expect(r.status).toBe('generated'); expect(s.free).toBe(1);
  });
  it('insufficient credits charges nothing and does not call the provider', async () => {
    const { s, deps } = mockLedger({ isPro: false, plan: 5, free: 0 });
    let called = false;
    const r = await runChargedPrompt('r1', 'x', deps, { generate: async () => { called = true; return { ok: true, text: 'y' }; } });
    expect(r.status).toBe('insufficient_credits'); expect(called).toBe(false); expect(s.free).toBe(0); expect(s.plan).toBe(5);
  });
  it('a failed generation refunds exactly once', async () => {
    const { s, deps } = mockLedger({ isPro: false, plan: 0, free: 2 });
    const r = await runChargedPrompt('r1', 'x', deps, badProvider);
    expect(r).toMatchObject({ status: 'failed_refunded', refunded: true }); expect(s.free).toBe(2);
    expect(await deps.refund('c-r1')).toBe(false); expect(s.free).toBe(2);
  });
  it('no connected service: nothing generated, credit returned', async () => {
    const { s, deps } = mockLedger({ isPro: false, plan: 0, free: 2 });
    const r = await runChargedPrompt('r1', 'x', deps, null);
    expect(r.status).toBe('failed_refunded'); expect(s.free).toBe(2);
  });
  it('repeating the same request never deducts twice', async () => {
    const { s, deps } = mockLedger({ isPro: false, plan: 0, free: 2 });
    await runChargedPrompt('r1', 'x', deps, okProvider);
    const again = await runChargedPrompt('r1', 'x', deps, okProvider);
    expect(again.status).toBe('duplicate'); expect(s.free).toBe(1);
  });
  it('Pro users spend plan credits, never free ones', async () => {
    const { s, deps } = mockLedger({ isPro: true, plan: 3, free: 0 });
    const r = await runChargedPrompt('r1', 'x', deps, okProvider);
    expect(r).toMatchObject({ status: 'generated', source: 'plan' }); expect(s.plan).toBe(2);
    expect(refreshFreeWallet({ freeCredits: 0, resetsAt: null }, true, 0).freeCredits).toBe(0);
  });
  it('free credits renew to 2 only after 7 days', () => {
    const w = { freeCredits: 0, resetsAt: FREE_PERIOD_MS };
    expect(refreshFreeWallet(w, false, FREE_PERIOD_MS - 1).freeCredits).toBe(0);
    expect(refreshFreeWallet(w, false, FREE_PERIOD_MS).freeCredits).toBe(2);
  });
});
