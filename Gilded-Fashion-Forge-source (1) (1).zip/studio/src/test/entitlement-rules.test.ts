import { describe, expect, it } from 'vitest';
import { cameraProfiles, canUseCamera, imagePlans, videoOptions, type Entitlement } from '@/lib/plans';
import { demoSamples } from '@/lib/workflow-visuals';

const future = new Date(Date.now() + 86_400_000).toISOString();
const past = new Date(Date.now() - 86_400_000).toISOString();
const ent = (planId: 'pro-4d' | 'pro-monthly', expiresAt = future): Entitlement =>
  ({ verified: true, planId, imageCreditsLeft: 0, videoCreditsLeft: 0, expiresAt });

describe('Pro camera access depends only on server plan state', () => {
  it('locks all four cameras without a server entitlement', () => {
    expect(cameraProfiles).toHaveLength(4);
    expect(cameraProfiles.every(c => !canUseCamera(null, c))).toBe(true);
  });
  it('locks all cameras when the plan has expired', () => {
    expect(cameraProfiles.some(c => canUseCamera(ent('pro-monthly', past), c))).toBe(false);
  });
  it('rejects an entitlement not marked verified', () => {
    const fake = { ...ent('pro-monthly'), verified: false } as unknown as Entitlement;
    expect(cameraProfiles.some(c => canUseCamera(fake, c))).toBe(false);
  });
  it('4 Day Pro unlocks only the Canon profile', () => {
    expect(cameraProfiles.filter(c => canUseCamera(ent('pro-4d'), c)).map(c => c.id)).toEqual(['canon-r5-ii']);
  });
  it('Monthly Full Pro unlocks all four profiles', () => {
    expect(cameraProfiles.filter(c => canUseCamera(ent('pro-monthly'), c))).toHaveLength(4);
  });
});

describe('Demo samples never grant credits or plans', () => {
  it('sample records carry no plan, credit or payment fields', () => {
    const banned = ['planId', 'plan_id', 'credits', 'imageCredits', 'videoCredits', 'amount', 'payment', 'entitlement'];
    for (const s of demoSamples) for (const k of banned) expect(Object.keys(s)).not.toContain(k);
  });
});

describe('Server price table matches the listed prices', () => {
  // Mirrors public.validate_payment_intent(); keep both in sync.
  const serverPrices: Record<string, number> = {
    'pro-4d': 10000, 'pro-8d': 20000, 'pro-14d': 30000, 'pro-monthly': 60000,
    'video-5s': 5000, 'video-10s': 10000, 'video-15s': 15000, 'video-20s': 20000,
  };
  it('image plans', () => { for (const p of imagePlans) expect(serverPrices[p.id]).toBe(p.priceNgn); });
  it('video lengths', () => { for (const v of videoOptions) expect(serverPrices[`video-${v.seconds}s`]).toBe(v.priceNgn); });
});
