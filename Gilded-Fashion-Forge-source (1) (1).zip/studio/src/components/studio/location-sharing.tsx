import { useState } from 'react';
import type { Key } from '@/lib/i18n';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/lib/use-auth';
import { deleteMyLocation, getMyLocation, revokeMyLocation, saveMyLocation } from '@/lib/location.functions';
import { formatLagos } from '@/lib/lagos-time';
import { useLang } from '@/lib/use-lang';

/** Opt-in only: the browser location API is never touched until the user presses Share and grants permission. */
export function LocationSharing() {
  const { t, locale } = useLang();
  const { user } = useAuth();
  const qc = useQueryClient();
  const key = ['my-location', user?.id];
  const { data: loc, isError } = useQuery({ queryKey: key, queryFn: () => getMyLocation(), enabled: !!user });
  const save = useServerFn(saveMyLocation), revoke = useServerFn(revokeMyLocation), del = useServerFn(deleteMyLocation);
  const [agreed, setAgreed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<Key | ''>('');
  const done = async (m: Key) => { setMsg(m); setBusy(false); await qc.invalidateQueries({ queryKey: key }); };

  const share = () => {
    if (!agreed) { setMsg('loc.msgConsent'); return; }
    if (!('geolocation' in navigator)) { setMsg('loc.msgNotSupported'); return; }
    setBusy(true); setMsg('loc.msgWaiting');
    navigator.geolocation.getCurrentPosition(
      async p => { try { await save({ data: { latitude: p.coords.latitude, longitude: p.coords.longitude, accuracyM: p.coords.accuracy ?? null } }); await done('loc.msgShared'); } catch { await done('loc.msgSaveError'); } },
      e => { setBusy(false); setMsg(e.code === e.PERMISSION_DENIED ? 'loc.msgDenied' : 'loc.msgReadError'); },
      { enableHighAccuracy: false, timeout: 15000, maximumAge: 0 },
    );
  };
  const active = !!loc?.consentGivenAt && !loc.revokedAt;

  return <section className="form-section mt-4">
    <h2 className="section-title mb-3 flex gap-2 items-center"><MapPin className="text-primary" size={18} /> {t('loc.title')}</h2>
    <p className="text-xs text-muted-foreground leading-5">{t('loc.description')}</p>
    {isError && <p role="alert" className="text-destructive text-xs mt-3">{t('loc.errorLoad')}</p>}
    {active && loc?.latitude !== null && <dl className="text-xs space-y-1 mt-4">
      <div className="flex justify-between"><dt className="text-muted-foreground">{t('loc.sharedLocation')}</dt><dd dir="ltr">{loc.latitude?.toFixed(2)}, {loc.longitude?.toFixed(2)}</dd></div>
      <div className="flex justify-between"><dt className="text-muted-foreground">{t('loc.consentGiven')}</dt><dd dir="ltr">{formatLagos(loc.consentGivenAt, locale)}</dd></div>
      <div className="flex justify-between"><dt className="text-muted-foreground">{t('loc.lastUpdated')}</dt><dd dir="ltr">{formatLagos(loc.capturedAt, locale) ?? '—'}</dd></div>
    </dl>}
    {loc?.revokedAt && <p className="text-xs text-muted-foreground mt-3">{t('loc.sharingStoppedAt', { date: formatLagos(loc.revokedAt, locale) ?? '' })}</p>}
    {!active && <label className="flex gap-2 items-start text-xs mt-4"><input type="checkbox" className="w-auto mt-0.5" checked={agreed} onChange={e => setAgreed(e.target.checked)} /> {t('loc.consentCheckbox')}</label>}
    <div className="flex flex-wrap gap-2 mt-4">
      <Button type="button" onClick={share} disabled={busy || (!active && !agreed)}>{active ? t('loc.updateBtn') : t('loc.shareBtn')}</Button>
      {active && <Button type="button" variant="outline" disabled={busy} onClick={async () => { setBusy(true); try { await revoke(); await done('loc.msgRevoked'); } catch { await done('loc.msgRevokeError'); } }}>{t('loc.stopBtn')}</Button>}
      {loc && <Button type="button" variant="ghost" disabled={busy} onClick={async () => { setBusy(true); try { await del(); setAgreed(false); await done('loc.msgDeleted'); } catch { await done('loc.msgDeleteError'); } }}>{t('loc.deleteBtn')}</Button>}
    </div>
    {msg && <p role="status" className="text-xs mt-3">{t(msg)}</p>}
  </section>;
}
