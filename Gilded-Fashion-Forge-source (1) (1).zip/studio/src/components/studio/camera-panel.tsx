import { Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { applyPreset, cameraOptions, cameraPresets, type CameraSettings } from '@/lib/studio-options';
import { useLang } from '@/lib/use-lang';
import { type Key } from '@/lib/i18n';
import { SlidersHorizontal } from 'lucide-react';
import { cameraControlIcons, cameraPresetIcons } from './camera-icons';

export function CameraPanel({ value, onChange, hideRatio = false }: { value: CameraSettings; onChange: (v: CameraSettings) => void; hideRatio?: boolean }) {
  const { t } = useLang();
  const keys = (Object.keys(cameraOptions) as (keyof CameraSettings)[]).filter(k => k !== 'preset' && !(hideRatio && k === 'ratio'));
  return <section className="camera-controls" aria-labelledby="camera-title">
    <div className="flex items-center gap-2 mb-2"><span className="camera-icon-tile"><Camera aria-hidden="true" /></span><h2 id="camera-title" className="section-title">{t('ws.cameraTitle')}</h2></div>
    <p className="text-[10px] text-muted-foreground mb-4">{t('ws.cameraDescription')}</p>
    <div className="camera-preset-grid">{Object.keys(cameraPresets).map(name => { const Icon = cameraPresetIcons[name] ?? Camera; return <Button key={name} type="button" variant="outline" aria-pressed={value.preset === name} className="camera-preset-button" onClick={() => onChange(applyPreset(value, name))}>
        <Icon aria-hidden="true" className="camera-preset-symbol" /><span className="text-xs font-semibold">{t(`ws.option.camera.preset.${name}` as Key)}</span><span className="camera-preset-hint">{t(`ws.option.camera.preset.${name}.hint` as Key)}</span>
      </Button>; })}</div>
    <details className="camera-details mt-3"><summary className="text-xs cursor-pointer py-2"><span className="camera-fine-tune-label"><SlidersHorizontal aria-hidden="true" className="size-4" />{t('ws.cameraFineTune')}</span></summary>
      <div className="camera-field-grid mt-3">{keys.map(k => { const Icon = cameraControlIcons[k]; return <div key={k} className={k === 'ratio' || k === 'framing' ? 'camera-field-wide' : ''}><label className="camera-control-label" htmlFor={`cam-${k}`}><Icon aria-hidden="true" className="camera-label-icon" />{t(`ws.camera.${k}` as Key)}</label><select id={`cam-${k}`} value={value[k]} onChange={e => onChange({ ...value, [k]: e.target.value })}>{cameraOptions[k].map(o => <option key={o} value={o}>{t(`ws.option.camera.${k}.${o}` as Key)}</option>)}</select></div>; })}</div>
    </details>
    <div className="flex flex-wrap gap-1 mt-4" aria-label={t('ws.activeCameraSettings')}>
      {[
        { k: 'preset', v: value.preset },
        { k: 'lens', v: value.lens },
        { k: 'aperture', v: value.aperture },
        { k: 'framing', v: value.framing },
        { k: 'ratio', v: value.ratio },
        { k: 'quality', v: value.quality }
      ].map(({ k, v }) => { const Icon = cameraControlIcons[k as keyof CameraSettings]; return <span key={k} className="pill text-primary"><Icon aria-hidden="true" className="size-3" />{t(`ws.option.camera.${k}.${v}` as Key)}</span>; })}
    </div>
  </section>;
}
