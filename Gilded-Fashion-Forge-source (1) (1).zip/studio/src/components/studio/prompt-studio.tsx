import { useAccount, useRefreshAccount } from '@/lib/use-account';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { generatePrompt, getCreditHistory } from '@/lib/prompt-generation.functions';
import type { ChargedOutcome } from '@/lib/prompt-charge';
import { PROMPT_NOT_CONNECTED } from '@/lib/prompt-charge';
import { formatLagos, spendableCredits } from '@/lib/lagos-time';
import { Link } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { Copy, Eraser, Save, Wand2, Trash2, CheckCircle2, Sparkles, Loader2, AlertTriangle, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { buildPrompt, demoEnhance, emptyPrompt, type PromptParts } from '@/lib/studio-options';
import { useStudio } from './studio-context';
import type { Key } from '@/lib/i18n';

export const PROMPT_TOOL_ID = 'prompt-studio';

export function PromptStudio() {
  const { t, locale, savedPrompts, savePrompt, removePrompt, promptDraft, setPromptDraft } = useStudio();
  const { data: account } = useAccount();
  const isPro = !!account?.isPro;
  const credits = account ? spendableCredits(account) : null;
  const refreshAccount = useRefreshAccount();
  const qc = useQueryClient();
  const history = useQuery({ queryKey: ['credit-history', account?.userId], queryFn: () => getCreditHistory(), enabled: !!account });
  const [busy, setBusy] = useState(false);
  const [outcome, setOutcome] = useState<ChargedOutcome | null>(null);
  const [requestId, setRequestId] = useState<string | null>(null);
  const [parts, setParts] = useState<PromptParts>(promptDraft?.parts ?? emptyPrompt);
  const [final, setFinal] = useState(promptDraft?.final ?? buildPrompt(emptyPrompt));
  const [edited, setEdited] = useState(promptDraft?.edited ?? false);
  useEffect(() => { setPromptDraft({ parts, final, edited }); }, [parts, final, edited]); // eslint-disable-line react-hooks/exhaustive-deps
  const [note, setNote] = useState<Key | ''>('');
  const [genError, setGenError] = useState<Key | ''>('');
  useEffect(() => { if (!edited) setFinal(buildPrompt(parts)); }, [parts, edited]);

  const fields: { key: keyof PromptParts; label: string; placeholder: string; rows?: number }[] = [
    { key: 'idea', label: t('prompt.fields.idea.label'), placeholder: t('prompt.fields.idea.placeholder'), rows: 3 },
    { key: 'garment', label: t('prompt.fields.garment.label'), placeholder: t('prompt.fields.garment.placeholder') },
    { key: 'model', label: t('prompt.fields.model.label'), placeholder: t('prompt.fields.model.placeholder') },
    { key: 'pose', label: t('prompt.fields.pose.label'), placeholder: t('prompt.fields.pose.placeholder') },
    { key: 'background', label: t('prompt.fields.background.label'), placeholder: t('prompt.fields.background.placeholder') },
    { key: 'lighting', label: t('prompt.fields.lighting.label'), placeholder: t('prompt.fields.lighting.placeholder') },
    { key: 'composition', label: t('prompt.fields.composition.label'), placeholder: t('prompt.fields.composition.placeholder') },
    { key: 'colour', label: t('prompt.fields.colour.label'), placeholder: t('prompt.fields.colour.placeholder') },
    { key: 'negative', label: t('prompt.fields.negative.label'), placeholder: t('prompt.fields.negative.placeholder') },
  ];

  async function generate() {
    if (busy) return;
    if (!parts.idea.trim() && !parts.garment.trim() && !edited) { setGenError('prompt.error.emptyFields'); return; }
    if (!final.trim()) { setGenError('prompt.error.emptyFinal'); return; }
    setGenError(''); setBusy(true);
    const id = requestId ?? crypto.randomUUID(); setRequestId(id);
    try { const r = await generatePrompt({ data: { requestId: id, prompt: final.trim() } }); setOutcome(r); setRequestId(null); }
    catch { setGenError('prompt.error.serverUnreachable'); }
    finally { setBusy(false); void refreshAccount(); void qc.invalidateQueries({ queryKey: ['credit-history'] }); }
  }
  function flash(m: Key) { setNote(m); setTimeout(() => setNote(''), 2000); }
  async function copy() { try { await navigator.clipboard.writeText(final); flash('prompt.note.copied'); } catch { flash('prompt.note.copyFailed'); } }

  const reasonMap: Record<string, string> = {
    [PROMPT_NOT_CONNECTED]: t('prompt.error.notConnected'),
    'Prompt generation failed. Your credit was returned.': t('prompt.error.failed'),
    'Empty result. Your credit was returned.': t('prompt.error.empty'),
  };

  return <div className="tool-layout"><main className="workspace-main">
    <div className="eyebrow mb-1">{t('prompt.title')}</div><h1 className="page-title">{t('prompt.pageTitle')}</h1>
    <p className="text-sm text-muted-foreground mt-2">{t('prompt.description')}</p>
    <div className="grid sm:grid-cols-2 gap-4 mt-6">{fields.map(f => <div key={f.key} className={f.key === 'idea' || f.key === 'negative' ? 'sm:col-span-2' : ''}><label htmlFor={`p-${f.key}`}>{f.label}</label><textarea id={`p-${f.key}`} rows={f.rows ?? 2} placeholder={f.placeholder} value={parts[f.key]} onChange={e => { setParts({ ...parts, [f.key]: e.target.value }); setEdited(false); }} /></div>)}</div>
    <div className="flex flex-wrap gap-2 mt-5"><Button type="button" variant="outline" onClick={() => { setParts(demoEnhance(parts)); setEdited(false); flash('prompt.note.enhanced'); }}><Wand2 /> {t('prompt.enhanceDemo')}</Button><Button type="button" variant="ghost" onClick={() => { setParts(emptyPrompt); setEdited(false); }}><Eraser /> {t('prompt.clear')}</Button></div>
    <section className="output-panel mt-6"><div className="flex justify-between items-center mb-3"><label htmlFor="final-prompt" className="mb-0 text-foreground text-sm font-semibold">{t('prompt.finalLabel')}</label>{edited && <span className="pill">{t('prompt.editedByYou')}</span>}</div>
      <textarea id="final-prompt" rows={8} value={final} onChange={e => { setFinal(e.target.value); setEdited(true); }} />
      <div className="grid grid-cols-2 gap-2 mt-3"><Button onClick={copy}><Copy /> {t('prompt.copy')}</Button><Button variant="outline" onClick={() => { savePrompt({ id: crypto.randomUUID(), name: parts.idea.trim().slice(0, 40) || t('prompt.untitledPreset'), parts, final }); flash('prompt.note.saved'); }}><Save /> {t('prompt.savePreset')}</Button></div>
      {note && <p role="status" className="flex gap-2 items-center text-xs text-success mt-3"><CheckCircle2 size={14} />{t(note)}</p>}
      <div className="flex justify-between items-center mt-4 text-[11px] text-muted-foreground"><span>{t('prompt.costNote', { planType: isPro ? t('prompt.proPlanCredits') : t('prompt.freeWeeklyCredits') })}</span><span className="pill">{t('prompt.demoNoService')}</span></div>
      <p className="text-xs mt-2">{t('prompt.creditsAvailable', { credits: credits === null ? t('prompt.history.loading') : credits })}{account && !isPro && account.freeResetsAt ? t('prompt.resetsAt', { date: formatLagos(account.freeResetsAt, locale) ?? '' }) : ''}</p>
      <Button type="button" size="lg" className="w-full mt-3 h-12 text-base" disabled={busy || !account || credits === 0} onClick={generate}>{busy ? <Loader2 className="animate-spin" /> : <Sparkles />} {busy ? t('prompt.generating') : t('prompt.generateWithCost')}</Button>
      {credits === 0 && <p className="text-[11px] text-muted-foreground mt-2"><Lock size={12} className="inline me-1 text-primary" />{t('prompt.noCreditsLeft')}{!isPro && <>{t('prompt.freeCreditsRenew')}<Link to="/pricing" className="text-primary">{t('prompt.seeProPlans')}</Link></>}</p>}
      {genError && <p role="alert" className="text-xs text-destructive mt-2">{t(genError)}</p>}
      <div aria-live="polite">
        {outcome?.status === 'generated' && <div className="mt-3"><p className="text-xs text-success">{t('prompt.outcome.generated')}</p><textarea readOnly rows={6} value={outcome.text} aria-label={t('prompt.pageTitle')} /></div>}
        {outcome?.status === 'failed_refunded' && <p role="alert" className="flex gap-2 items-center text-xs text-muted-foreground mt-3"><AlertTriangle size={14} />{reasonMap[outcome.reason] || outcome.reason}</p>}
        {outcome?.status === 'insufficient_credits' && <p role="alert" className="text-xs text-destructive mt-3">{t('prompt.outcome.insufficient')}</p>}
        {outcome?.status === 'duplicate' && <p className="text-xs text-muted-foreground mt-3">{t('prompt.outcome.duplicate')}</p>}
      </div>
    </section>
  </main>
    <aside className="right-panel"><h2 className="section-title mb-3">{t('prompt.history.title')}</h2>
      {history.isError ? <p className="text-[11px] text-destructive mb-5">{t('prompt.history.error')}</p> : !history.data ? <p className="text-[11px] text-muted-foreground mb-5">{t('prompt.history.loading')}</p> : history.data.length ? <ul className="space-y-1 mb-5 text-[11px]">{history.data.map(h => <li key={h.id} className="flex justify-between gap-2"><span>{t(h.reason.startsWith('generation_reserved:') ? 'prompt.history.reserved' : h.reason.startsWith('generation_refund:') ? 'prompt.history.refund' : h.reason === 'free_weekly_reset' ? 'prompt.history.reset' : 'prompt.history.activity')}</span><span dir="ltr" className={`shrink-0 ${h.delta > 0 ? 'text-success' : ''}`}>{h.delta > 0 ? '+' : ''}{h.delta}</span></li>)}</ul> : <p className="text-[11px] text-muted-foreground mb-5">{t('prompt.history.empty')}</p>}
      <h2 className="section-title mb-4">{t('prompt.presets.title')}</h2>
      {savedPrompts.length ? <ul className="space-y-2">{savedPrompts.map(p => <li key={p.id} className="flex items-center gap-2 border border-border rounded-md p-2"><button type="button" className="text-start text-xs flex-1 min-w-0 truncate" onClick={() => { setParts(p.parts); setFinal(p.final); setEdited(p.final !== buildPrompt(p.parts)); }}>{p.name}</button><Button variant="ghost" size="icon" aria-label={t('prompt.presets.deleteAria', { name: p.name })} onClick={() => removePrompt(p.id)}><Trash2 /></Button></li>)}</ul> : <p className="text-[11px] text-muted-foreground">{t('prompt.presets.empty')}</p>}
    </aside></div>;
}
