import { useAccount } from '@/lib/use-account';
import { CreditPanel } from './credit-panel';
import { Link } from '@tanstack/react-router';
import { useState } from 'react';
import { ArrowUpRight, ArrowRight, Sparkles, SlidersHorizontal, Image, Layers, Download, ShieldCheck, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { tools } from '@/lib/studio-tools';
import { toolThumbnails } from '@/lib/tool-thumbnails';
import { workflowVisuals } from '@/lib/workflow-visuals';
import { AdSlot } from './ad-slot';
import { StudioImage } from './studio-image';
import { Camera, Video, Crown, PenLine } from 'lucide-react';
import { ToolIcon } from './tool-icon';
import { samples, useStudio } from './studio-context';
import type { Key } from '@/lib/i18n';
import { Ratio, Aperture } from 'lucide-react';

export function Dashboard() {
  const { name, outputs, downloads, savedPrompts, t } = useStudio();
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('All tools');
  const { data: account } = useAccount();
  const [preview, setPreview] = useState<number | null>(null);
  const [style, setStyle] = useState('Editorial');
  const [ratio, setRatio] = useState('3:4');

  const base = filter === 'Featured' && !q ? tools.slice(0, 6) : filter === 'All tools' || filter === 'Featured' ? tools : tools.filter(t => t.category === filter);
  const visible = base.filter(x => t(`tool.${x.id}.title` as Key).toLowerCase().includes(q.toLowerCase()));

  return <div className="page-layout">
    <main className="workspace-main">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
        <div className="min-w-0">
          <div className="eyebrow mb-2">{t('dash.workspaceEyebrow')}</div>
          <h1 className="page-title">{t('welcome')}, {name}<span className="text-primary">.</span></h1>
          <p className="dashboard-demo-note"><strong>{t('ws.demoModeLabel')}</strong> {t('ws.demoModeNotice')}</p>
        </div>
        <Sparkles className="text-primary hidden sm:block" size={25} />
      </div>

      <section className="hero-banner">
        <div className="hero-copy">
          <div className="eyebrow">GILDED FASHION FORGE</div>
          <h2>OBITREND AI<br />CREATOR STUDIO</h2>
          <p className="hero-subtitle">{t('workflowTitle')}</p>
          <Button asChild className="mt-5"><Link to="/prompt-studio">{t('promptStudio')} <ArrowUpRight /></Link></Button>
        </div>
        <StudioImage src={workflowVisuals.hero} alt="Fashion collage: curvy model in black, lavender, white, navy and beige tops with grey jeans in luxury settings" width={1066} height={1280} fetchPriority="high" />
        <div className="hero-details">
          <div className="hero-stages">{(['uploadStep', 'sceneStep', 'campaignStep'] as const).map((key, i) => <span key={key}><strong>0{i + 1}</strong> {t(key)}</span>)}</div>
          <div className="sample-label hero-demo">{t('illustration')}</div>
          <p className="text-xs text-muted-foreground leading-5 mt-2">{t('fidelityNote')}</p>
          <Button asChild className="mt-4 h-11">
            <Link to="/tools/$toolId" params={{ toolId: 'fashion-image' }}>{t('startCreating')} <ArrowUpRight /></Link>
          </Button>
        </div>
      </section>

      <AdSlot id="dashboard" className="mb-6" />

      <div className="stat-grid">{[
        { label: t('dash.demoCreations'), value: outputs.length, icon: Image },
        { label: t('dash.creativeTools'), value: 20, icon: Layers },
        { label: t('downloads'), value: downloads.length, icon: Download }
      ].map(s => (
        <div className="stat" key={s.label}>
          <div className="flex items-center justify-between gap-2 text-muted-foreground">
            <span className="text-[10px]">{s.label}</span>
            <s.icon size={14} className="text-primary shrink-0" />
          </div>
          <strong>{String(s.value).padStart(2, '0')}</strong>
        </div>
      ))}</div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-7">{[
        { to: '/prompt-studio' as const, k: 'promptStudio' as const, i: PenLine },
        { to: '/cameras' as const, k: 'cameras' as const, i: Camera },
        { to: '/video' as const, k: 'video' as const, i: Video },
        { to: '/pricing' as const, k: 'pricing' as const, i: Crown }
      ].map(x => (
        <Link key={x.to} to={x.to} className={`camera-card flex items-center gap-2 text-xs font-medium ${x.to === '/cameras' ? 'camera-dashboard-link' : ''}`}>
          <x.i size={16} className={x.to === '/video' ? 'text-violet' : 'text-primary'} />
          {t(x.k)}
        </Link>
      ))}</div>

      <div className="flex justify-between items-center mb-4">
        <h2 className="section-title">{t('dash.exploreTools')}</h2>
        <span className="pill">{t('dash.toolsCount')}</span>
      </div>

      <div className="tool-filters flex gap-1 mb-4 overflow-x-auto">
        {['Featured', 'All tools', 'Create', 'Refine', 'Campaign'].map(f => {
          const label = f === 'Featured' ? t('dash.filterFeatured') : f === 'All tools' ? t('dash.filterAll') : t(f.toLowerCase() as Key);
          return <Button key={f} size="sm" aria-pressed={filter === f} variant={filter === f ? 'secondary' : 'ghost'} className={filter === f ? 'text-primary' : 'text-muted-foreground'} onClick={() => setFilter(f)}>{label}</Button>;
        })}
      </div>

      <input aria-label={t('dash.searchToolsAriaLabel' as Key)} placeholder={t('dash.searchToolsPlaceholder')} className="mb-4 text-xs" value={q} onChange={e => setQ(e.target.value)} />
      {visible.length === 0 && <p className="text-sm text-muted-foreground py-6">{t('noTools')}</p>}
      
      <div className="tool-grid">{visible.map(tool => (
        <article className="tool-card" key={tool.id}>
          <Link className="tool-card-link" to="/tools/$toolId" params={{ toolId: tool.id }}>
            <div className={`tool-card-media ${tool.id === 'editorial-studio' ? 'editorial-detail' : ''}`}>
              <StudioImage src={toolThumbnails[tool.id]?.image} alt={toolThumbnails[tool.id]?.alt ?? t(`tool.${tool.id}.title` as Key)} width={512} height={512} loading="lazy" decoding="async" />
              <span className="tool-symbol"><ToolIcon name={tool.icon} className="size-[18px]" /></span>
              {!account?.isPro && <span className="tool-popular">{t('shell.proOnly')}</span>}
            </div>
            <div className="tool-card-copy">
              <h3 className="text-xs font-semibold">{t(`tool.${tool.id}.title` as Key)}</h3>
              <p>{t(`tool.${tool.id}.description` as Key)}</p>
              <span className="text-[10px] font-medium flex items-center justify-between gap-1">
                {t('openWorkspace')} <ArrowUpRight size={13} className="text-muted-foreground shrink-0" />
              </span>
            </div>
          </Link>
        </article>
      ))}</div>

      <div className="grid sm:grid-cols-2 gap-4 mt-7">
        <section className="dashboard-journal">
          <h2 className="section-title mb-3">{t('dash.recentCreations')}</h2>
          {outputs.length ? <div className="grid grid-cols-4 gap-2">{outputs.slice(0, 4).map(o => <img key={o.id} src={o.image} alt={`${o.title} sample`} className="aspect-square object-contain rounded" />)}</div> : <p className="text-[11px] text-muted-foreground">{t('dash.noCreations')}</p>}
        </section>
        <section className="dashboard-journal">
          <h2 className="section-title mb-3">{t('dash.savedPrompts')}</h2>
          {savedPrompts.length ? <ul className="space-y-1">{savedPrompts.slice(0, 4).map(p => <li key={p.id} className="text-xs truncate">{p.name}</li>)}</ul> : <p className="text-[11px] text-muted-foreground">{t('dash.noSavedPrompts')}<Link to="/prompt-studio" className="text-primary">{t('dash.openPromptStudio')}</Link></p>}
        </section>
      </div>

      <div className="flex justify-between items-center mt-7 mb-4">
        <div>
          <h2 className="section-title">{t('examples')}</h2>
          <p className="text-[11px] text-muted-foreground mt-1">{t('exampleNote')}</p>
        </div>
        <span className="sample-label hidden sm:inline">{t('dash.illustrativeSamples')}</span>
      </div>

      <div className="image-grid">{samples.map((s, i) => (
        <article className="image-tile" key={s.title}>
          <Button variant="ghost" className="h-auto p-0 w-full" onClick={() => setPreview(i)} aria-label={`${t('dash.samplePreview')}: ${s.title}`}>
            <img src={s.image} alt={t(`dash.sample${i}.title` as Key)} loading="lazy" width={512} height={512} />
          </Button>
          <h3 className="text-[10px] font-medium mt-2">{t(`dash.sample${i}.title` as Key)}</h3>
          <p className="text-[9px] text-muted-foreground mt-1">{t(`dash.sample${i}.category` as Key)} · {t('dash.demoSample')}</p>
        </article>
      ))}</div>

      <AdSlot id="mobile" className="mt-6 md:hidden" />
      <footer className="mt-8 pt-5 border-t border-border text-[10px] text-muted-foreground flex justify-between gap-4">
        <span>OBITREND AI CREATOR STUDIO</span>
        <span>{t('dash.footerText')}</span>
      </footer>
    </main>

    <aside className="right-panel dashboard-panel" aria-label={t('dash.settingsTitle')}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-sm font-semibold">{t('dash.settingsTitle')}</h2>
        <SlidersHorizontal size={15} className="text-muted-foreground" />
      </div>
      <div className="dashboard-settings-form">
        <div className="eyebrow">{t('dash.creativeDirection')}</div>
        <div><label htmlFor="dashboard-style">{t('dash.defaultStyle')}</label>
          <select id="dashboard-style" value={style} onChange={e => setStyle(e.target.value)}>
            {['Editorial', 'Streetwear', 'Luxury', 'Minimal'].map(s => <option key={s} value={s}>{t(`dash.style${s}` as Key)}</option>)}
          </select>
        </div>
        <div><label className="camera-control-label" htmlFor="dashboard-ratio"><Ratio className="camera-label-icon" aria-hidden="true" />{t('dash.canvasRatio')}</label>
          <select id="dashboard-ratio" value={ratio} onChange={e => setRatio(e.target.value)}>
            {['3:4', '1:1', '9:16', '16:9'].map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>
      <CreditPanel compact />
      <div className="dashboard-quality">
        <label>{t('dash.outputQuality')}</label>
        <div className="text-xs border border-border rounded-md px-3 py-3 flex justify-between gap-3">
          {t('dash.demoPreview')} <span className="text-primary">{t('dash.sampleLabel')}</span>
        </div>
      </div>
      <Button className="w-full mt-5" asChild>
        <Link to="/tools/$toolId" params={{ toolId: 'fashion-image' }} search={{ style, ratio }}>
          {t('dash.newCreation')} <Sparkles />
        </Link>
      </Button>

      <div className="border-t border-border mt-7 pt-6">
        <h2 className="text-sm font-semibold mb-4 flex items-center gap-2"><Aperture className="size-4 text-primary" aria-hidden="true" />{t('cameraExample')}</h2>
        <StudioImage src={workflowVisuals.camera} alt="Illustrative full-length silver couture campaign under studio lighting" className="w-full aspect-[3/4] object-contain rounded-md" width={480} height={640} />
        <span className="sample-label block mt-3">{t('dash.cameraInspiration')}</span>
        <Button asChild variant="link" className="px-0 text-[11px]">
          <Link to="/cameras">{t('cameras')} <ArrowRight /></Link>
        </Button>
        <StudioImage src={workflowVisuals.video} alt="Illustrative streetwear campaign with a phone camera; still image, not generated video" className="w-full aspect-[3/4] object-contain mt-4 rounded-md" width={480} height={640} loading="lazy" />
        <Button asChild variant="link" className="px-0 text-[11px] text-violet">
          <Link to="/video">{t('videoExample')} <ArrowRight /></Link>
        </Button>
        <span className="sample-label block">{t('dash.stillFramesNote')}</span>
      </div>
      <div className="border-t border-border mt-5 pt-5">
        <div className="flex gap-2 items-center text-primary text-xs"><ShieldCheck size={15} /> {t('dash.yourSpaceTitle')}</div>
        <p className="text-[10px] text-muted-foreground leading-5 mt-3">{t('dash.demoActiveNote')}</p>
      </div>
    </aside>

    {preview !== null && (
      <div className="modal-backdrop" onClick={() => setPreview(null)}>
        <div role="dialog" aria-modal="true" aria-label={t('dash.samplePreview' as Key)} className="preview-modal" onClick={e => e.stopPropagation()}>
          <div className="flex justify-between mb-3 items-center">
            <span>{t(`dash.sample${preview}.title` as Key)} <span className="sample-label ms-2">{t('dash.demoSample')}</span></span>
            <Button autoFocus variant="ghost" size="icon" onClick={() => setPreview(null)} aria-label={t('dash.closePreview')}><X /></Button>
          </div>
          <img src={samples[preview]?.image} alt={t(`dash.sample${preview}.title` as Key)} />
        </div>
      </div>
    )}
  </div>;
}
