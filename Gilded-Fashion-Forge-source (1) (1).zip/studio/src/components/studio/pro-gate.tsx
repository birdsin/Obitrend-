import type { ReactNode } from 'react';
import { Link } from '@tanstack/react-router';
import { Crown, Lock, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAccount } from '@/lib/use-account';
import { useLang } from '@/lib/use-lang';

/** Renders children only for a server-verified Pro plan; everyone else gets an upgrade prompt. */
export function ProGate({ feature, children }: { feature: string; children: ReactNode }) {
  const { t } = useLang();
  const { data, isLoading, isError } = useAccount();
  if (isLoading) return <main className="workspace-main"><p className="text-xs text-muted-foreground flex gap-2 items-center"><Loader2 size={14} className="animate-spin" /> {t('pro.gate.checkingPlan')}</p></main>;
  if (data?.isPro) return <>{children}</>;
  return <main className="workspace-main max-w-xl">
    <div className="eyebrow mb-2 flex items-center gap-2"><Lock size={13} /> {t('pro.gate.proFeature')}</div>
    <h1 className="page-title">{t('pro.gate.isProTool', { feature })}</h1>
    <p className="text-sm text-muted-foreground mt-3">{isError ? t('pro.gate.error') : t('pro.gate.upgradeNote')}</p>
    <p className="text-[11px] text-muted-foreground mt-3">{t('pro.gate.notConnected')}</p>
    <div className="flex flex-wrap gap-2 mt-6">
      <Button asChild><Link to="/pricing"><Crown /> {t('pro.gate.seeProPlans')}</Link></Button>
      <Button asChild variant="outline"><Link to="/prompt-studio">{t('pro.gate.openPromptStudio')}</Link></Button>
    </div>
  </main>;
}
