import { Link, useRouterState } from '@tanstack/react-router';
import { useEffect, useState, type ReactNode } from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { useIsMobile } from '@/hooks/use-mobile';
import { LayoutDashboard, Images, Download, Settings, PanelLeftClose, PanelLeftOpen, Menu, X, ChevronDown, Sparkles, ShieldCheck, Search, PenLine, Camera, Video, Crown, Globe, LogIn, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { tools } from '@/lib/studio-tools';
import { type Key } from '@/lib/i18n';
import { ToolIcon } from './tool-icon';
import { useStudio } from './studio-context';
import { AdSlot } from './ad-slot';
import { Intro } from './intro';
import { UpgradeSuccessWatcher } from './upgrade-success';
import { useAuth } from '@/lib/use-auth';
import { useAccount } from '@/lib/use-account';
import { LanguagePicker, LanguageSuggestion, TranslationReviewNote } from './language-picker';

const groups: { id: string; key: Key }[] = [{ id: 'Create', key: 'create' }, { id: 'Refine', key: 'refine' }, { id: 'Campaign', key: 'campaign' }];
const proLinks = [{ to: '/prompt-studio' as const, key: 'promptStudio' as const, icon: PenLine }, { to: '/cameras' as const, key: 'cameras' as const, icon: Camera }, { to: '/video' as const, key: 'video' as const, icon: Video }, { to: '/pricing' as const, key: 'pricing' as const, icon: Crown }];
const utility = [{ to: '/history' as const, key: 'history' as const, icon: Images }, { to: '/downloads' as const, key: 'downloads' as const, icon: Download }, { to: '/account' as const, key: 'account' as const, icon: Settings }];

export function StudioShell({ children }: { children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false); const [mobile, setMobile] = useState(false); const [query, setQuery] = useState('');
  const [closed, setClosed] = useState<Record<string, boolean>>({});
  const isMobile = useIsMobile();
  useEffect(() => { if (!isMobile) setMobile(false); }, [isMobile]);
  const path = useRouterState({ select: s => s.location.pathname }); const { name, t, lang, setLang } = useStudio();
  const { user } = useAuth();
  const { data: account } = useAccount(); const isPro = !!account?.isPro;
  const lock = <Lock size={11} className="ms-auto shrink-0 text-muted-foreground" aria-label={t('shell.proOnly')} />;
  const wide = !collapsed || mobile; const close = () => setMobile(false);
  const item = (active: boolean) => `nav-item ${active ? 'active' : ''}`;
  const navigation = <>
      <div className="h-[76px] border-b border-border flex items-center gap-3 px-5"><span className="w-8 h-8 shrink-0 grid place-items-center border border-primary rounded-md text-primary"><Sparkles size={19} /></span>{wide && <div className="min-w-0"><div className="font-bold text-[17px]">OBITREND<span className="text-primary"> AI</span></div><div className="text-[8px] tracking-[1.8px] text-muted-foreground mt-1">CREATOR STUDIO</div></div>}<Button variant="ghost" size="icon" className="ms-auto md:hidden" onClick={close} aria-label={t("shell.closeNav" as Key)}><X /></Button></div>
      <nav className="nav-scroll">
        <Button variant="ghost" className={item(path === '/')} asChild title={t('dashboard')}><Link to="/" aria-current={path === '/' ? 'page' : undefined} onClick={close}><LayoutDashboard />{wide && t('dashboard')}</Link></Button>
        {wide && <div className="relative mt-3"><Search className="absolute start-3 top-3 text-muted-foreground" size={13} /><input aria-label={t('findTool')} placeholder={t('findTool')} className="ps-8 text-xs" value={query} onChange={e => setQuery(e.target.value)} /></div>}
        <div className="nav-group">{wide ? t('pro') : '·'}</div>
        {proLinks.map(l => <Button key={l.to} variant="ghost" asChild title={t(l.key)} className={item(path === l.to)}><Link to={l.to} aria-current={path === l.to ? 'page' : undefined} onClick={close}><l.icon className={l.to === '/video' ? 'text-violet' : ''} />{wide && <span className="truncate">{t(l.key)}</span>}{wide && !isPro && l.to === '/video' && lock}</Link></Button>)}
        {groups.map(g => { const list = tools.filter(x => x.category === g.id && t(`tool.${x.id}.title` as Key).toLowerCase().includes(query.toLowerCase())); const open = !closed[g.id] || !!query || list.some(x => path === `/tools/${x.id}`); return <div key={g.id}>
          {wide ? <Button variant="ghost" type="button" className="nav-group nav-group-btn" aria-expanded={open} onClick={() => setClosed(c => ({ ...c, [g.id]: open }))}>{t(g.key)} <ChevronDown size={12} className={open ? '' : '-rotate-90'} /></Button> : <div className="nav-group">·</div>}
          {(open || !wide) && list.map(x => <Button variant="ghost" asChild key={x.id} title={t(`tool.${x.id}.title` as Key)} className={item(path === `/tools/${x.id}`)}><Link to="/tools/$toolId" params={{ toolId: x.id }} aria-current={path === `/tools/${x.id}` ? 'page' : undefined} onClick={close}><ToolIcon name={x.icon} />{wide && <span className="truncate">{t(`tool.${x.id}.title` as Key)}</span>}{wide && !isPro && lock}</Link></Button>)}
        </div>; })}
        <div className="nav-group">{wide ? t('workspace') : '·'}</div>
        {utility.map(l => <Button key={l.to} asChild variant="ghost" title={t(l.key)} className={item(path === l.to)}><Link to={l.to} aria-current={path === l.to ? 'page' : undefined} onClick={close}><l.icon />{wide && t(l.key)}</Link></Button>)}
        {wide && <AdSlot id="sidebar" className="mt-4 hidden md:block" />}
      </nav>
      <div className="border-t border-border p-3">
        <Button variant="ghost" size={collapsed ? 'icon' : 'default'} className="hidden md:flex w-full justify-start text-muted-foreground" onClick={() => setCollapsed(!collapsed)} title={t('collapse')}>
          {collapsed ? <PanelLeftOpen /> : <PanelLeftClose />}
          {!collapsed && <span className="text-xs">{t('collapse')}</span>}
        </Button>
        {wide && (user ? (
          <Link to="/account" className="flex gap-3 items-center p-2 mt-2 rounded-md hover:bg-accent">
            <span className="w-8 h-8 rounded-full bg-accent text-primary grid place-items-center text-xs">{(user.email ?? 'T').slice(0, 2).toUpperCase()}</span>
            <div className="min-w-0">
              <div className="text-xs font-medium truncate">{user.email}</div>
              <div className="text-[10px] text-muted-foreground mt-1">{isPro ? t('shell.proLabel') : t('shell.freeLabel')} · {t('shell.testLabel')}</div>
            </div>
          </Link>
        ) : (
          <Link to="/auth" className="flex gap-3 items-center p-2 mt-2 rounded-md hover:bg-accent">
            <span className="w-8 h-8 rounded-full bg-accent text-primary grid place-items-center text-xs"><LogIn size={14} /></span>
            <div>
              <div className="text-xs font-medium">{t('shell.signIn')}</div>
              <div className="text-[10px] text-muted-foreground mt-1">{t('shell.testAccountsNote')}</div>
            </div>
          </Link>
        ))}
        {wide && <div className="mt-2 px-2"><TranslationReviewNote /></div>}
      </div>
  </>;
  return <Dialog.Root open={mobile && isMobile} onOpenChange={setMobile}><div className={`studio-shell ${collapsed ? 'collapsed' : ''}`}>
    <aside className="nav-sidebar desktop-navigation" aria-label={t('shell.navAriaLabel')}>{!isMobile && navigation}</aside>
    <Dialog.Portal>
      <Dialog.Overlay className="mobile-scrim" />
      <Dialog.Content className="nav-sidebar mobile-navigation mobile-open" aria-describedby={undefined}>
        <Dialog.Title className="sr-only">{t('shell.navAriaLabel')}</Dialog.Title>
        {isMobile && navigation}
      </Dialog.Content>
    </Dialog.Portal>
    <div className="min-w-0">
      <header className="topbar">
        <div className="flex items-center min-w-0 gap-3">
          <Dialog.Trigger asChild><Button className="md:hidden" variant="ghost" size="icon" aria-label={t("shell.openNav" as Key)}><Menu /></Button></Dialog.Trigger>
          <span className="text-xs font-medium truncate">{t('shell.creatorStudio')}</span>
        </div>
        <div className="flex shrink-0 items-center gap-2 sm:gap-4">
          <div className="hidden sm:block"><LanguagePicker /></div>
          <div className="sm:hidden"><LanguagePicker compact /></div>
          <span className="pill text-primary"><span className="gold-dot" /> {t('demoMode')}</span>
          <ShieldCheck size={16} className="text-muted-foreground hidden sm:block" />
          <Button asChild variant="ghost" size="icon" title={t('account')}>
            <Link to="/account"><span className="w-8 h-8 rounded-full bg-accent text-primary grid place-items-center text-xs">{name.slice(0, 2).toUpperCase()}</span></Link>
          </Button>
        </div>
      </header>
      <LanguageSuggestion />
      <Intro />
      <UpgradeSuccessWatcher />
      {children}
    </div>
  </div></Dialog.Root>;
}
