import { useState } from 'react';
import { Download, FileDown, Images, ArrowRight, Search } from 'lucide-react';
import { Link } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { AdSlot } from './ad-slot';
import { useStudio, exportBrief, type DemoOutput } from './studio-context';
import type { Key } from '@/lib/i18n';

export function StudioLibrary({ mode }: { mode: 'history' | 'downloads' }) {
  const { outputs, downloads, download, jobs, t } = useStudio();
  const pending = mode === 'history' ? jobs.filter(j => j.status !== 'completed') : [];
  const [query, setQuery] = useState('');
  const [error, setError] = useState<Key | ''>('');
  const [busy, setBusy] = useState<string | null>(null);

  const list = (mode === 'history' ? outputs : downloads).filter(o => `${o.title} ${o.prompt}`.toLowerCase().includes(query.toLowerCase()));

  async function save(o: DemoOutput) {
    setBusy(o.id); setError('');
    try { await download(o); } catch { setError('lib.downloadError'); } finally { setBusy(null); }
  }

  return <main className="workspace-main">
    <div className="eyebrow mb-2">{t('lib.yourWorkspace' as Key)}</div>
    <h1 className="page-title">{t(mode as Key)}</h1>
    <p className="text-muted-foreground text-xs mt-3">
      {mode === 'history' ? t('lib.historyNote' as Key) : t('lib.downloadsNote' as Key)} {mode === 'history' ? t('lib.storageNote' as Key) : t('lib.sessionNote' as Key)}
    </p>
    <div className="relative max-w-sm mt-6 mb-6">
      <Search size={15} className="absolute start-3 top-3 text-muted-foreground" />
      <input className="ps-9" aria-label={t('lib.searchAriaLabel' as Key)} placeholder={t('lib.searchPlaceholder' as Key)} value={query} onChange={e => setQuery(e.target.value)} />
    </div>
    {error && <p className="text-destructive mb-4" role="alert">{t(error)}</p>}
    {pending.length > 0 && <section className="mb-6" aria-label={t('lib.trackedJobs' as Key)}>
      <h2 className="section-title mb-2">{t('lib.trackedJobs' as Key)}</h2>
      <ul className="space-y-2">{pending.map(j => <li key={j.id} className="flex items-center justify-between gap-3 text-xs border border-border rounded-md p-3"><span className="truncate">{j.config.title} · {j.status === 'processing' ? t('lib.preparingSample' as Key) : t('lib.failed' as Key)}</span><Link className="text-primary shrink-0" to="/tools/$toolId" params={{ toolId: j.config.toolId }}>{t('lib.open' as Key)}</Link></li>)}</ul>
    </section>}
    <AdSlot id="gallery" className="mb-6" />
    {list.length ? <div className="image-grid">{list.map((o, i) => (
      <article className="image-tile" key={`${o.id}-${i}`}>
        <img src={o.image} alt={`${o.title} demo sample`} width={768} height={1024} />
        <div className="sample-label mt-3">{t('lib.preMadeSample' as Key)}</div>
        <h2 className="text-sm font-semibold mt-2">{o.title}</h2>
        <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{o.prompt}</p>
        <div className="flex gap-2 mt-3">
          <Button variant="outline" size="sm" disabled={busy === o.id} onClick={() => save(o)}><Download /> {t('lib.sample' as Key)}</Button>
          <Button variant="ghost" size="icon" title={t('lib.exportBrief' as Key)} onClick={() => exportBrief(o)}><FileDown /></Button>
        </div>
      </article>
    ))}</div> : <div className="output-empty mt-10">
      <Images size={35} className="text-primary" />
      <h2 className="section-title">{query ? t('lib.noMatchingCreations' as Key) : t('lib.freshCanvas')}</h2>
      <p className="text-muted-foreground text-xs">{query ? t('lib.tryDifferentSearch' as Key) : t('lib.createDemoPreview' as Key)}</p>
      <Button asChild>
        <Link to="/tools/$toolId" params={{ toolId: 'fashion-image' }}>{t('lib.openFashionCreator' as Key)} <ArrowRight /></Link>
      </Button>
    </div>}
  </main>;
}
