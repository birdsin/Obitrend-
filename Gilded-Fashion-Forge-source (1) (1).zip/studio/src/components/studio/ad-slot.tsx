import { adSlots, type AdSlotId } from '@/lib/ad-slots';
import { canRenderAdSlot } from '@/lib/ad-visibility';
import { useAccount } from '@/lib/use-account';
import { useStudio } from './studio-context';
import type { Key } from '@/lib/i18n';

/** Renders a labelled ad container only for a server-confirmed Free plan in an enabled slot.
 *  Pro, loading or unknown plans render nothing (no reserved gap). Never rewards the viewer. */
export function AdSlot({ id, className = '' }: { id: AdSlotId; className?: string }) {
  const { t } = useStudio();
  const { data, isSuccess } = useAccount();
  if (!canRenderAdSlot(id, { loaded: isSuccess, isPro: !!data?.isPro })) return null;
  return <aside data-ad-slot={id} aria-label={t('shell.advertisement' as Key)} className={`ad-slot ${className}`} style={{ minHeight: adSlots[id].minHeight }}><span className="sample-label">{t('shell.advertisement' as Key)}</span></aside>;
}
