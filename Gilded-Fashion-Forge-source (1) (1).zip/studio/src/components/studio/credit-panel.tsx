import { useEffect, useState } from 'react';
import { Link } from '@tanstack/react-router';
import { RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAccount } from '@/lib/use-account';
import { countdown, formatLagos, spendableCredits } from '@/lib/lagos-time';
import { planById, type PlanId } from '@/lib/plans';
import { useLang } from '@/lib/use-lang';
import type { Key } from '@/lib/i18n';

/** Live account credits. All numbers and dates come from the server; only the countdown ticks locally. */
export function CreditPanel({ compact = false }: { compact?: boolean }) {
  const { t, locale } = useLang();
  const { data: a, isError, isFetching, refetch } = useAccount();
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => { const id = setInterval(() => setNow(Date.now()), 30_000); return () => clearInterval(id); }, []);
  // When the free reset moment passes, ask the server (it decides whether credits renew).
  useEffect(() => { if (a && !a.isPro && a.freeResetsAt && new Date(a.freeResetsAt).getTime() <= now) void refetch(); }, [a, now, refetch]);

  const row = (k: string, v: React.ReactNode, detail = false) => <div className={`credit-row${detail ? ' credit-row-detail' : ''}`}><dt className="text-muted-foreground">{k}</dt><dd dir="ltr">{v}</dd></div>;
  const plan = a?.entitlement ? planById(a.entitlement.planId as PlanId) : null;
  const proExpiry = a?.isPro ? formatLagos(a.entitlement?.expiresAt, locale) : null;
  const freeReset = a && !a.isPro ? formatLagos(a.freeResetsAt, locale) : null;

  return <section className={`credit-panel ${compact ? 'border border-border rounded-md p-3 mb-5 text-[11px]' : 'form-section mt-4'}`} aria-label={t('cred.panelAria')} aria-busy={isFetching}>
    <div className="flex justify-between items-center mb-3">
      <h2 className={compact ? 'text-xs font-semibold' : 'section-title'}>{t('cred.title')}</h2>
      <Button variant="ghost" size="icon" aria-label={t('cred.refreshAria')} onClick={() => refetch()} disabled={isFetching}><RefreshCw className={isFetching ? 'animate-spin' : ''} /></Button>
    </div>
    {isError && <div role="alert" className="text-destructive text-xs">{t('cred.error')} <Button variant="outline" size="sm" className="ms-2" onClick={() => refetch()} disabled={isFetching}>{t('cred.retry')}</Button></div>}
    {!a && !isError && <p className="text-muted-foreground text-xs">{t('cred.loading')}</p>}
    {a && <dl className="space-y-2 text-xs">
      {row(t('cred.spendableImage'), String(spendableCredits(a)))}
      {row(t('cred.planStatus'), a.isPro ? t('cred.proPlan', { name: plan ? t(`pro.plans.${plan.id}.name` as Key) : '' }) : t('cred.free'))}
      {!a.isPro && row(t('cred.freeWeekly'), t('cred.freeOf', { n: a.freeImageCredits }))}
      {a.isPro && row(t('cred.proPlanCredits'), String(a.imageCredits))}
      {row(t('cred.videoCredits'), String(a.videoCredits))}
      {!a.isPro && row(t('cred.nextFreeReset'), freeReset ? t('cred.inCountdown', { date: freeReset, countdown: countdown(a.freeResetsAt, now, t) ?? '' }) : t('cred.notScheduled'), true)}
      {a.isPro && row(t('cred.proExpires'), proExpiry ? t('cred.inCountdown', { date: proExpiry, countdown: countdown(a.entitlement?.expiresAt, now, t) ?? '' }) : t('cred.noExpiry'), true)}
      {row(t('cred.lastUpdated'), formatLagos(a.fetchedAt, locale) ?? '—', true)}
    </dl>}
    <p className="text-[10px] text-muted-foreground mt-3">{t('cred.demoModeNote')}</p>
    {a && !a.isPro && <Link to="/pricing" className="text-primary text-[11px] block mt-2">{t('cred.seeProPlans')}</Link>}
  </section>;
}
