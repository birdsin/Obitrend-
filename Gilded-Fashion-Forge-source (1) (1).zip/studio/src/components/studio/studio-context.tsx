import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { JOBS_STORAGE_KEY, activeJobFor, addJob, advanceAll, createJob, canRetry, interruptStale, parseJobs, type GenerationJob, type JobConfig } from '@/lib/demo-jobs';
import { demoSamples } from '@/lib/workflow-visuals';
import { type Key, type Lang, type Vars } from '@/lib/i18n';
import { useLang } from '@/lib/use-lang';
import { defaultCamera, type CameraSettings, type PromptParts } from '@/lib/studio-options';
import { useRefreshAccount } from '@/lib/use-account';
export type ToolState = { prompt: string; direction: string; fields: Record<string,string>; camera: CameraSettings };
export type SavedPrompt = { id: string; name: string; parts: PromptParts; final: string };
/** In-memory only (never persisted): keeps prompt-studio inputs across sidebar navigation. */
export type PromptDraft = { parts: PromptParts; final: string; edited: boolean };
export const samples = demoSamples;
export type DemoOutput = { id: string; tool: string; title: string; prompt: string; image: string; created: string; settings: Record<string, string> };
type StudioState = { outputs: DemoOutput[]; jobs: GenerationJob[]; jobsRestored: boolean; startJob: (config: JobConfig) => GenerationJob; retryJob: (id: string) => GenerationJob | null; downloads: DemoOutput[]; download: (output: DemoOutput) => Promise<void>; name: string; setName: (name: string) => void; toolState: Record<string, ToolState>; saveToolState: (id: string, state: ToolState) => void; savedPrompts: SavedPrompt[]; savePrompt: (p: SavedPrompt) => void; removePrompt: (id: string) => void; promptDraft: PromptDraft | null; setPromptDraft: (d: PromptDraft) => void; lang: Lang; setLang: (l: Lang) => void; t: (k: Key, vars?: Vars) => string; locale: string };
export function initialToolState(direction: string): ToolState { return { prompt: '', direction, fields: {}, camera: defaultCamera }; }
const StudioContext = createContext<StudioState | null>(null);
export function StudioProvider({ children, userId }: { children: ReactNode; userId: string }) {
  // Jobs are scoped per account so a different sign-in never sees another person's history.
  const storageKey = `${JOBS_STORAGE_KEY}:${userId}`;
  const [jobs, setJobs] = useState<GenerationJob[]>([]);
  const [jobsRestored, setJobsRestored] = useState(false);
  const jobsRef = useRef<GenerationJob[]>([]);
  const commit = useCallback((next: GenerationJob[]) => { if (next === jobsRef.current) return; jobsRef.current = next; setJobs(next); try { localStorage.setItem(storageKey, JSON.stringify(next)); } catch { /* storage full/blocked: in-memory only */ } }, [storageKey]);
  // Restore on open/reload. A job still "processing" was abandoned when the page went
  // away (the demo runner only exists in the open page), so it is marked interrupted
  // and offered for resume — never silently completed.
  useEffect(() => { let stored: GenerationJob[] = []; try { stored = parseJobs(localStorage.getItem(storageKey)); } catch { /* blocked */ } jobsRef.current = stored; setJobs(stored); commit(interruptStale(stored, Date.now())); setJobsRestored(true); }, [commit]);
  const hasProcessing = jobs.some(j => j.status === 'processing');
  useEffect(() => {
    if (!hasProcessing) return;
    const tick = () => commit(advanceAll(jobsRef.current, Date.now()));
    const id = setInterval(tick, 250);
    const onVis = () => { if (!document.hidden) tick(); };
    document.addEventListener('visibilitychange', onVis);
    return () => { clearInterval(id); document.removeEventListener('visibilitychange', onVis); };
  }, [hasProcessing, commit]);
  const startJob = useCallback((config: JobConfig) => { const existing = activeJobFor(jobsRef.current, config.toolId); if (existing) return existing; const job = createJob(config, Date.now(), crypto.randomUUID()); commit(addJob(jobsRef.current, job)); return job; }, [commit]);
  const retryJob = useCallback((id: string) => { const old = jobsRef.current.find(j => j.id === id); if (!old || !canRetry(old)) return null; const existing = activeJobFor(jobsRef.current, old.config.toolId); if (existing) return existing; const job = createJob(old.config, Date.now(), crypto.randomUUID(), old.id); commit(addJob(jobsRef.current, job)); return job; }, [commit]);
  const outputs = useMemo(() => jobs.filter(j => j.status === 'completed' && j.result).map(jobToOutput), [jobs]);
  // Re-read server balances whenever a job settles (completed or failed → possible charge/refund).
  const refreshAccount = useRefreshAccount();
  const settledCount = jobs.filter(j => j.status !== 'processing').length;
  const firstSettle = useRef(true);
  useEffect(() => { if (firstSettle.current) { firstSettle.current = false; return; } void refreshAccount(); }, [settledCount]); // eslint-disable-line react-hooks/exhaustive-deps
  const [downloads, setDownloads] = useState<DemoOutput[]>([]);
  const [name, setName] = useState('Promise');
  const [toolState, setToolState] = useState<Record<string, ToolState>>({});
  const { lang, setLang, t, locale } = useLang();
  const [savedPrompts, setSavedPrompts] = useState<SavedPrompt[]>([]);
  const [promptDraft, setPromptDraft] = useState<PromptDraft | null>(null);
  async function download(output: DemoOutput) {
    const response = await fetch(output.image);
    if (!response.ok) throw new Error(t('ws.downloadFailed'));
    const url = URL.createObjectURL(await response.blob());
    const a = document.createElement('a'); a.href = url; a.download = `OBITREND-DEMO-${output.tool}.jpg`; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000); setDownloads(prev => [output, ...prev]);
  }
  return <StudioContext.Provider value={{outputs, jobs, jobsRestored, startJob, retryJob, downloads, download, name, setName, toolState, saveToolState: (id, st) => setToolState(prev => ({...prev, [id]: st})), savedPrompts, promptDraft, setPromptDraft, savePrompt: p => setSavedPrompts(prev => [p, ...prev]), lang, setLang, t, locale, removePrompt: id => setSavedPrompts(prev => prev.filter(x => x.id !== id))}}>{children}</StudioContext.Provider>;
}
export function useStudio() { const state = useContext(StudioContext); if (!state) throw new Error('StudioProvider is required'); return state; }
export function exportBrief(output: DemoOutput, t?: (k: Key) => string) {
  const blob = new Blob([JSON.stringify({ mode: t ? t('ws.exportBriefMode') : 'DEMO — pre-made sample, not AI-generated from input', ...output, image: undefined }, null, 2)], {type: 'application/json'});
  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `OBITREND-DEMO-${output.tool}-brief.json`; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function jobToOutput(j: GenerationJob): DemoOutput {
  const sample = samples[j.result?.sampleIndex ?? j.config.sampleIndex] ?? samples[0];
  return { id: j.id, tool: j.config.toolId, title: j.config.title, prompt: j.config.prompt, image: sample.image, created: new Date(j.completedAt ?? j.createdAt).toISOString(), settings: j.config.settings };
}
