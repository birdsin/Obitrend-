import { useEffect, useState } from 'react';
import { Sparkles } from 'lucide-react';
import { useLang } from '@/lib/use-lang';
import type { Key } from '@/lib/i18n';

export const splashSessionKey = 'obitrend-splash-v1';

/** Lightweight startup screen: one short CSS fade/shine (opacity/transform only),
 *  shown once per browser session. Reduced-motion users get a static frame. */
export function Splash({ onDone }: { onDone: () => void }) {
  const [leaving, setLeaving] = useState(false);
  const { t } = useLang();
  useEffect(() => {
    const t1 = setTimeout(() => setLeaving(true), 1500);
    const t2 = setTimeout(onDone, 1900);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [onDone]);
  return <div className={`splash-screen ${leaving ? 'leaving' : ''}`} role="status" aria-label={t('shell.loadingSplash' as Key)}>
    <div className="splash-mark"><Sparkles size={30} /></div>
    <div className="splash-word">OBITREND<span className="text-primary"> AI</span></div>
    <div className="splash-sub">CREATOR STUDIO</div>
    <div className="splash-line" />
  </div>;
}

export function useSplashOnce(): [boolean, () => void] {
  const [show, setShow] = useState(false);
  useEffect(() => {
    try { if (!sessionStorage.getItem(splashSessionKey)) { sessionStorage.setItem(splashSessionKey, '1'); setShow(true); } } catch { /* storage blocked */ }
  }, []);
  return [show, () => setShow(false)];
}
