import { useEffect, useRef, useState, type FormEvent } from 'react';
import { AlertCircle, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLang } from '@/lib/use-lang';
import type { Key, Vars } from '@/lib/i18n';

export type AuthMode = 'sign-in' | 'sign-up';
type Result = { notice?: Key } | void;
type Props = {
  onSubmit: (mode: AuthMode, email: string, password: string) => Promise<Result>;
  onGoogle: () => Promise<void>;
};

const draft = { mode: 'sign-in' as AuthMode, email: '', password: '' };
export function resetAuthDraft() { draft.mode = 'sign-in'; draft.email = ''; draft.password = ''; }

export function AuthForm({ onSubmit, onGoogle }: Props) {
  const { t } = useLang();
  const [hydrated, setHydrated] = useState(false);
  const [mode, setModeState] = useState<AuthMode>(draft.mode);
  const [email, setEmailState] = useState(draft.email);
  const [password, setPasswordState] = useState(draft.password);
  const setMode = (v: AuthMode) => { draft.mode = v; setModeState(v); };
  const setEmail = (v: string) => { draft.email = v; setEmailState(v); };
  const setPassword = (v: string) => { draft.password = v; setPasswordState(v); };
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<Key | ''>('');
  const [errorVars, setErrorVars] = useState<Vars>({});
  const [notice, setNotice] = useState<Key | ''>('');
  const inFlight = useRef(false);
  useEffect(() => setHydrated(true), []);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (inFlight.current) return;
    setError(''); setNotice('');
    if (!email.trim() || !password) { setError('auth.errorMissing'); return; }
    inFlight.current = true; setBusy(true);
    try { 
      const r = await onSubmit(mode, email.trim(), password); 
      draft.password = ''; 
      if (r && r.notice) setNotice(r.notice); else resetAuthDraft(); 
    }
    catch (err: unknown) {
      const code = err && typeof err === 'object' && 'code' in err ? err.code : err instanceof Error ? err.message : undefined;
      if (code === 'invalid_credentials' || code === 'Invalid login credentials') setError('auth.err.invalid_credentials');
      else if (code === 'email_not_confirmed') setError('auth.err.email_not_confirmed');
      else if (code === 'user_already_exists') setError('auth.err.user_already_exists');
      else { setError('auth.errorGeneric'); setErrorVars({}); }
    }
    finally { inFlight.current = false; setBusy(false); }
  }

  const off = !hydrated;
  return <>
    <h1 className="page-title">{mode === 'sign-in' ? t('auth.signIn') : t('auth.signUp')}</h1>
    <p className="text-sm text-muted-foreground mt-3">{t('auth.description')}</p>
    <form className="form-section mt-5" method="post" action="#" noValidate onSubmit={submit} aria-busy={busy}>
      <label htmlFor="auth-email">{t('auth.email')}</label>
      <input id="auth-email" name="email" type="email" inputMode="email" autoCapitalize="none" autoCorrect="off" spellCheck={false} autoComplete="email" disabled={off} value={email} onChange={e => setEmail(e.target.value)} />
      <label htmlFor="auth-password" className="mt-4">{t('auth.password')}</label>
      <input id="auth-password" name="password" type="password" autoComplete={mode === 'sign-in' ? 'current-password' : 'new-password'} disabled={off} value={password} onChange={e => setPassword(e.target.value)} />
      {error && <p role="alert" className="flex gap-2 text-destructive text-xs mt-4"><AlertCircle size={15} className="shrink-0" />{t(error, errorVars)}</p>}
      {notice && <p role="status" className="flex gap-2 text-success text-xs mt-4"><CheckCircle2 size={15} className="shrink-0" />{t(notice)}</p>}
      <Button className="w-full mt-5" type="submit" disabled={off || busy}>{off ? t('auth.loading') : busy ? t('auth.wait') : mode === 'sign-in' ? t('auth.signIn') : t('auth.signUp')}</Button>
      <Button type="button" variant="outline" className="w-full mt-2" disabled={off || busy} onClick={async () => { if (inFlight.current) return; inFlight.current = true; setBusy(true); setError(''); try { await onGoogle(); } catch { setError('auth.errorGoogle'); } finally { inFlight.current = false; setBusy(false); } }}>{t('auth.googleBtn')}</Button>
      <Button variant="link" type="button" disabled={off} className="text-xs text-primary mt-4 px-0 text-start justify-start" onClick={() => { setMode(mode === 'sign-in' ? 'sign-up' : 'sign-in'); setError(''); setNotice(''); }}>
        {mode === 'sign-in' ? t('auth.toggleSignUp') : t('auth.toggleSignIn')}
      </Button>
    </form>
  </>;
}
