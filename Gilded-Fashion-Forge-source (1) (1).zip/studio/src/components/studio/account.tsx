import { useState } from 'react';
import { Link } from '@tanstack/react-router';
import { CheckCircle2, ShieldCheck, Save, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useStudio } from './studio-context';
import { useAuth } from '@/lib/use-auth';
import { CreditPanel } from './credit-panel';
import { LocationSharing } from './location-sharing';
import { useAccount, useSignOut } from '@/lib/use-account';
import { formatNgn, planById, type PlanId } from '@/lib/plans';
import { formatLagos } from '@/lib/lagos-time';
import { useLang } from '@/lib/use-lang';
import type { Key } from '@/lib/i18n';

function SignedInAccount({ user }: { user: { id: string; email?: string } }) {
  const { t, locale } = useLang();
  const { data: state, isError, refetch } = useAccount();
  const signOut = useSignOut();
  const error = isError ? t('acct.error') : '';
  const plan = state?.entitlement ? planById(state.entitlement.planId as PlanId) : null;
  return <>
    <section className="form-section mt-4">
      <h2 className="section-title mb-5">{t('acct.signedInAccount')}</h2>
      <dl className="space-y-4 text-xs">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-3">
          <dt className="text-muted-foreground">{t('acct.email')}</dt>
          <dd dir="ltr">{user.email}</dd>
        </div>
        <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-3">
          <dt className="text-muted-foreground">{t('acct.displayName')}</dt>
          <dd>{state?.displayName ?? '—'}</dd>
        </div>
        <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-3">
          <dt className="text-muted-foreground">{t('acct.plan')}</dt>
          <dd>
            {plan 
              ? t('acct.planWithExpiry', { name: t(`pro.plans.${plan.id}.name` as Key), date: formatLagos(state?.entitlement?.expiresAt ?? null, locale) ?? '' }) 
              : t('acct.noPlan')}
          </dd>
        </div>
        {state && !state.isPro && (
          <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-3">
            <dt className="text-muted-foreground">{t('acct.freeCredits')}</dt>
            <dd>
              {t('acct.freeCreditsOf', { n: state.freeImageCredits })}
              {state.freeResetsAt ? t('acct.freeResetsAt', { date: formatLagos(state.freeResetsAt, locale) ?? '' }) : ''}
            </dd>
          </div>
        )}
        <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-3">
          <dt className="text-muted-foreground">{t('acct.planCredits')}</dt>
          <dd>{state ? state.imageCredits : '—'}</dd>
        </div>
        <div className="grid grid-cols-[minmax(0,1fr)_auto] gap-3">
          <dt className="text-muted-foreground">{t('acct.videoCredits')}</dt>
          <dd>{state ? state.videoCredits : '—'}</dd>
        </div>
      </dl>
      {!state && !isError && <p role="status" className="text-muted-foreground text-xs mt-4">{t('acct.loading')}</p>}
      {error && (
        <div role="alert" className="text-destructive text-xs mt-4">
          {error} <Button variant="outline" size="sm" className="ms-2" onClick={() => refetch()}>{t('acct.retry')}</Button>
        </div>
      )}
      <p className="text-[11px] text-muted-foreground mt-4">{t('acct.creditsNote')}</p>
      <Button variant="outline" className="mt-5" onClick={signOut}><LogOut /> {t('acct.signOut')}</Button>
    </section>
  </>;
}

export function AccountSettings() {
  const { t } = useLang();
  const { name, setName } = useStudio();
  const { user, loading } = useAuth();
  const [draft, setDraft] = useState(name);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<Key | ''>('');
  return <main className="workspace-main max-w-3xl">
    <div className="eyebrow mb-2">{t('workspace')}</div>
    <h1 className="page-title">{t('account')}</h1>
    <p className="text-muted-foreground text-xs mt-3">{t('acct.testEnvNote')}</p>
    {!loading && (user
      ? <><SignedInAccount user={user} /><CreditPanel /><LocationSharing /></>
      : (
        <section className="form-section mt-4">
          <h2 className="section-title mb-3">{t('acct.signInTitle')}</h2>
          <p className="text-xs text-muted-foreground">{t('acct.signInNote')}</p>
          <Button asChild className="mt-4">
            <Link to="/auth">{t('acct.signInBtn')}</Link>
          </Button>
        </section>
      ))}
    <form className="form-section mt-4" onSubmit={e => { e.preventDefault(); if (!draft.trim()) { setError('acct.enterDisplayName'); return; } setName(draft.trim()); setError(''); setSaved(true); }}>
      <h2 className="section-title mb-6">{t('acct.demoProfileTitle')}</h2>
      <label htmlFor="display-name">{t('acct.displayName')}</label>
      <input id="display-name" value={draft} maxLength={40} onChange={e => { setDraft(e.target.value); setSaved(false); }} />
      <p className="text-[11px] text-muted-foreground mt-3">{t('acct.demoNameNote')}</p>
      {error && <p role="alert" className="text-destructive text-xs mt-3">{t(error)}</p>}
      <Button className="mt-5" type="submit"><Save /> {t('acct.saveProfile')}</Button>
      {saved && <p role="status" className="flex gap-2 text-success text-xs mt-4"><CheckCircle2 size={15} /> {t('acct.profileUpdated')}</p>}
    </form>
    <section className="form-section">
      <h2 className="section-title mb-5 flex gap-2 items-center"><ShieldCheck className="text-primary" size={18} /> {t('acct.privacyTitle')}</h2>
      <dl className="space-y-5 text-xs">
        {[
          [t('acct.connAccounts'), t('acct.connAccountsVal')],
          [t('acct.connAi'), t('acct.connAiVal')],
          [t('acct.connPayments'), t('acct.connPaymentsVal')],
          [t('acct.connProd'), t('acct.connProdVal')],
          [t('acct.connUploads'), t('acct.connUploadsVal')]
        ].map(([k, v]) => (
          <div key={k} className="grid grid-cols-[minmax(0,1fr)_auto] gap-3">
            <dt className="text-muted-foreground">{k}</dt>
            <dd>{v}</dd>
          </div>
        ))}
      </dl>
    </section>
  </main>;
}

// Re-export for plan formatting reuse elsewhere.
export { formatNgn };
