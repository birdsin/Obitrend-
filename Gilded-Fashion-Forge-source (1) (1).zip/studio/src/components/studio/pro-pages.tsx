import { useEffect, useRef, useState } from 'react';
import { Link } from '@tanstack/react-router';
import { Lock, Camera, Video, AlertCircle, ShieldAlert, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cameraProfiles, canUseCamera, formatNgn, imagePlans, planById, videoOptions, paymentsConnected, type Entitlement, type PlanId } from '@/lib/plans';
import { useStudio } from './studio-context';
import { workflowVisuals } from '@/lib/workflow-visuals';
import { useAuth } from '@/lib/use-auth';
import { getAccountState } from '@/lib/account.functions';
import { useRefreshAccount } from '@/lib/use-account';
import { getCheckoutStatus, startProCheckout, confirmProPayment } from '@/lib/payments.functions';
import { useLang } from '@/lib/use-lang';
import { UpgradeSuccessDialog } from './upgrade-success';
import type { Key } from '@/lib/i18n';
import { Aperture } from 'lucide-react';
import { cameraProfileIcons } from './camera-icons';

/** Entitlement comes from the server record only. Signed-out users get null,
 *  so every camera stays locked until a verified payment grants a plan. */
function useEntitlement(): Entitlement {
  const { user } = useAuth();
  const [ent, setEnt] = useState<Entitlement>(null);
  useEffect(() => {
    if (!user) { setEnt(null); return; }
    getAccountState().then(s => setEnt(s.entitlement ? { verified: true, planId: s.entitlement.planId as PlanId, imageCreditsLeft: s.imageCredits, videoCreditsLeft: s.videoCredits, expiresAt: s.entitlement.expiresAt } : null)).catch(() => setEnt(null));
  }, [user]);
  return ent;
}

function NotConnected() {
  const { t } = useLang();
  const { user } = useAuth();
  return <div className="flex gap-3 items-start border border-border bg-card rounded-md p-3 mt-5"><ShieldAlert size={16} className="text-primary shrink-0 mt-0.5" /><p className="text-[11px] text-muted-foreground leading-5"><strong className="text-primary">{t('pro.purchasesUnavailable')}</strong>{t('pro.notConnectedNote')}{user ? '' : (() => { const [a, b] = t('pro.signInToSee').split('{link}'); return <>{a}<Link to="/auth" className="text-primary underline-offset-2 hover:underline">{t('pro.signIn')}</Link>{b}</>; })()}</p></div>;
}

export function CameraStudio() {
  const { t } = useStudio();
  const entitlement = useEntitlement();
  return <main className="workspace-main max-w-5xl">
    <div className="camera-studio-heading"><span className="camera-icon-tile camera-icon-tile-large"><Camera aria-hidden="true" /></span><div><div className="eyebrow mb-1">{t('pro' as Key)}</div><h1 className="page-title">{t('cameras' as Key)}</h1></div></div>
    <p className="text-sm text-muted-foreground mt-2">{t('pro.cameraStudio.description')}</p>
    <NotConnected />
    <figure className="camera-studio-photo mt-5"><img src={workflowVisuals.camera} alt={t('pro.cameraStudio.alt')} width={640} height={640}/><figcaption className="sample-label">{t('pro.cameraStudio.caption')}</figcaption></figure>
    <div className="camera-profile-grid mt-6">{cameraProfiles.map(c => { const plan = planById(c.minPlan); const open = canUseCamera(entitlement, c); const ProfileIcon = cameraProfileIcons[c.id] ?? Camera; return <article key={c.id} aria-labelledby={`profile-${c.id}`} className={`camera-card camera-profile-card ${open ? 'camera-profile-unlocked' : ''}`}>
      <div className="camera-profile-top"><span className="camera-profile-mark"><Camera aria-hidden="true" /><ProfileIcon aria-hidden="true" className="camera-profile-detail" /></span><span className={`pill ${open ? 'text-primary' : ''}`}>{open ? <><Check size={12} aria-hidden="true" />{t('pro.cameraStudio.unlocked')}</> : <><Lock size={12} aria-hidden="true" /> Pro · {t('locked' as Key)}</>}</span></div>
      <h2 id={`profile-${c.id}`} className="camera-profile-name">{t(`pro.cameras.${c.id}.name` as Key)}</h2><p className="camera-profile-summary"><ProfileIcon aria-hidden="true" />{t(`pro.cameras.${c.id}.summary` as Key)}</p><p className="camera-profile-look"><Aperture aria-hidden="true" />{t(`pro.cameras.${c.id}.look` as Key)}</p>
      <div className="camera-profile-plan"><div className="text-muted-foreground">{t('pro.cameraStudio.unlockedFrom')}</div><div className="font-semibold text-primary mt-1">{t(`pro.plans.${plan.id}.name` as Key)} · {formatNgn(plan.priceNgn)} · {t('pro.plans.imageCreditsCount', { count: plan.imageCredits })} · {t('pro.plans.days', { count: plan.days })}</div></div>
    </article>; })}</div>
    <Button asChild variant="outline" className="mt-6"><Link to="/pricing">{t('pro.cameraStudio.comparePlans')}</Link></Button>
  </main>;
}

export function Pricing() {
  const { t } = useStudio();
  const entitlement = useEntitlement();
  const planName = entitlement ? t(`pro.plans.${entitlement.planId}.name` as Key) : t('noPlan' as Key);
  const [demoOpen, setDemoOpen] = useState(false);
  const { user } = useAuth();
  const refreshAccount = useRefreshAccount();
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [notice, setNotice] = useState<Key | null>(null);
  useEffect(() => {
    if (!user) return;
    getCheckoutStatus().then(r => setReady(r.testCheckoutReady)).catch(() => setReady(false));
    const q = new URLSearchParams(window.location.search);
    const ref = q.get('reference') ?? q.get('trxref');
    if (!ref) return;
    window.history.replaceState(null, '', window.location.pathname);
    setNotice('pro.pay.verifying');
    confirmProPayment({ data: { reference: ref } }).then(r => {
      const o = r.outcome;
      setNotice(o === 'activated' || o === 'already_paid' ? 'pro.pay.activated' : o === 'pending' ? 'pro.pay.pending' : o === 'marked_failed' ? 'pro.pay.failed' : 'pro.pay.error');
      // Re-read server state so the verified-upgrade watcher can react.
      void refreshAccount();
    }).catch(() => setNotice('pro.pay.error'));
  }, [user]);
  async function pay(planId: PlanId) {
    setBusy(planId); setNotice('pro.pay.redirecting');
    try {
      const r = await startProCheckout({ data: { planId, origin: window.location.origin } });
      if ('authorizationUrl' in r && r.authorizationUrl) { window.location.assign(r.authorizationUrl); return; }
      setNotice('pro.pay.error');
    } catch { setNotice('pro.pay.error'); }
    setBusy(null);
  }
  return <main className="workspace-main max-w-5xl">
    <UpgradeSuccessDialog demo open={demoOpen} onClose={() => setDemoOpen(false)} />
    <div className="eyebrow mb-1">{t('pro' as Key)}</div><h1 className="page-title">{t('pricing' as Key)}</h1>
    <div className="grid grid-cols-2 gap-3 mt-5"><div className="stat"><span className="text-[10px] text-muted-foreground">{t('plan' as Key)}</span><strong className="text-base">{planName}</strong></div><div className="stat"><span className="text-[10px] text-muted-foreground">{t('credits' as Key)} / {t('videoCredits' as Key)}</span><strong className="text-base">{entitlement ? `${entitlement.imageCreditsLeft} / ${entitlement.videoCreditsLeft}` : '— / —'}</strong></div></div>
    {ready ? <p className="text-[11px] text-primary border border-primary rounded-md p-3 mt-5">{t('pro.pay.testBanner')}</p> : <NotConnected />}
    {notice && <p role="status" className="text-xs mt-3">{t(notice)}</p>}
    <Button variant="outline" size="sm" className="mt-3" onClick={() => setDemoOpen(true)}>{t('pro.upgrade.previewButton')}</Button>
    <h2 className="section-title mt-8 mb-4">{t('pro.imageSubscriptions')}</h2>
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">{imagePlans.map(p => <article key={p.id} className={`camera-card ${p.id === 'pro-monthly' ? 'border-primary' : ''}`}>
      <h3 className="text-sm font-semibold">{t(`pro.plans.${p.id}.name` as Key)}</h3><div className="text-2xl font-bold text-primary mt-2">{formatNgn(p.priceNgn)}</div>
      <p className="text-[11px] text-muted-foreground mt-1">{t('pro.plans.imageCreditsCount', { count: p.imageCredits })} · {t('pro.plans.days', { count: p.days })}</p>
      <ul className="mt-3 space-y-1">{p.unlocks.map((u, i) => <li key={u} className="flex gap-2 text-[11px]"><Check size={12} className="text-primary shrink-0 mt-0.5" />{t(`pro.plans.${p.id}.unlocks.${i}` as Key)}</li>)}</ul>
      {ready ? <Button className="w-full mt-4" disabled={busy !== null} onClick={() => pay(p.id)}>{t('pro.pay.button')}</Button> : <Button className="w-full mt-4" disabled={!paymentsConnected}>{t('unavailable' as Key)}</Button>}
    </article>)}</div>
    <h2 className="section-title mt-8 mb-4">{t('pro.video')}</h2>
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">{videoOptions.map(v => <div key={v.seconds} className="camera-card text-center"><div className="text-lg font-bold">{v.seconds}s</div><div className="text-primary font-semibold">{formatNgn(v.priceNgn)}</div><div className="text-[10px] text-muted-foreground">{v.videoCredits} {t('pro.videoCredit')}</div></div>)}</div>
    <p className="text-[10px] text-muted-foreground mt-4">{t('pro.separateCredits')}</p>
  </main>;
}

export function VideoCreator() {
  const { t } = useStudio();
  const [seconds, setSeconds] = useState<number | null>(null);
  const [brief, setBrief] = useState('');
  const [error, setError] = useState<Key | ''>('');
  const ref = useRef<HTMLTextAreaElement>(null);
  useEffect(() => setError(''), [seconds, brief]);
  const chosen = videoOptions.find(v => v.seconds === seconds);
  function submit() {
    if (!brief.trim()) { setError('pro.videoCreator.error.emptyBrief'); ref.current?.focus(); return; }
    if (!chosen) { setError('pro.videoCreator.error.noLength'); return; }
    setError('pro.videoCreator.error.notConnected');
  }
  return <main className="workspace-main max-w-3xl">
    <div className="eyebrow mb-1 text-violet">{t('pro' as Key)}</div><h1 className="page-title">{t('video' as Key)}</h1>
    <p className="text-sm text-muted-foreground mt-2">{t('pro.videoCreator.description')}</p>
    <NotConnected />
    <figure className="mt-5"><img src={workflowVisuals.video} alt={t('pro.videoCreator.alt')} className="w-full max-h-72 object-contain" width={640} height={640}/><figcaption className="sample-label mt-2">{t('pro.videoCreator.caption')}</figcaption></figure>
    <label htmlFor="video-brief" className="mt-6">{t('pro.videoCreator.briefLabel')}</label><textarea id="video-brief" ref={ref} rows={4} value={brief} onChange={e => setBrief(e.target.value)} placeholder={t('pro.videoCreator.briefPlaceholder')} />
    <div role="radiogroup" aria-label={t('pro.videoCreator.lengthAria')} className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-5">{videoOptions.map(v => <Button key={v.seconds} type="button" role="radio" aria-checked={seconds === v.seconds} variant="outline" className={`h-auto flex-col py-3 ${seconds === v.seconds ? 'border-violet text-violet' : ''}`} onClick={() => setSeconds(v.seconds)}><span className="font-bold">{v.seconds}s</span><span className="text-[10px]">{formatNgn(v.priceNgn)} · {t('pro.videoCreator.creditSuffix')}</span></Button>)}</div>
    {error && <div role="alert" className="flex gap-2 text-destructive text-xs mt-4"><AlertCircle size={16} className="shrink-0" />{t(error, { seconds: chosen?.seconds ?? 0 })}</div>}
    <Button size="lg" className="w-full h-12 mt-5 bg-violet text-primary-foreground hover:bg-violet/90" onClick={submit}><Video /> {t('generate' as Key)} {chosen ? t('pro.videoCreator.generateWithLength', { length: `${chosen.seconds}s` }) : t('pro.video')}</Button>
  </main>;
}
