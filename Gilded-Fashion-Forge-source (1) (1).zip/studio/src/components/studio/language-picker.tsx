import { useEffect, useState } from 'react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Check, ChevronDown, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { langInfo, languages, translate, type Key, type Lang } from '@/lib/i18n';
import { browserSuggestion, LANG_SUGGEST_DISMISSED_KEY, useLang } from '@/lib/use-lang';

/** Accessible language menu: native names with flags; choice is remembered on this device. */
export function LanguagePicker({ compact = false }: { compact?: boolean }) {
  const { lang, setLang, t } = useLang();
  const [open, setOpen] = useState(false);
  const cur = langInfo(lang);
  return <Popover open={open} onOpenChange={setOpen}><div className="lang-picker">
    <PopoverTrigger asChild><Button type="button" variant="outline" size="sm" aria-label={t('lang.choose')} className="lang-trigger">
      <Globe className="text-muted-foreground" /><span aria-hidden>{cur.flag}</span>{!compact && <span className="truncate max-w-[92px]">{cur.label}</span>}<ChevronDown className="text-muted-foreground" />
    </Button></PopoverTrigger>
    <PopoverContent align="end" sideOffset={6} collisionPadding={16} className="lang-popover" dir={cur.dir}>
    <ul role="listbox" aria-label={t('lang.choose')}>
      {languages.map(l => <li key={l.code} role="option" aria-selected={l.code === lang}>
        <Button variant="ghost" type="button" lang={l.code} dir={l.dir} className="lang-option" onClick={() => { setLang(l.code); setOpen(false); }}>
          <span aria-hidden className="text-base">{l.flag}</span>
          <span className="flex-1 min-w-0 text-start"><span className="block">{l.label}</span>{l.review !== 'source' && <span className="block text-[10px] text-muted-foreground">{t(l.review === 'machine' ? 'lang.reviewNote' : 'lang.partialNote')}</span>}</span>
          {l.code === lang && <Check size={14} className="text-primary" />}
        </Button>
      </li>)}
    </ul></PopoverContent>
  </div></Popover>;
}

/** One-time hint offering the browser's language; never switches without the user's tap. */
export function LanguageSuggestion() {
  const { setLang, lang } = useLang();
  const [s, setS] = useState<Lang | null>(null);
  useEffect(() => { setS(browserSuggestion()); }, []);
  if (!s || lang !== 'en') return null;
  const info = langInfo(s);
  const dismiss = () => { try { localStorage.setItem(LANG_SUGGEST_DISMISSED_KEY, '1'); } catch { /* ignore */ } setS(null); };
  // Shown in the suggested language itself, so the user can read the offer.
  const tt = (k: Key, v?: Record<string, string>) => translate(s, k, v);
  return <div role="region" aria-label={tt('lang.choose')} className="lang-suggest" lang={s} dir={info.dir}>
    <span aria-hidden>{info.flag}</span>
    <span className="flex-1">{tt('lang.suggest', { language: info.label })}</span>
    <Button size="sm" onClick={() => { setLang(s); setS(null); }}>{tt('lang.switch')}</Button>
    <Button size="sm" variant="ghost" onClick={dismiss}>{tt('lang.keep')}</Button>
  </div>;
}

/** Small notice shown when the selected language still awaits native review. */
export function TranslationReviewNote() {
  const { lang, t } = useLang();
  const r = langInfo(lang).review;
  if (r === 'source') return null;
  return <p className="text-[10px] text-muted-foreground">{t(r === 'machine' ? 'lang.reviewNote' : 'lang.partialNote')}</p>;
}
