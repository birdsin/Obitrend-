import { useEffect, useState } from 'react';
import { Check, Crown, Sparkles } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useAccount } from '@/lib/use-account';
import { useAuth } from '@/lib/use-auth';
import { useLang } from '@/lib/use-lang';
import { formatLagos } from '@/lib/lagos-time';
import { observeVerifiedPlan } from '@/lib/upgrade-success';
import type { Key } from '@/lib/i18n';

type Props = { open: boolean; onClose: () => void; demo?: boolean; planId?: string; expiresAt?: string };

export function UpgradeSuccessDialog({ open, onClose, demo = false, planId, expiresAt }: Props) {
  const { t, locale } = useLang();
  const until = formatLagos(expiresAt, locale);
  return <Dialog open={open} onOpenChange={v => { if (!v) onClose(); }}>
    <DialogContent className="upgrade-dialog">
      <div className="upgrade-art" aria-hidden="true"><Sparkles className="upgrade-spark" size={16} /><span className="upgrade-crown"><Crown size={34} /></span><span className="upgrade-wordmark">OBITREND PRO</span></div>
      <div className="p-6 pt-5">
        {demo && <span className="pill mb-3 inline-flex">{t('pro.upgrade.demoBadge')}</span>}
        <span className="upgrade-check" aria-hidden="true"><Check size={18} /></span>
        <DialogTitle className="text-xl font-semibold mt-3">{demo ? t('pro.upgrade.demoTitle') : t('pro.upgrade.title')}</DialogTitle>
        <DialogDescription className="text-sm text-muted-foreground mt-2">{demo ? t('pro.upgrade.demoNote') : t('pro.upgrade.active')}</DialogDescription>
        {!demo && planId && until && <p className="text-[11px] text-primary mt-2">{t('pro.upgrade.planLine', { plan: t(`pro.plans.${planId}.name` as Key), date: until })}</p>}
        <ul className="mt-4 space-y-2">{([0, 1, 2] as const).map(i => <li key={i} className="flex gap-2 text-xs"><Check size={14} className="text-primary shrink-0 mt-0.5" />{t(`pro.upgrade.benefit.${i}` as Key)}</li>)}</ul>
        <Button className="w-full mt-6" onClick={onClose} autoFocus>{t('pro.upgrade.continue')}</Button>
      </div>
    </DialogContent>
  </Dialog>;
}

/** Watches the server-verified plan; opens the dialog only on a real Free → Pro transition. */
export function UpgradeSuccessWatcher() {
  const { user } = useAuth();
  const { data } = useAccount();
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (!user || !data) return;
    if (observeVerifiedPlan(window.localStorage, user.id, data)) setOpen(true);
  }, [user, data]);
  if (!data?.entitlement) return null;
  return <UpgradeSuccessDialog open={open} onClose={() => setOpen(false)} planId={data.entitlement.planId} expiresAt={data.entitlement.expiresAt} />;
}
