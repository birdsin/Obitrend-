import { useEffect, useRef, useState } from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { useRouterState } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { entryCampaigns } from '@/lib/workflow-visuals';
import { useStudio } from './studio-context';
import { shouldShowWelcome, welcomeSessionKey } from '@/lib/welcome-session';
import { StudioImage } from './studio-image';

/** Optional first-entry campaign. Reduced motion stays static until dismissed. */
export function Intro() {
  const [show, setShow] = useState(false);
  const attempted = useRef(false);
  const [reduced, setReduced] = useState(true);
  const [look, setLook] = useState(0);
  const path = useRouterState({ select: s => s.location.pathname });
  const { t } = useStudio();
  useEffect(() => {
    if (path !== '/') { setShow(false); return; }
    if (attempted.current) return;
    attempted.current = true;
    let prefersReduced = false;
    try {
      prefersReduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (!shouldShowWelcome(sessionStorage.getItem(welcomeSessionKey), prefersReduced)) return;
      sessionStorage.setItem(welcomeSessionKey, '1');
    } catch { return; }
    setLook(Math.floor(Math.random() * entryCampaigns.length));
    setReduced(prefersReduced);
    setShow(true);
  }, [path]);
  useEffect(() => {
    if (!show || reduced) return;
    const id = setTimeout(() => setShow(false), 8000);
    return () => clearTimeout(id);
  }, [show, reduced]);
  if (!show) return null;
  const campaign = entryCampaigns[look] ?? entryCampaigns[0];
  return <Dialog.Root open={show} onOpenChange={setShow}>
    <Dialog.Portal>
      <Dialog.Overlay className="entry-overlay" />
      <Dialog.Content className="entry-screen" aria-describedby="entry-description">
        <div className="entry-top">
          <span className="eyebrow">OBITREND AI CREATOR STUDIO</span>
          <Button variant="outline" onClick={() => setShow(false)}>{t('skip')}</Button>
        </div>
        <div className="entry-scene">
          <StudioImage src={campaign.image} alt={campaign.alt} width={800} height={1200} fetchPriority="high" />
        </div>
        <div className="entry-copy">
          <span className="sample-label">{t('illustration')}</span>
          <Dialog.Title>{t('workflowWelcome')}</Dialog.Title>
          <div className="entry-steps">
            {(['uploadStep', 'sceneStep', 'campaignStep'] as const).map((key, i) => (
              <p key={key}><span>0{i + 1}</span>{t(key)}</p>
            ))}
          </div>
          <Dialog.Description id="entry-description" className="text-xs text-muted-foreground leading-5 mt-3">
            {t('exampleNote')}
          </Dialog.Description>
          <Button className="mt-4 h-11" onClick={() => setShow(false)}>{t('startCreating')}</Button>
        </div>
      </Dialog.Content>
    </Dialog.Portal>
  </Dialog.Root>;
}
