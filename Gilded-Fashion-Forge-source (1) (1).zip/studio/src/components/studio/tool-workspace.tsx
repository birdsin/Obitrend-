import { type Key } from "@/lib/i18n";
import { useEffect, useRef, useState } from 'react';
import { Link } from '@tanstack/react-router';
import { ChevronRight, Upload, Sparkles, LoaderCircle, Download, FileDown, Image, CheckCircle2, AlertCircle, X, RefreshCw, Maximize2, History, Replace, Ratio } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLang } from '@/lib/use-lang';
import { validateDemoInput, validateUpload, validationKeys, type StudioTool } from '@/lib/studio-tools';
import { toolFields, modelOptions, poseOptions, backgroundOptions, colourOptions, expressionOptions, cameraOptions, type CameraSettings } from '@/lib/studio-options';
import { useStudio, exportBrief, initialToolState, jobToOutput } from './studio-context';
import { activeJobFor } from '@/lib/demo-jobs';
import { toolThumbnails } from '@/lib/tool-thumbnails';
import { StudioImage } from './studio-image';
import { ToolIcon } from './tool-icon';
import { CameraPanel } from './camera-panel';
import { AdSlot } from './ad-slot';
import { buildGenerationRequest, imageProvider, loadCamera, saveCamera } from '@/lib/generation-request';

const fieldConfig = { model: { label: 'Model', options: modelOptions }, pose: { label: 'Pose', options: poseOptions }, background: { label: 'Background', options: backgroundOptions }, colour: { label: 'Colour', options: colourOptions }, expression: { label: 'Expression', options: expressionOptions } } as const;

export function ToolWorkspace({ tool, initialStyle, initialRatio }: { tool: StudioTool; initialStyle?: string | undefined; initialRatio?: string | undefined }) {
  const { t } = useLang();
  const { download, outputs, jobs, jobsRestored, startJob, retryJob, toolState, saveToolState } = useStudio();
  const fields = toolFields(tool.id);
  const saved = toolState[tool.id] ?? initialToolState(tool.options.includes(initialStyle ?? '') ? initialStyle ?? tool.options[0] ?? '' : tool.options[0] ?? '');
  const [prompt, setPrompt] = useState(saved.prompt);
  const [direction, setDirection] = useState(saved.direction);
  const [values, setValues] = useState<Record<string, string>>(saved.fields);
  const [camera, setCamera] = useState<CameraSettings>(initialRatio && !toolState[tool.id] ? { ...saved.camera, ratio: initialRatio === '3:4' ? 'Portrait 3:4' : initialRatio === '1:1' ? 'Square 1:1' : initialRatio } : saved.camera);
  const [upload, setUpload] = useState<{ name: string; url: string } | null>(null);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState('');
  const [inputError, setInputError] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  // The job shown here lives in the shared durable store, so leaving and returning
  // (or reloading) shows the same job instead of resetting or failing it.
  const toolJobs = jobs.filter(j => j.config.toolId === tool.id);
  const job = (selectedId ? toolJobs.find(j => j.id === selectedId) : undefined) ?? activeJobFor(jobs, tool.id) ?? toolJobs[0] ?? null;
  const output = job?.status === 'completed' ? jobToOutput(job) : null;
  const status: 'idle' | 'loading' | 'success' | 'error' = inputError ? 'error' : !job ? 'idle' : job.status === 'processing' ? 'loading' : job.status === 'failed' || job.status === 'interrupted' ? 'error' : 'success';
  const setStatus = (s: 'idle' | 'error') => setInputError(s === 'error');
  const [zoom, setZoom] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const briefInput = useRef<HTMLTextAreaElement>(null);
  function focusBrief() {
    briefInput.current?.focus();
    briefInput.current?.scrollIntoView({ block: 'center', behavior: 'auto' });
  }
  const history = outputs.filter(o => o.tool === tool.id).slice(0, 4);

  useEffect(() => { saveToolState(tool.id, { prompt, direction, fields: values, camera }); }, [prompt, direction, values, camera]); // eslint-disable-line react-hooks/exhaustive-deps
  // Restore this tool's saved camera after hydration (unless the session already has it).
  useEffect(() => { if (toolState[tool.id]) return; const c = loadCamera(localStorage, tool.id); if (c) setCamera(c); }, [tool.id]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (fields.includes('camera')) saveCamera(localStorage, tool.id, camera); }, [camera]); // eslint-disable-line react-hooks/exhaustive-deps
  const request = buildGenerationRequest({ toolId: tool.id, userPrompt: prompt, direction, fields: values, camera, referenceName: upload?.name ?? null });
  useEffect(() => () => { if (upload) URL.revokeObjectURL(upload.url); }, [upload]);

  function handleFile(file?: File) { if (!file) return; const m = validateUpload(file); if (m) { setError(m); setStatus('error'); return; } setUpload({ name: file.name, url: URL.createObjectURL(file) }); setError(''); setStatus('idle'); }
  function generate() {
    const m = validateDemoInput(tool, prompt, !!upload); if (m) { setError(m); setStatus('error'); if (!prompt.trim()) focusBrief(); return; }
    setError(''); setStatus('idle');
    const sampleIndex = Math.max(0, Math.min(tool.options.indexOf(direction), 3));
    // No provider is connected, so the request is recorded but never sent; the demo runner shows a labelled sample.
    const j = startJob({ toolId: tool.id, title: tool.title, prompt: prompt.trim(), sampleIndex, settings: { direction, ...values, ...(request.camera ?? {}), reference: upload?.name ?? 'None' }, request, ...(imageProvider ? {} : { providerStatus: 'not_connected' as const }) });
    setSelectedId(j.id);
  }
  async function downloadOutput() { if (!output) return; try { await download(output); } catch { setError('ws.downloadFailedTryAgain'); setStatus('error'); } }
  let step = 0; const n = () => String(++step).padStart(2, '0');

  return <div className="tool-layout"><main className="workspace-main">
    <nav aria-label="Breadcrumb" className="workspace-breadcrumb flex items-center gap-1 text-[11px] text-muted-foreground mb-5"><Link to="/" className="hover:text-primary shrink-0">{t("dashboard")}</Link><ChevronRight size={12} className="shrink-0" /><span className="shrink-0">{t(tool.category.toLowerCase() as Key)}</span><ChevronRight size={12} className="shrink-0" /><span className="text-foreground min-w-0 truncate">{t(`tool.${tool.id}.title` as Key)}</span></nav>
    <div className="workspace-heading grid grid-cols-[minmax(0,1fr)_96px] gap-4 items-center"><div className="flex min-w-0 gap-3 items-center"><span className="tool-symbol mb-0 shrink-0"><ToolIcon name={tool.icon} className="size-5" /></span><div className="min-w-0"><div className="eyebrow mb-1">{t(tool.category.toLowerCase() as Key)}</div><h1 className="page-title">{t(`tool.${tool.id}.title` as Key)}</h1></div></div><StudioImage src={toolThumbnails[tool.id]?.image} alt={toolThumbnails[tool.id]?.alt} width={96} height={96} className="workspace-heading-image" /></div>
    <p className="text-sm text-muted-foreground mt-3 leading-6">{t(`tool.${tool.id}.description` as Key)}</p>
    <div className="flex items-start gap-3 border border-border bg-card rounded-md p-3 mt-5"><Sparkles size={16} className="text-primary shrink-0 mt-0.5" /><p className="text-[11px] text-muted-foreground leading-5"><strong className="text-primary">{t("ws.demoModeLabel")}</strong> {t("ws.demoModeNotice")}</p></div>
    <form onSubmit={e => { e.preventDefault(); generate(); }}>
      {(tool.upload || tool.id === 'fashion-image') && <section className="form-section"><h2 className="section-title mb-4">{n()} <span className="text-muted-foreground font-normal text-sm ms-2">{t('ws.uploadSection')} {t(tool.upload === 'required' ? 'ws.required' : 'ws.optional')}</span></h2>
        <div className={`upload-zone ${dragging ? 'dragging' : ''} ${upload ? 'has-preview' : ''}`} onDragOver={e => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={e => { e.preventDefault(); setDragging(false); handleFile(e.dataTransfer.files[0]); }}>
          {upload ? <><img src={upload.url} alt={t("ws.uploadPreviewAlt")} className="upload-preview" /><span className="text-xs break-all">{upload.name}</span><div className="flex gap-2"><Button type="button" variant="outline" size="sm" onClick={() => input.current?.click()}><Replace /> {t("ws.replace")}</Button><Button type="button" variant="ghost" size="sm" onClick={() => setUpload(null)}><X /> {t("ws.remove")}</Button></div></>
            : <><Upload className="text-primary" size={24} /><p className="text-xs text-muted-foreground">{t("ws.uploadDrag")}</p><Button type="button" variant="outline" onClick={() => input.current?.click()}>{t("ws.uploadButton")}</Button><span className="text-[10px] text-muted-foreground">{t("ws.uploadHint")}</span></>}
          <input ref={input} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" aria-label={t("ws.uploadAriaLabel")} onChange={e => { handleFile(e.target.files?.[0]); e.target.value = ''; }} />
        </div></section>}
      <section className="form-section"><h2 className="section-title mb-4">{n()} <span className="text-muted-foreground font-normal text-sm ms-2">{t('ws.sectionPrompt')}</span></h2>
        <label htmlFor="tool-prompt">{t(`tool.${tool.id}.promptLabel` as Key)} <span className="text-primary">*</span></label>
        <textarea ref={briefInput} id="tool-prompt" rows={4} maxLength={2000} placeholder={t(`tool.${tool.id}.placeholder` as Key)} value={prompt} onChange={e => { setPrompt(e.target.value); if (error === validateDemoInput(tool, '', false) && e.target.value.trim()) { setError(''); setStatus('idle'); } }} aria-invalid={inputError && !prompt.trim()} aria-describedby={error ? 'tool-error' : undefined} />
        <div className="flex justify-between text-[10px] text-muted-foreground mt-2"><Link to="/prompt-studio" className="text-primary">{t("ws.openPromptStudio")}</Link><span>{prompt.length} / 2,000</span></div>
      </section>
      <section className="form-section"><h2 className="section-title mb-4">{n()} <span className="text-muted-foreground font-normal text-sm ms-2">{t('ws.sectionOptions')}</span></h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div><label htmlFor="creative-direction">{t('ws.style')}</label><select id="creative-direction" value={direction} onChange={e => setDirection(e.target.value)}>{tool.options.map((o, i) => <option key={o} value={o}>{t(`tool.${tool.id}.option${i}` as Key)}</option>)}</select></div>
          {fields.filter(f => f !== 'camera').map(f => { const c = fieldConfig[f]; return <div key={f}><label htmlFor={`field-${f}`}>{t(`ws.field.${f}` as Key)}</label><select id={`field-${f}`} value={values[f] ?? c.options[0]} onChange={e => setValues(v => ({ ...v, [f]: e.target.value }))}>{c.options.map(o => <option key={o} value={o}>{t(`ws.option.${f}.${o}` as Key)}</option>)}</select></div>; })}
          {fields.includes('camera') && <div><label className="camera-control-label" htmlFor="tool-ratio"><Ratio className="camera-label-icon" aria-hidden="true" />{t('ws.camera.ratio')}</label><select id="tool-ratio" value={camera.ratio} onChange={e => setCamera(c => ({ ...c, ratio: e.target.value }))}>{cameraOptions.ratio.map(o => <option key={o} value={o}>{t(`ws.option.camera.ratio.${o}` as Key)}</option>)}</select></div>}
        </div>
      </section>
      <details className="form-section camera-details"><summary className="text-xs cursor-pointer py-2">{t('ws.generationRequest')}{request.camera ? t('ws.includesCamera') : ''}</summary>
        <pre className="text-[10px] text-muted-foreground whitespace-pre-wrap mt-2" data-testid="generation-request">{request.prompt || t('ws.addPromptToBuild')}</pre>
        {!imageProvider && <p className="text-[10px] text-primary mt-2">{t('ws.cameraDescription')}</p>}
      </details>
      <AdSlot id="workspace" className="my-5" />
      {error && <div id="tool-error" role="alert" className="flex gap-2 text-destructive text-xs my-4"><AlertCircle size={16} className="shrink-0" />{!prompt.trim() && error === validateDemoInput(tool, '', false) ? <Button type="button" variant="link" className="h-auto p-0 text-destructive text-xs whitespace-normal text-start justify-start" onClick={focusBrief}>{t("ws.validationBrief", { label: t(`tool.${tool.id}.promptLabel` as Key) })}</Button> : (error in validationKeys ? t(validationKeys[error as keyof typeof validationKeys]) : t(error as Key))}</div>}
      <Button type="submit" size="lg" className="w-full mt-5 h-12 text-sm" disabled={status === 'loading' || !jobsRestored}>{status === 'loading' ? <LoaderCircle className="animate-spin" /> : <Sparkles />}{status === 'loading' ? t('ws.preparingDemo') : t('generate')}</Button>
      <p className="text-[10px] text-muted-foreground text-center mt-2">{t("ws.demoNoCredits")}</p>
    </form>
    
  </main>
    <aside className="right-panel">    <section className="output-panel workspace-output" aria-live="polite" aria-busy={status === 'loading'}>
      <div className="flex items-center justify-between mb-3"><h2 className="section-title">{t("ws.outputSection")}</h2><span className="pill text-primary">{t("ws.sampleNotGenerated")}</span></div>
      {status === 'loading' ? <div className="output-empty"><div className="skeleton w-40 aspect-[3/4]" /><span className="text-xs">{t("ws.preparingSample")}</span>{job && <span className="text-[10px] text-muted-foreground text-center max-w-xs">{t("ws.demoJobSaved", { id: job.id.slice(0, 8) })}</span>}</div>
        : job?.status === 'failed' || job?.status === 'interrupted' ? <div className="output-empty"><AlertCircle size={24} className={job.status === 'failed' ? 'text-destructive' : 'text-muted-foreground'} /><span className="text-xs text-center max-w-xs">{job.error ? t(job.error as Key) : t('ws.demoJobFailed')}</span><Button variant="outline" onClick={() => { const r = retryJob(job.id); if (r) setSelectedId(r.id); }}><RefreshCw /> {job.status === 'interrupted' ? t('ws.resumeDemoJob') : t('ws.retry')}</Button></div>
        : output ? <div className="grid gap-4">
          <Button variant="ghost" type="button" className="sample-zoom relative" onClick={() => setZoom(true)} aria-label={t("ws.enlargeSample")}><img className="output-image" src={output.image} alt={t("ws.sampleAlt", { title: t(`tool.${tool.id}.title` as Key) })} width={768} height={1024} /><span className="absolute top-2 start-2 pill bg-card text-primary">{t("ws.samplePill")}</span><Maximize2 className="absolute bottom-2 end-2 text-hero-foreground" size={18} /></Button>
          <div><div className="flex gap-2 text-success text-xs"><CheckCircle2 size={15} /> {t("ws.sampleReady")}</div><p className="text-[10px] text-muted-foreground leading-5 mt-2">{t("ws.sampleInspiration")}</p>
            <div className="workspace-output-actions grid grid-cols-2 gap-2 mt-4"><Button onClick={downloadOutput}><Download /> {t("ws.download")}</Button><Button variant="outline" onClick={generate} disabled={!!activeJobFor(jobs, tool.id)}><RefreshCw /> {t("ws.again")}</Button><Button variant="outline" onClick={() => setZoom(true)}><Maximize2 /> {t("ws.expand")}</Button><Button variant="outline" onClick={() => exportBrief(output, t)}><FileDown /> {t("ws.exportBrief")}</Button></div>
            <Button asChild variant="link" className="px-0 text-xs mt-2"><Link to="/history"><History /> {t("ws.viewHistory")}</Link></Button></div>
        </div>
          : <div className="output-empty"><Image size={28} className="text-muted-foreground" /><div className="text-xs">{t("ws.samplePlaceholder")}</div></div>}
    </section>

      {fields.includes('camera') ? <CameraPanel value={camera} onChange={setCamera} hideRatio /> : <div><h2 className="section-title mb-2">{t("ws.advancedSettings")}</h2><p className="text-[11px] text-muted-foreground">{t("ws.styleColorOnly")}</p></div>}
      <div className="border-t border-border mt-6 pt-5"><div className="eyebrow mb-3">{t("ws.recentInTool")}</div>
        {history.length ? <div className="grid grid-cols-4 gap-2">{history.map(h => <Button variant="ghost" className="h-auto p-0" type="button" key={h.id} onClick={() => setSelectedId(h.id)} aria-label={t("ws.showEarlierSample")}><img src={h.image} alt="" className="aspect-[3/4] object-cover rounded" /></Button>)}</div> : <p className="text-[11px] text-muted-foreground">{t("ws.nothingYet")}</p>}
      </div>
      <AdSlot id="mobile" className="mt-6 md:hidden" />
    </aside>
    {zoom && output && <div className="modal-backdrop" onClick={() => setZoom(false)}><div role="dialog" aria-modal="true" aria-label={t("ws.enlargedSampleAria")} className="preview-modal" onClick={e => e.stopPropagation()}><div className="flex justify-between items-center mb-3"><span className="sample-label">{t("ws.sampleNotAiGenerated")}</span><Button autoFocus variant="ghost" size="icon" onClick={() => setZoom(false)} aria-label={t("ws.close")}><X /></Button></div><img src={output.image} alt={t("ws.sampleEnlargedAlt", { title: t(`tool.${tool.id}.title` as Key) })} /></div></div>}
  </div>;
}
