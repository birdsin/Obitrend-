import { useState, type ImgHTMLAttributes } from 'react';
import { ImageOff } from 'lucide-react';

export function StudioImage({ alt, ...props }: ImgHTMLAttributes<HTMLImageElement>) {
  const [failed, setFailed] = useState(false);
  if (failed) return <div role="img" aria-label={alt} className="image-fallback"><ImageOff aria-hidden="true" /><span>{alt}</span></div>;
  return <img {...props} alt={alt} onError={() => setFailed(true)} />;
}
