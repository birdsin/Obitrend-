import { Aperture, Camera, Contrast, Focus, GitFork, MoveUpRight, Ratio, Scan, ScanFace, SlidersHorizontal, Sun, Timer, Video, Zap, type LucideIcon } from 'lucide-react';
import type { CameraSettings } from '@/lib/studio-options';

/** Presentation only: not hardware branding or an entitlement source. */
export function CameraStandIcon({ className }: { className?: string }) {
  return <span className={`camera-stand-icon ${className ?? ''}`} aria-hidden="true"><Camera /><GitFork /></span>;
}
export const cameraControlIcons: Record<keyof CameraSettings, LucideIcon | typeof CameraStandIcon> = {
  preset: Camera, angle: MoveUpRight, distance: CameraStandIcon, lens: Focus,
  aperture: Aperture, shutter: Timer, iso: Contrast, exposure: Sun,
  lightDir: Zap, lightSoft: Sun, framing: ScanFace, ratio: Ratio, quality: Scan,
};
export const cameraPresetIcons: Record<string, LucideIcon> = {
  Portrait: ScanFace, Editorial: Aperture, Studio: SlidersHorizontal,
  'Street-style': Focus, Campaign: Zap,
};
export const cameraProfileIcons: Record<string, LucideIcon> = {
  'canon-r5-ii': Focus, 'nikon-z8': Video, 'sony-a7r-vi': Sun, 'fuji-gfx100s-ii': Aperture,
};