import { createFileRoute } from '@tanstack/react-router';
import { isTestSecretKey, verifyPaystackSignature } from '@/lib/paystack';
import { verifyAndSettle } from '@/lib/payments.server';

export const Route = createFileRoute('/api/public/paystack-webhook')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env['PAYSTACK_SECRET_KEY'];
        if (!isTestSecretKey(secret)) return new Response('Not configured', { status: 503 });
        const raw = await request.text();
        if (raw.length > 100_000) return new Response('Too large', { status: 413 });
        if (!(await verifyPaystackSignature(raw, request.headers.get('x-paystack-signature'), secret))) return new Response('Invalid signature', { status: 401 });
        let ref = '';
        try { const p = JSON.parse(raw) as { data?: { reference?: unknown } }; ref = typeof p.data?.reference === 'string' ? p.data.reference : ''; } catch { return new Response('Bad body', { status: 400 }); }
        if (!ref || ref.length > 80) return new Response('ok');
        // Even signed events are re-verified with Paystack before any grant.
        const outcome = await verifyAndSettle(ref, secret);
        return new Response(outcome === 'verify_failed' ? 'retry' : 'ok', { status: outcome === 'verify_failed' ? 500 : 200 });
      },
    },
  },
});
