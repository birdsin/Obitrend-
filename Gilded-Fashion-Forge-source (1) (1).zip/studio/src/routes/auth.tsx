import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useEffect } from 'react';
import { Sparkles } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { lovable } from '@/integrations/lovable/index';
import { useAuth } from '@/lib/use-auth';
import { AuthForm, type AuthMode } from '@/components/studio/auth-form';
import { useLang } from '@/lib/use-lang';
import { LanguagePicker } from '@/components/studio/language-picker';
import { LanguageSuggestion } from '@/components/studio/language-picker';

export const Route = createFileRoute('/auth')({
  validateSearch: (s: Record<string, unknown>): { redirect?: string | undefined } => {
    const r = s['redirect'];
    return { redirect: typeof r === 'string' && r.startsWith('/') && !r.startsWith('//') && r !== '/auth' ? r : undefined };
  },
  head: () => ({
    meta: [
      { title: 'Sign in — OBITREND AI Creator Studio' },
      { name: 'description', content: 'Sign in to the OBITREND AI Creator Studio test environment.' },
      { property: 'og:title', content: 'Sign in — OBITREND AI Creator Studio' },
      { property: 'og:description', content: 'Sign in to the OBITREND AI Creator Studio test environment.' },
      { property: 'og:type', content: 'website' },
      { name: 'twitter:card', content: 'summary' },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { t } = useLang();
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { redirect } = Route.useSearch();
  // Signed in (password, Google return, or existing session) → go to the dashboard / requested page.
  useEffect(() => { if (!loading && user) navigate({ to: redirect ?? '/', replace: true }); }, [loading, user, redirect, navigate]);

  async function submit(mode: AuthMode, email: string, password: string) {
    if (mode === 'sign-up') {
      const { data, error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin } });
      if (error) throw error;
      return data.session ? undefined : { notice: 'auth.confirmEmail' as const };
    }
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return undefined;
  }

  async function google() {
    const result = await lovable.auth.signInWithOAuth('google', { redirect_uri: `${window.location.origin}/auth` });
    if (result.error) throw result.error;
  }

  return <main className="workspace-main max-w-md w-full">
    <div className="flex justify-end mb-4">
      <LanguagePicker />
    </div>
    {!loading && user ? <p className="text-sm text-muted-foreground" role="status">{t('auth.openingStudio')}</p> : <>
      <div className="flex items-center gap-3 mb-6"><span className="w-9 h-9 grid place-items-center border border-primary rounded-md text-primary"><Sparkles size={19} /></span><div><div className="font-bold text-[17px]">OBITREND<span className="text-primary"> AI</span></div><div className="text-[8px] tracking-[1.8px] text-muted-foreground mt-1">CREATOR STUDIO</div></div></div>
      <div className="eyebrow mb-2">{t('auth.pageEyebrow')}</div>
      <AuthForm onSubmit={submit} onGoogle={google} />
      <div className="mt-8">
        <LanguageSuggestion />
      </div>
    </>}
  </main>;
}
