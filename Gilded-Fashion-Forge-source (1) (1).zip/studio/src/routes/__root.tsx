import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { StudioProvider } from "@/components/studio/studio-context";
import { StudioShell } from "@/components/studio/studio-shell";
import { supabase } from "@/integrations/supabase/client";
import { authIdentityChanged, useAuth } from "@/lib/use-auth";
import { useRouterState } from "@tanstack/react-router";
import { Splash, useSplashOnce } from "@/components/studio/splash";
import { useLang } from "@/lib/use-lang";

function NotFoundComponent() {
  const { t } = useLang();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">{t('misc.notFoundTitle')}</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          {t('misc.notFoundText')}
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            {t('misc.goHome')}
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  const { t } = useLang();
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          {t('misc.errorTitle')}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {t('misc.errorText')}
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            {t('misc.tryAgain')}
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            {t('misc.goHome')}
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", href: "/favicon.svg", type: "image/svg+xml" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;650;700;800&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  const { dir, lang } = useLang();
  return (
    <html lang={lang} dir={dir}>
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const router = useRouter();
  useEffect(() => {
    let lastUserId: string | null | undefined;
    supabase.auth.getSession().then(({ data }) => { if (lastUserId === undefined) lastUserId = data.session?.user.id ?? null; });
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "INITIAL_SESSION") { if (lastUserId === undefined) lastUserId = session?.user.id ?? null; return; }
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
      const nextId = session?.user.id ?? null;
      if (event !== "USER_UPDATED" && lastUserId !== undefined && !authIdentityChanged(lastUserId, nextId)) return;
      lastUserId = nextId;
      router.invalidate();
      if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
    });
    return () => sub.subscription.unsubscribe();
  }, [router, queryClient]);

  return (
    <QueryClientProvider client={queryClient}>
      <AppGate />
    </QueryClientProvider>
  );
}

function AppGate() {
  const { t } = useLang();
  const { user, loading } = useAuth();
  const router = useRouter();
  const path = useRouterState({ select: s => s.location.pathname });
  const [splash, endSplash] = useSplashOnce();
  useEffect(() => {
    if (!splash && !loading && !user && path !== "/auth") router.navigate({ to: "/auth", search: { redirect: path === "/" ? undefined : path }, replace: true });
  }, [splash, loading, user, path, router]);
  if (splash) return <Splash onDone={endSplash} />;
  if (path === "/auth") return <div className="auth-shell"><Outlet /></div>;
  if (loading || !user) return <div className="auth-shell" aria-busy="true"><span className="text-xs text-muted-foreground">{t('misc.checkingSession')}</span></div>;
  return <StudioProvider key={user.id} userId={user.id}><StudioShell><Outlet /></StudioShell></StudioProvider>;
}
