import { createFileRoute, Outlet, redirect } from '@tanstack/react-router';
import { supabase } from '@/integrations/supabase/client';

// Every studio page lives under this gate. getUser() re-validates the session with the
// auth server, so a signed-out or revoked session can never render protected screens.
export const Route = createFileRoute('/_authenticated')({
  ssr: false,
  beforeLoad: async ({ location }) => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: '/auth', search: { redirect: location.pathname }, replace: true });
  },
  component: () => <Outlet />,
});
