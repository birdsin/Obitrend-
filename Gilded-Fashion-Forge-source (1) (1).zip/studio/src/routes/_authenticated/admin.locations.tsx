import { createFileRoute } from '@tanstack/react-router';
import { useQuery } from '@tanstack/react-query';
import { adminListLocations } from '@/lib/location.functions';
import { formatLagos } from '@/lib/lagos-time';
import { useLang } from '@/lib/use-lang';

function AdminLocations() {
  const { t, locale } = useLang();
  const { data, isLoading, isError } = useQuery({ queryKey: ['admin-locations'], queryFn: () => adminListLocations() });
  return <main className="workspace-main max-w-3xl">
    <div className="eyebrow mb-2">{t('loc.adminEyebrow')}</div>
    <h1 className="page-title">{t('loc.adminTitle')}</h1>
    {isLoading && <p className="text-xs text-muted-foreground mt-4">{t('loc.adminChecking')}</p>}
    {isError && <p role="alert" className="text-destructive text-xs mt-4">{t('loc.adminLoadError')}</p>}
    {data && !data.authorized && <p className="text-xs text-muted-foreground mt-4">{t('loc.adminOnly')}</p>}
    {data?.authorized && (data.rows.length === 0
      ? <p className="text-xs text-muted-foreground mt-4">{t('loc.adminEmpty')}</p>
      : <table className="w-full text-xs mt-4"><thead><tr className="text-start text-muted-foreground"><th className="text-start">{t('loc.tableAccount')}</th><th className="text-start">{t('loc.tableLocation')}</th><th className="text-start">{t('loc.tableConsent')}</th><th className="text-start">{t('loc.tableUpdated')}</th></tr></thead>
        <tbody>{data.rows.map(r => <tr key={r.userId} className="border-t border-border"><td className="py-2 font-mono" dir="ltr">{r.userId.slice(0, 8)}…</td><td dir="ltr">{r.latitude?.toFixed(2)}, {r.longitude?.toFixed(2)}</td><td dir="ltr">{formatLagos(r.consentGivenAt, locale)}</td><td dir="ltr">{formatLagos(r.capturedAt, locale)}</td></tr>)}</tbody></table>)}
  </main>;
}

export const Route = createFileRoute('/_authenticated/admin/locations')({
  head: () => ({ meta: [{ title: 'Shared Locations (Admin) — OBITREND AI Creator Studio' }, { name: 'description', content: 'Administrator view of locations users chose to share.' }, { property: 'og:title', content: 'Shared Locations (Admin) — OBITREND AI Creator Studio' }, { property: 'og:description', content: 'Administrator view of locations users chose to share.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }, { name: 'robots', content: 'noindex' }] }),
  component: AdminLocations,
});
