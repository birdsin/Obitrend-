import { createFileRoute, notFound, Link } from '@tanstack/react-router';
import { tools } from '@/lib/studio-tools';
import { ToolWorkspace } from '@/components/studio/tool-workspace';
import { Button } from '@/components/ui/button';
import { ProGate } from '@/components/studio/pro-gate';
import { useLang } from '@/lib/use-lang';
import type { Key } from '@/lib/i18n';

export const Route = createFileRoute('/_authenticated/tools/$toolId')({
 validateSearch: (search: {style?: string; ratio?: string}): {style?: string | undefined; ratio?: string | undefined} => ({style: typeof search.style==='string'?search.style:undefined,ratio: ['3:4','1:1','9:16','16:9'].includes(String(search.ratio))?String(search.ratio):undefined}),
 beforeLoad: ({params}) => { if(!tools.some(t=>t.id===params.toolId)) throw notFound(); },
 head: ({params}) => {const tool=tools.find(t=>t.id===params.toolId);const title=`${tool?.title??'Tool unavailable'} — OBITREND AI Creator Studio`;const description=tool?.description??'Explore the independent OBITREND fashion creator studio.';return {meta:[{title},{name:'description',content:description},{property:'og:title',content:title},{property:'og:description',content:description},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]};},
 component: ToolPage,
 notFoundComponent: () => <ToolNotFound />,
});
function ToolNotFound(){const {t}=useLang();return <main className="workspace-main"><h1 className="page-title">{t('ws.toolNotFound')}</h1><Button asChild className="mt-5"><Link to="/">{t('ws.backToDashboard')}</Link></Button></main>;}
function ToolPage(){const {t}=useLang();const {toolId}=Route.useParams();const search=Route.useSearch();const tool=tools.find(t=>t.id===toolId);if(!tool)return null;return <ProGate feature={t(`tool.${tool.id}.title` as Key)}><ToolWorkspace key={tool.id} tool={tool} initialStyle={search.style} initialRatio={search.ratio}/></ProGate>;}
