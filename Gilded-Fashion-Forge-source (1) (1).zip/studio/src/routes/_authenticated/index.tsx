import { createFileRoute } from '@tanstack/react-router';
import { Dashboard } from '@/components/studio/dashboard';
export const Route = createFileRoute('/_authenticated/')({
 head:()=>({meta:[{title:'OBITREND AI Creator Studio — Fashion Workspace'},{name:'description',content:'An independent fashion creator studio with twenty creative tools, editorial inspiration and honest demo previews.'},{property:'og:title',content:'OBITREND AI Creator Studio — Fashion Workspace'},{property:'og:description',content:'Explore twenty fashion tools in an independent black-and-gold demo studio.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),
 component: Dashboard,
});
