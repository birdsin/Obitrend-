import { createFileRoute } from '@tanstack/react-router';
import { VideoCreator } from '@/components/studio/pro-pages';
import { ProGate } from '@/components/studio/pro-gate';
import { useLang } from '@/lib/use-lang';

export const Route = createFileRoute('/_authenticated/video')({
  head: () => ({ meta: [{ title: 'Video Creator — OBITREND AI Creator Studio' }, { name: 'description', content: 'Create fashion videos at an exact 5, 10, 15 or 20 second length.' }, { property: 'og:title', content: 'Video Creator — OBITREND' }, { property: 'og:description', content: 'Create fashion videos at an exact 5, 10, 15 or 20 second length.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }] }),
  component: () => {
    const { t } = useLang();
    return <ProGate feature={t('video')}><VideoCreator /></ProGate>;
  },
});
