import { createFileRoute } from '@tanstack/react-router';
import { CameraStudio } from '@/components/studio/pro-pages';
export const Route = createFileRoute('/_authenticated/cameras')({
  head: () => ({ meta: [{ title: 'Pro Camera Studio — OBITREND AI Creator Studio' }, { name: 'description', content: 'Simulated camera-style profiles for fashion image generation.' }, { property: 'og:title', content: 'Pro Camera Studio — OBITREND' }, { property: 'og:description', content: 'Simulated camera-style profiles for fashion image generation.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }] }),
  component: CameraStudio,
});
