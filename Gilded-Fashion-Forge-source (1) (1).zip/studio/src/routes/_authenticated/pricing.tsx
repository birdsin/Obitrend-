import { createFileRoute } from '@tanstack/react-router';
import { Pricing } from '@/components/studio/pro-pages';
export const Route = createFileRoute('/_authenticated/pricing')({
  head: () => ({ meta: [{ title: 'Plans & Pricing — OBITREND AI Creator Studio' }, { name: 'description', content: 'Image subscriptions and video prices in Naira.' }, { property: 'og:title', content: 'Plans & Pricing — OBITREND' }, { property: 'og:description', content: 'Image subscriptions and video prices in Naira.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }] }),
  component: Pricing,
});
