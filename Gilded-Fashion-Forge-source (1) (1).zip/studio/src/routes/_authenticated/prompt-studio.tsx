import { createFileRoute } from '@tanstack/react-router';
import { PromptStudio } from '@/components/studio/prompt-studio';
export const Route = createFileRoute('/_authenticated/prompt-studio')({
  head: () => ({ meta: [{ title: 'Text-to-Prompt Studio — OBITREND AI Creator Studio' }, { name: 'description', content: 'Build garment-faithful fashion prompts with model, pose, lighting and framing details.' }, { property: 'og:title', content: 'Text-to-Prompt Studio — OBITREND' }, { property: 'og:description', content: 'Write detailed fashion prompts that keep your garment exactly as it is.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }] }),
  component: PromptStudio,
});
