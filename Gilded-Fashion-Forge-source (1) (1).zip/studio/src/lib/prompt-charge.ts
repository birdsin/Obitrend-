// Charged prompt-generation flow, shared by the server function and tests.
// The database (reserve_request_credit / complete / refund) is the authority;
// this orchestrates it: reserve 1 credit (idempotent per requestId), run the
// provider, complete on success, refund exactly once on any failure.
export const PROMPT_COST = 1;

export type PromptProviderResult = { ok: true; text: string } | { ok: false; reason: 'provider_not_connected' | 'provider_error'; message: string };
export type PromptProvider = { generate(prompt: string): Promise<PromptProviderResult> };

/** No prompt-generation service is connected in this test project. */
export const promptProvider: PromptProvider | null = null;
export const PROMPT_NOT_CONNECTED = 'Prompt service not connected — nothing was generated. Your credit was returned.';

export type Reservation = { chargeId: string; status: 'reserved' | 'completed' | 'refunded'; source: 'free' | 'plan'; duplicate: boolean };
export type ChargeDeps = {
  reserve(requestId: string): Promise<Reservation>; // throws 'no credits left'
  complete(chargeId: string): Promise<boolean>;
  refund(chargeId: string): Promise<boolean>;
};

export type ChargedOutcome =
  | { status: 'generated'; text: string; source: 'free' | 'plan' }
  | { status: 'duplicate'; chargeStatus: Reservation['status'] }
  | { status: 'insufficient_credits' }
  | { status: 'failed_refunded'; reason: string; refunded: boolean };

export async function runChargedPrompt(requestId: string, prompt: string, deps: ChargeDeps, provider: PromptProvider | null): Promise<ChargedOutcome> {
  let r: Reservation;
  try { r = await deps.reserve(requestId); }
  catch (e) { if (e instanceof Error && /no credits left/.test(e.message)) return { status: 'insufficient_credits' }; throw e; }
  if (r.duplicate) return { status: 'duplicate', chargeStatus: r.status };
  let result: PromptProviderResult;
  try { result = provider ? await provider.generate(prompt) : { ok: false, reason: 'provider_not_connected', message: PROMPT_NOT_CONNECTED }; }
  catch { result = { ok: false, reason: 'provider_error', message: 'Prompt generation failed. Your credit was returned.' }; }
  if (result.ok && result.text.trim()) { await deps.complete(r.chargeId); return { status: 'generated', text: result.text, source: r.source }; }
  const refunded = await deps.refund(r.chargeId);
  return { status: 'failed_refunded', reason: result.ok ? 'Empty result. Your credit was returned.' : result.message, refunded };
}
