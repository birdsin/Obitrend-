import editorial from '@/assets/editorial/fashion-image.webp';
import tailoring from '@/assets/editorial/outfit-preview.webp';
import menswear from '@/assets/editorial/model-selection.webp';
import emerald from '@/assets/editorial/editorial-studio.webp';
import pose from '@/assets/editorial/pose-selection.webp';
import background from '@/assets/editorial/background-selection.webp';
import colour from '@/assets/editorial/colour-variations.webp';
import campaign from '@/assets/editorial/fashion-campaigns.webp';
import tryOn from '@/assets/editorial/virtual-try-on.webp';
import sketch from '@/assets/editorial/sketch-to-fashion.webp';
import fabric from '@/assets/editorial/fabric-studio.webp';
import pattern from '@/assets/editorial/pattern-creator.webp';
import accessories from '@/assets/editorial/accessory-styling.webp';
import product from '@/assets/editorial/product-photography.webp';
import lookbook from '@/assets/editorial/lookbook.webp';
import social from '@/assets/editorial/social-content.webp';
import enhancer from '@/assets/editorial/image-enhancer.webp';
import remover from '@/assets/editorial/background-remover.webp';
import moodboard from '@/assets/editorial/fashion-moodboard.webp';
import collection from '@/assets/editorial/collection-planner.webp';

/** Decorative inspiration only: never used as generated workspace output. */
export const toolThumbnails: Record<string, { image: string; alt: string }> = {
  'fashion-image': { image: editorial, alt: 'Illustration: cobalt jacket reference beside a full-length model wearing a cobalt jacket and ivory trousers' },
  'model-selection': { image: menswear, alt: 'Diverse adult models in tank tops, a crop top and tailored trousers' },
  'pose-selection': { image: pose, alt: 'Two poses of an adult model in a crop top and olive pleated skirt' },
  'background-selection': { image: background, alt: 'Full-length menswear campaign in a stone courtyard' },
  'colour-variations': { image: colour, alt: 'Adult models wearing emerald, blue and burgundy silk dress colourways' },
  'fashion-campaigns': { image: campaign, alt: 'Two models in a coordinated tailoring campaign' },
  'outfit-preview': { image: tailoring, alt: 'Tank top, denim jacket, sage skirt and trainers arranged as a complete outfit' },
  'virtual-try-on': { image: tryOn, alt: 'Illustrative green trench reference beside a full-length adult model' },
  'sketch-to-fashion': { image: sketch, alt: 'Couture dress sketch beside a sculptural dress on a mannequin' },
  'fabric-studio': { image: fabric, alt: 'Linen, satin, tweed and denim fabric textures' },
  'pattern-creator': { image: pattern, alt: 'Full-length patterned dress beside a matching repeat textile' },
  'accessory-styling': { image: accessories, alt: 'Full-length tailored menswear with a leather bag and loafers' },
  'product-photography': { image: product, alt: 'Burgundy handbag and silver heels on a studio plinth' },
  'lookbook': { image: lookbook, alt: 'Three adult models in coordinated lookbook outfits' },
  'social-content': { image: social, alt: 'Streetwear crop top and denim campaign with a phone on a tripod' },
  'editorial-studio': { image: emerald, alt: 'Full-length adult model in silver couture under editorial studio lighting' },
  'image-enhancer': { image: enhancer, alt: 'Detailed denim stitching and buttons, illustrative enhancement inspiration' },
  'background-remover': { image: remover, alt: 'Ruby tailored blazer isolated on an ivory studio background' },
  'fashion-moodboard': { image: moodboard, alt: 'Fashion photographs and fabric moodboard' },
  'collection-planner': { image: collection, alt: 'Coordinated capsule collection on a rail' },
};