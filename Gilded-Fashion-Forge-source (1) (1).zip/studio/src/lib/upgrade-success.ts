// Decides when to show the Pro upgrade-success dialog.
// The only trigger is a server-verified account state (getAccountState) moving from a
// previously recorded Free plan to an active Pro entitlement. Opening pricing or clicking
// a button never triggers it. When a real payment provider is connected, its verified
// webhook must create the `entitlements` row server-side; this detector then fires.

export type VerifiedPlan = { isPro: boolean; entitlement: { planId: string; expiresAt: string } | null };
type Stored = { lastIsPro: boolean; celebrated: string[] };

const key = (userId: string) => `obitrend.upgrade.v1.${userId}`;
export const entitlementId = (e: { planId: string; expiresAt: string }) => `${e.planId}@${e.expiresAt}`;

function read(storage: Pick<Storage, 'getItem'>, userId: string): Stored | null {
  try { const v = JSON.parse(storage.getItem(key(userId)) ?? 'null'); return v && typeof v.lastIsPro === 'boolean' && Array.isArray(v.celebrated) ? v : null; } catch { return null; }
}

/** Pure decision: show only when a known Free state becomes verified Pro with an uncelebrated entitlement. */
export function shouldCelebrate(prev: Stored | null, next: VerifiedPlan): boolean {
  if (!prev || prev.lastIsPro || !next.isPro || !next.entitlement) return false;
  return !prev.celebrated.includes(entitlementId(next.entitlement));
}

/** Records the latest verified plan and returns whether the dialog should open. */
export function observeVerifiedPlan(storage: Pick<Storage, 'getItem' | 'setItem'>, userId: string, next: VerifiedPlan): boolean {
  const prev = read(storage, userId);
  const show = shouldCelebrate(prev, next);
  const celebrated = [...(prev?.celebrated ?? [])];
  if (next.isPro && next.entitlement && !celebrated.includes(entitlementId(next.entitlement))) celebrated.push(entitlementId(next.entitlement));
  try { storage.setItem(key(userId), JSON.stringify({ lastIsPro: next.isPro, celebrated: celebrated.slice(-10) })); } catch { /* storage unavailable */ }
  return show;
}
