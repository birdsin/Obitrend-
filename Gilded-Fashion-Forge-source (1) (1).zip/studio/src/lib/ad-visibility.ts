// Single source of truth for whether an ad slot may render.
// Ads render only for a server-confirmed Free plan, in an enabled designated slot.
// There is deliberately no rewarded-ad concept: ad views never grant credits or generations.
import { isAdEnabled, type AdSlotId } from './ad-slots';

export type PlanVisibility = { loaded: boolean; isPro: boolean };

export function adsAllowedForPlan(plan: PlanVisibility): boolean {
  return plan.loaded && !plan.isPro;
}

export function canRenderAdSlot(id: AdSlotId, plan: PlanVisibility, enabled: (id: AdSlotId) => boolean = isAdEnabled): boolean {
  return adsAllowedForPlan(plan) && enabled(id);
}
