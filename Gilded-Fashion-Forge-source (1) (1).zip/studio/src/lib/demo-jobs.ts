import type { GenerationRequest } from './generation-request';
/**
 * Durable generation-job model. Today a local demo runner "processes" jobs by
 * assigning a bundled sample once `readyAt` passes; it runs only while the app
 * is open. A future server worker can own processing by replacing `JobRunner`
 * while the job shape and UX stay the same.
 */
export type JobStatus = 'processing' | 'completed' | 'failed' | 'interrupted';
export type JobConfig = { toolId: string; title: string; prompt: string; settings: Record<string, string>; sampleIndex: number; request?: GenerationRequest; providerStatus?: 'not_connected' };
export type GenerationJob = {
  id: string;
  status: JobStatus;
  config: JobConfig;
  createdAt: number;
  updatedAt: number;
  readyAt: number;
  completedAt?: number;
  /** Set when the app was closed/hidden past readyAt; the sample was assigned on return. */
  restoredOnReturn?: boolean;
  /** Result reference only — the index of a bundled demo sample, never inference output. */
  result?: { sampleIndex: number };
  error?: string;
  /** Set when a processing job was found after a reload/close; the browser runner stopped, so it never finished. */
  interruptedAt?: number;
  retryOf?: string;
};

export const JOBS_STORAGE_KEY = 'obitrend-demo-jobs-v1';
export const DEMO_DURATION_MS = 1100;
export const MAX_JOBS = 60;

export interface JobRunner {
  /** Advance a job given the current time. Must be idempotent. */
  advance(job: GenerationJob, now: number, appWasAway: boolean): GenerationJob;
}

export const localDemoRunner: JobRunner = {
  advance(job, now, appWasAway) {
    if (job.status !== 'processing' || now < job.readyAt) return job;
    return { ...job, status: 'completed', updatedAt: now, completedAt: now, result: { sampleIndex: job.config.sampleIndex }, ...(appWasAway ? { restoredOnReturn: true } : {}) };
  },
};

export function createJob(config: JobConfig, now: number, id: string, retryOf?: string): GenerationJob {
  return { id, status: 'processing', config, createdAt: now, updatedAt: now, readyAt: now + DEMO_DURATION_MS, ...(retryOf ? { retryOf } : {}) };
}

/** A tool may have at most one in-flight job; returns it so callers reuse instead of duplicating. */
export function activeJobFor(jobs: GenerationJob[], toolId: string): GenerationJob | undefined {
  return jobs.find(j => j.config.toolId === toolId && j.status === 'processing');
}

export function canRetry(job: GenerationJob): boolean { return job.status === 'failed' || job.status === 'interrupted'; }

export const INTERRUPTED_MESSAGE = 'ws.interruptedMessage';

/**
 * On app open/reload, any job still "processing" was abandoned when the page went
 * away (this runner lives only in the open page). Mark it interrupted instead of
 * pretending it completed while closed. Completed/failed jobs are left untouched.
 */
export function interruptStale(jobs: GenerationJob[], now: number): GenerationJob[] {
  if (!jobs.some(j => j.status === 'processing')) return jobs;
  return jobs.map(j => j.status === 'processing' ? { ...j, status: 'interrupted' as const, updatedAt: now, interruptedAt: now, error: INTERRUPTED_MESSAGE } : j);
}

export function addJob(jobs: GenerationJob[], job: GenerationJob): GenerationJob[] {
  if (activeJobFor(jobs, job.config.toolId)) return jobs;
  return [job, ...jobs].slice(0, MAX_JOBS);
}

export function advanceAll(jobs: GenerationJob[], now: number, runner: JobRunner = localDemoRunner, appWasAway = false): GenerationJob[] {
  let changed = false;
  const next = jobs.map(j => { const n = runner.advance(j, now, appWasAway); if (n !== j) changed = true; return n; });
  return changed ? next : jobs;
}

function isJob(v: unknown): v is GenerationJob {
  if (!v || typeof v !== 'object') return false;
  const j = v as Partial<Record<'id' | 'status' | 'createdAt' | 'readyAt' | 'config', unknown>>; const c = j.config as Partial<Record<'toolId' | 'sampleIndex', unknown>> | undefined;
  return typeof j.id === 'string' && ['processing', 'completed', 'failed', 'interrupted'].includes(j.status as string) && typeof j.createdAt === 'number' && typeof j.readyAt === 'number' && !!c && typeof c.toolId === 'string' && typeof c.sampleIndex === 'number';
}

export function parseJobs(raw: string | null): GenerationJob[] {
  if (!raw) return [];
  try { const v: unknown = JSON.parse(raw); return Array.isArray(v) ? v.filter(isJob).slice(0, MAX_JOBS) : []; } catch { return []; }
}
