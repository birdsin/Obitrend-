// Mirrors the database rules for opt-in location sharing (the database is the authority).
export type LocationRecord = { consentGivenAt: string | null; revokedAt: string | null; latitude: number | null; longitude: number | null };

/** ~1 km precision: coordinates are rounded to 2 decimals before storage. */
export function minimizeCoord(v: number): number { return Math.round(v * 100) / 100; }

/** Location may only be read from the device after explicit consent that has not been revoked. */
export function mayCaptureLocation(r: LocationRecord | null): boolean { return !!r?.consentGivenAt && !r.revokedAt; }

/** Revoking clears coordinates immediately. */
export function revoke(r: LocationRecord, now: string): LocationRecord { return { ...r, revokedAt: now, latitude: null, longitude: null }; }

/** Who may view a record: the owner always; an admin (server-verified role) only while consent is active and coordinates exist. */
export function canViewLocation(viewerId: string, ownerId: string, viewerIsAdmin: boolean, r: LocationRecord): boolean {
  if (viewerId === ownerId) return true;
  return viewerIsAdmin && mayCaptureLocation(r) && r.latitude !== null;
}
