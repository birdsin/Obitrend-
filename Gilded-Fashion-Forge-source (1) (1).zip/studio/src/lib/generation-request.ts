/**
 * Shared, typed image-generation request contract. Every image tool builds its
 * payload here so camera settings travel as structured data AND as prompt text,
 * always after the garment-fidelity instructions (which take priority).
 *
 * No image provider is connected in this project. `imageProvider` is null, so
 * `submitGenerationRequest` reports `provider_not_connected` honestly instead of
 * returning a sample as if it were generated. A future server-side adapter can
 * implement `ImageProvider` without changing tool components.
 */
import { defaultCamera, toolFields, modelOptions, poseOptions, expressionOptions, backgroundOptions, colourOptions, type CameraSettings } from './studio-options';

export const GARMENT_FIDELITY_RULE = 'Reproduce the uploaded garment exactly: keep its category, silhouette, colour, neckline, sleeves, seams, stitching, proportions, fabric texture, print, embroidery, buttons, zippers and logos. Do not redesign or recolour it.';
export const CAMERA_PRIORITY_RULE = 'Camera settings affect only framing, lens look, lighting and output format; they must never change the garment.';

export type GenerationRequest = {
  toolId: string;
  prompt: string;
  /** Uploaded garment/reference is the primary input. */
  reference: { name: string } | null;
  options: Record<string, string>;
  camera: CameraSettings | null;
  output: { ratio: string; quality: string };
};

export type BuildInput = { toolId: string; userPrompt: string; direction: string; fields: Record<string, string>; camera?: CameraSettings | null; referenceName?: string | null };

/** Keeps only known camera keys with string values; anything missing falls back to defaults. */
export function normalizeCamera(raw: unknown): CameraSettings {
  const out: CameraSettings = { ...defaultCamera };
  if (raw && typeof raw === 'object') for (const k of Object.keys(defaultCamera) as (keyof CameraSettings)[]) { const v = (raw as Record<string, unknown>)[k]; if (typeof v === 'string' && v) out[k] = v; }
  return out;
}

export function cameraPromptLine(c: CameraSettings): string {
  return `Camera: ${c.preset} preset, ${c.angle.toLowerCase()} angle, ${c.distance.toLowerCase()} distance, ${c.lens} lens, ${c.aperture}, shutter ${c.shutter}, ISO ${c.iso}, exposure ${c.exposure} EV. Lighting: ${c.lightSoft.toLowerCase()} ${c.lightDir.toLowerCase()} light. Framing: ${c.framing.toLowerCase()}${/full.?body/i.test(c.framing) ? ', show the entire model from head to feet' : ''}. Output: ${c.ratio}, ${c.quality} quality.`;
}

export function buildGenerationRequest(i: BuildInput): GenerationRequest {
  const usesCamera = toolFields(i.toolId).includes('camera');
  const camera = usesCamera ? normalizeCamera(i.camera) : null;
  const defaults = { model: modelOptions[0] ?? '', pose: poseOptions[0] ?? '', expression: expressionOptions[0] ?? '', background: backgroundOptions[0] ?? '', colour: colourOptions[0] ?? '' };
  const selected = Object.fromEntries(toolFields(i.toolId).filter(f => f !== 'camera').map(f => [f, i.fields[f] ?? defaults[f]]));
  const options = { direction: i.direction, ...selected };
  const lines = [
    i.referenceName ? GARMENT_FIDELITY_RULE : '',
    i.userPrompt.trim(),
    Object.entries(options).filter(([, v]) => v).map(([k, v]) => `${k.charAt(0).toUpperCase()}${k.slice(1)}: ${v}.`).join(' '),
    camera ? cameraPromptLine(camera) : '',
    camera && i.referenceName ? CAMERA_PRIORITY_RULE : '',
  ].filter(Boolean);
  return { toolId: i.toolId, prompt: lines.join('\n'), reference: i.referenceName ? { name: i.referenceName } : null, options, camera, output: { ratio: camera?.ratio ?? defaultCamera.ratio, quality: camera?.quality ?? defaultCamera.quality } };
}

export type ProviderResult = { ok: true; imageUrl: string } | { ok: false; reason: 'provider_not_connected' | 'provider_error'; message: string };
export interface ImageProvider { generate(req: GenerationRequest): Promise<ProviderResult> }

/** No provider configured in this test project. Replace with a server-side adapter once approved. */
export const imageProvider: ImageProvider | null = null;
export const PROVIDER_NOT_CONNECTED = 'Image service not connected — this request was not sent. A pre-made demo sample is shown instead.';

export async function submitGenerationRequest(req: GenerationRequest, provider: ImageProvider | null = imageProvider): Promise<ProviderResult> {
  if (!provider) return { ok: false, reason: 'provider_not_connected', message: PROVIDER_NOT_CONNECTED };
  return provider.generate(req);
}

/** Camera settings persist per tool on this device so reloads keep them. */
export const CAMERA_STORAGE_KEY = 'obitrend-camera-v1';
export function loadCamera(store: Pick<Storage, 'getItem'>, toolId: string): CameraSettings | null {
  try { const all = JSON.parse(store.getItem(CAMERA_STORAGE_KEY) ?? '{}') as Record<string, unknown>; return all[toolId] ? normalizeCamera(all[toolId]) : null; } catch { return null; }
}
export function saveCamera(store: Pick<Storage, 'getItem' | 'setItem'>, toolId: string, c: CameraSettings) {
  try { const all = JSON.parse(store.getItem(CAMERA_STORAGE_KEY) ?? '{}') as Record<string, unknown>; all[toolId] = c; store.setItem(CAMERA_STORAGE_KEY, JSON.stringify(all)); } catch { /* storage blocked */ }
}
