// Pure, runtime-safe Paystack helpers (Web Crypto only). No secrets live here.
import { imagePlans, type PlanId } from './plans';

export const PAYSTACK_API = 'https://api.paystack.co';

/** Only test-mode secret keys are accepted in this project. */
export function isTestSecretKey(key: string | undefined): key is string {
  return typeof key === 'string' && key.startsWith('sk_test_');
}

export function proPlanForCheckout(id: string) {
  return imagePlans.find(p => p.id === id) ?? null;
}

export function toKobo(ngn: number): number { return Math.round(ngn * 100); }

/** HMAC-SHA512 hex of the raw body, as Paystack signs webhooks (x-paystack-signature). */
export async function signPaystackBody(rawBody: string, secret: string): Promise<string> {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-512' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(rawBody));
  return [...new Uint8Array(sig)].map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function verifyPaystackSignature(rawBody: string, header: string | null, secret: string): Promise<boolean> {
  if (!header) return false;
  const expected = await signPaystackBody(rawBody, secret);
  if (expected.length !== header.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ header.charCodeAt(i);
  return diff === 0;
}

export type VerifiedTx = { reference: string; status: string; amountKobo: number; currency: string };

/** Asks Paystack itself for the transaction status — never trusts redirects or webhook bodies alone. */
export async function fetchVerifiedTransaction(reference: string, secret: string): Promise<VerifiedTx | null> {
  const res = await fetch(`${PAYSTACK_API}/transaction/verify/${encodeURIComponent(reference)}`, { headers: { Authorization: `Bearer ${secret}` } });
  if (!res.ok) return null;
  const body = await res.json() as { status?: boolean; data?: { reference?: string; status?: string; amount?: number; currency?: string } };
  const d = body.data;
  if (!body.status || !d || d.reference !== reference || typeof d.amount !== 'number') return null;
  return { reference, status: String(d.status ?? ''), amountKobo: d.amount, currency: String(d.currency ?? '') };
}

export type SettleOutcome = 'activated' | 'already_paid' | 'pending' | 'marked_failed' | 'amount_mismatch' | 'unknown_reference' | 'unsupported_plan';

export function planGrant(planId: string): { days: number; credits: number } | null {
  const p = proPlanForCheckout(planId as PlanId);
  return p ? { days: p.days, credits: p.imageCredits } : null;
}
