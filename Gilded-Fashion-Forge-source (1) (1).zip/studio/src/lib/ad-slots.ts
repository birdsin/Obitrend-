// Reserved advertising slots. All disabled by default; no third-party scripts are loaded.
export type AdSlotId = 'dashboard' | 'workspace' | 'sidebar' | 'mobile' | 'gallery';
export const adSlots: Record<AdSlotId, { label: string; enabled: boolean; minHeight: number }> = {
  dashboard: { label: 'Dashboard banner', enabled: false, minHeight: 90 },
  workspace: { label: 'Tool workspace', enabled: false, minHeight: 90 },
  sidebar: { label: 'Sidebar sponsored', enabled: false, minHeight: 120 },
  mobile: { label: 'Mobile banner', enabled: false, minHeight: 60 },
  gallery: { label: 'Gallery / history', enabled: false, minHeight: 120 },
};
export function isAdEnabled(id: AdSlotId): boolean { return adSlots[id].enabled; }
