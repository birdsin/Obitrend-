// Source-of-truth English strings, split by area. Add keys to the area file; run
// `bun scripts/translate-locales.ts` to draft other languages, then `bunx vitest run src/test/i18n.test.ts`.
import { core } from './en/core';
import { tools } from './en/tools';
import { time } from './en/time';
import { lang } from './en/lang';
import { shell } from './en/shell';
import { dashboard } from './en/dashboard';
import { workspace } from './en/workspace';
import { prompt } from './en/prompt';
import { account } from './en/account';
import { credits } from './en/credits';
import { location } from './en/location';
import { auth } from './en/auth';
import { pro } from './en/pro';
import { library } from './en/library';
import { intro } from './en/intro';
import { misc } from './en/misc';

export const en = { ...core, ...tools, ...time, ...lang, ...shell, ...dashboard, ...workspace, ...prompt, ...account, ...credits, ...location, ...auth, ...pro, ...library, ...intro, ...misc } as const;
export type Key = keyof typeof en;
