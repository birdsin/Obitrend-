// Original studio strings (keys kept unchanged so earlier Igbo/Chinese translations are preserved).
export const core = {
  dashboard: 'Dashboard', findTool: 'Find a tool…', create: 'Create studio', refine: 'Refine studio', campaign: 'Campaign studio', pro: 'Pro studio', workspace: 'Your workspace',
  history: 'Image history', downloads: 'Downloads', account: 'Account settings', promptStudio: 'Text-to-prompt studio', cameras: 'Pro camera studio', pricing: 'Plans & pricing', video: 'Video creator',
  collapse: 'Collapse sidebar', demoMode: 'Demo mode', welcome: 'Welcome back', startCreating: 'Start creating', generate: 'Generate', language: 'Language',
  locked: 'Locked', unavailable: 'Purchases unavailable', credits: 'Image credits', videoCredits: 'Video credits', plan: 'Current plan', noPlan: 'No verified plan',
  noTools: 'No matching tools.', workflowTitle: 'Your garment. A new campaign.', uploadStep: 'Upload garment', sceneStep: 'Choose model & scene', campaignStep: 'Generate campaign', illustration: 'DEMO · Illustrative workflow', fidelityNote: 'Garment preservation is the goal, not a verified capability of this demo. These examples are pre-made; your upload is not transformed.', skip: 'Skip', workflowWelcome: 'From garment to campaign', openWorkspace: 'Open workspace', examples: 'Garment & campaign examples', exampleNote: 'Pre-made illustrations — not generated from your inputs.', cameraExample: 'Camera studio', videoExample: 'Video storyboard',
} as const;
