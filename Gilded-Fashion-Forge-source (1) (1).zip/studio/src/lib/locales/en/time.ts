export const time = { 'time.dueNow': 'due now — refreshing', 'time.dhm': '{d}d {h}h {m}m', 'time.hm': '{h}h {m}m', 'time.m': '{m}m' } as const;
