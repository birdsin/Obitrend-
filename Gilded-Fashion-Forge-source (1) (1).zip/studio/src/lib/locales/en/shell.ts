export const shell = {
 "shell.proOnly": "Pro only",
 "shell.proLabel": "Pro",
 "shell.freeLabel": "Free",
 "shell.testLabel": "test",
 "shell.signIn": "Sign in",
 "shell.testAccountsNote": "Test accounts · no plan by default",
 "shell.creatorStudio": "Creator Studio",
 "shell.loadingSplash": "Loading OBITREND AI Creator Studio",
 "shell.advertisement": "Advertisement",
 "shell.openNav": "Open navigation",
 "shell.closeNav": "Close navigation",
 "shell.navAriaLabel": "Studio navigation"
} as const;
