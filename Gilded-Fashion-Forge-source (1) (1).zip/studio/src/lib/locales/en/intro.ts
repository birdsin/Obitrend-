export const intro = {} as const;
