export const misc = {
 "misc.notFoundTitle": "Page not found",
 "misc.notFoundText": "The page you're looking for doesn't exist or has been moved.",
 "misc.goHome": "Go home",
 "misc.errorTitle": "This page didn't load",
 "misc.errorText": "Something went wrong on our end. You can try refreshing or head back home.",
 "misc.tryAgain": "Try again",
 "misc.checkingSession": "Checking your session…"
} as const;
