export const lang = {
  'lang.choose': 'Choose language', 'lang.suggest': 'Your browser prefers {language}. Switch the studio to it?', 'lang.switch': 'Switch', 'lang.keep': 'Keep English',
  'lang.reviewNote': 'Machine-drafted translation — awaiting native-speaker review.', 'lang.partialNote': 'Some text is machine-drafted — awaiting native-speaker review.',
} as const;
