import { fetchVerifiedTransaction, planGrant, type SettleOutcome } from './paystack';

/** Verifies with Paystack, then settles atomically in the database. Safe to call repeatedly. */
export async function verifyAndSettle(reference: string, secret: string): Promise<SettleOutcome | 'verify_failed'> {
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
  const { data: intent } = await supabaseAdmin.from('payment_intents').select('plan_id').eq('reference', reference).maybeSingle();
  if (!intent) return 'unknown_reference';
  const grant = planGrant(intent.plan_id);
  if (!grant) return 'unsupported_plan';
  const tx = await fetchVerifiedTransaction(reference, secret);
  if (!tx) return 'verify_failed';
  const { data, error } = await supabaseAdmin.rpc('settle_paystack_payment', {
    _reference: reference, _paystack_status: tx.status, _amount_kobo: tx.amountKobo, _currency: tx.currency, _days: grant.days, _credits: grant.credits,
  });
  if (error) { console.error('settle failed', error.message); return 'verify_failed'; }
  return data as SettleOutcome;
}
