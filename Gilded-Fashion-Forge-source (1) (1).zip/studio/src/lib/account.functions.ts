import { createServerFn } from '@tanstack/react-start';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';

export type AccountState = {
  userId: string;
  email: string | null;
  displayName: string | null;
  imageCredits: number;
  videoCredits: number;
  freeImageCredits: number;
  freeResetsAt: string | null;
  isPro: boolean;
  entitlement: { planId: string; expiresAt: string } | null;
  roles: string[];
  walletUpdatedAt: string | null;
  fetchedAt: string;
};

/** Reads the signed-in user's account. refresh_free_credits() runs in the database and
 *  only grants the weekly free credits when the 7-day period has expired. */
export const getAccountState = createServerFn({ method: 'GET' })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AccountState> => {
    const { supabase, userId, claims } = context;
    const free = await supabase.rpc('refresh_free_credits');
    if (free.error) throw new Error('Could not load free credits');
    const [profile, wallet, entitlements, roles] = await Promise.all([
      supabase.from('profiles').select('display_name').eq('id', userId).maybeSingle(),
      supabase.from('credit_wallets').select('image_credits, video_credits, updated_at').eq('user_id', userId).maybeSingle(),
      supabase.from('entitlements').select('plan_id, expires_at').eq('user_id', userId).lte('starts_at', new Date().toISOString()).gt('expires_at', new Date().toISOString()).order('expires_at', { ascending: false }).limit(1),
      supabase.from('user_roles').select('role').eq('user_id', userId),
    ]);
    if (wallet.error || entitlements.error) throw new Error('Could not load account balances');
    const active = entitlements.data?.[0] ?? null;
    const f = free.data?.[0];
    return {
      userId,
      email: (claims?.email as string | undefined) ?? null,
      displayName: profile.data?.display_name ?? null,
      imageCredits: wallet.data?.image_credits ?? 0,
      videoCredits: wallet.data?.video_credits ?? 0,
      freeImageCredits: f?.free_image_credits ?? 0,
      freeResetsAt: f?.free_period_resets_at ?? null,
      isPro: !!f?.is_pro,
      entitlement: active ? { planId: active.plan_id, expiresAt: active.expires_at } : null,
      roles: (roles.data ?? []).map(r => r.role),
      walletUpdatedAt: wallet.data?.updated_at ?? null,
      fetchedAt: new Date().toISOString(),
    };
  });
