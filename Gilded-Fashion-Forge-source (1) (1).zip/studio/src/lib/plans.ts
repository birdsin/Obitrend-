// Single source of truth for subscription plans, video pricing and camera profiles.
// Amounts are in Naira and must not be changed without the owner's approval.
export type PlanId = 'pro-4d' | 'pro-8d' | 'pro-14d' | 'pro-monthly';
export type Plan = { id: PlanId; name: string; priceNgn: number; imageCredits: number; days: number; unlocks: string[] };
export const imagePlans: Plan[] = [
  { id: 'pro-4d', name: '4 Day Pro', priceNgn: 10000, imageCredits: 5, days: 4, unlocks: ['Canon EOS R5 Mark II profile', 'Pro camera fine-tuning'] },
  { id: 'pro-8d', name: '8 Day Pro', priceNgn: 20000, imageCredits: 10, days: 8, unlocks: ['Canon EOS R5 Mark II profile', 'Nikon Z8 profile', 'Pro camera fine-tuning'] },
  { id: 'pro-14d', name: '14 Day Pro', priceNgn: 30000, imageCredits: 15, days: 14, unlocks: ['Canon, Nikon and Sony a7R VI profiles', 'Pro camera fine-tuning', 'Ultra quality setting'] },
  { id: 'pro-monthly', name: 'Monthly Full Pro', priceNgn: 60000, imageCredits: 30, days: 30, unlocks: ['All four camera profiles incl. Fujifilm GFX 100S II', 'Pro camera fine-tuning', 'Ultra quality setting'] },
];
export type VideoOption = { seconds: 5 | 10 | 15 | 20; priceNgn: number; videoCredits: 1 };
export const videoOptions: VideoOption[] = [
  { seconds: 5, priceNgn: 5000, videoCredits: 1 },
  { seconds: 10, priceNgn: 10000, videoCredits: 1 },
  { seconds: 15, priceNgn: 15000, videoCredits: 1 },
  { seconds: 20, priceNgn: 20000, videoCredits: 1 },
];
export type CameraProfile = { id: string; name: string; summary: string; look: string; minPlan: PlanId };
export const cameraProfiles: CameraProfile[] = [
  { id: 'canon-r5-ii', name: 'Canon EOS R5 Mark II', summary: '45MP stacked CMOS, 8K video, eye-control autofocus (requested profile).', look: 'Crisp full-frame detail with natural skin tones.', minPlan: 'pro-4d' },
  { id: 'nikon-z8', name: 'Nikon Z8', summary: '46MP-class profile, fast burst and 8K-video look, rugged pro body.', look: 'Punchy contrast suited to motion and runway.', minPlan: 'pro-8d' },
  { id: 'sony-a7r-vi', name: 'Sony a7R VI', summary: 'High-resolution full-frame profile with tracking and low-light look.', look: 'Clean shadows for evening and interior scenes.', minPlan: 'pro-14d' },
  { id: 'fuji-gfx100s-ii', name: 'Fujifilm GFX 100S II', summary: '102MP medium-format look with deep detail and dynamic range.', look: 'Smooth tonal roll-off for luxury campaigns.', minPlan: 'pro-monthly' },
];
export function formatNgn(n: number): string { return `₦${n.toLocaleString('en-NG')}`; }
export function planById(id: PlanId): Plan { const p = imagePlans.find(x => x.id === id); if (!p) throw new Error(`Unknown plan ${id}`); return p; }
/** Entitlement is only ever granted by a verified server. This project has none, so nothing unlocks. */
export type Entitlement = { verified: true; planId: PlanId; imageCreditsLeft: number; videoCreditsLeft: number; expiresAt: string } | null;
const order: PlanId[] = ['pro-4d', 'pro-8d', 'pro-14d', 'pro-monthly'];
export function canUseCamera(ent: Entitlement, profile: CameraProfile): boolean {
  if (!ent || !ent.verified || new Date(ent.expiresAt).getTime() < Date.now()) return false;
  return order.indexOf(ent.planId) >= order.indexOf(profile.minPlan);
}
export const paymentsConnected = false;
