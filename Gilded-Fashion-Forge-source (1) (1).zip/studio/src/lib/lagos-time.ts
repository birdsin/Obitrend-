// Display helpers: every account date/time is shown in Africa/Lagos (WAT, UTC+1),
// whatever the interface language. Language only changes wording, never the instant.
export const LAGOS_TZ = 'Africa/Lagos';

export function formatLagos(iso: string | null | undefined, locale = 'en-GB'): string | null {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  let s: string;
  try { s = new Intl.DateTimeFormat(locale, { timeZone: LAGOS_TZ, day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(d); }
  catch { s = new Intl.DateTimeFormat('en-GB', { timeZone: LAGOS_TZ, day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(d); }
  return `${s} WAT`;
}

export type CountdownParts = { due: true } | { due: false; d: number; h: number; m: number };
/** Time left until a server-provided target; null when there is no valid target. */
export function countdownParts(targetIso: string | null | undefined, now: number): CountdownParts | null {
  if (!targetIso) return null;
  const t = new Date(targetIso).getTime();
  if (Number.isNaN(t)) return null;
  const ms = t - now;
  if (ms <= 0) return { due: true };
  const mins = Math.floor(ms / 60000);
  return { due: false, d: Math.floor(mins / 1440), h: Math.floor((mins % 1440) / 60), m: mins % 60 };
}

type TV = { d?: number; h?: number; m?: number };
type T = (k: 'time.dueNow' | 'time.dhm' | 'time.hm' | 'time.m', v?: TV) => string;
const enT: T = (k, v) => ({ 'time.dueNow': 'due now — refreshing', 'time.dhm': `${v?.d}d ${v?.h}h ${v?.m}m`, 'time.hm': `${v?.h}h ${v?.m}m`, 'time.m': `${v?.m}m` })[k];

/** Countdown text; pass the translator to localise the units. */
export function countdown(targetIso: string | null | undefined, now: number, t: T = enT): string | null {
  const p = countdownParts(targetIso, now);
  if (!p) return null;
  if (p.due) return t('time.dueNow');
  return p.d > 0 ? t('time.dhm', p) : p.h > 0 ? t('time.hm', p) : t('time.m', { m: Math.max(p.m, 1) });
}

/** Spendable image credits: free users spend only free credits, Pro users only plan credits. */
export function spendableCredits(a: { isPro: boolean; imageCredits: number; freeImageCredits: number }): number {
  return a.isPro ? a.imageCredits : a.freeImageCredits;
}
