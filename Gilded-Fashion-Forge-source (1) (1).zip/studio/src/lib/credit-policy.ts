// Shared account-access and free-credit rules. The database functions
// (refresh_free_credits / reserve / refund) are the authority; this module mirrors
// the same rules for the UI and tests and never grants anything by itself.
export const FREE_WEEKLY_IMAGE_CREDITS = 2;
export const FREE_PERIOD_MS = 7 * 24 * 60 * 60 * 1000;
/** The only workspace free (non-Pro) accounts may open. */
export const FREE_TOOL_ROUTES = ['/prompt-studio'] as const;

export type FreeWallet = { freeCredits: number; resetsAt: number | null };

/** Mirrors refresh_free_credits(): Pro never holds free credits; free users get exactly
 *  2 only when the 7-day period has expired (never on every load). */
export function refreshFreeWallet(w: FreeWallet, isPro: boolean, now: number): FreeWallet {
  if (isPro) return { freeCredits: 0, resetsAt: null };
  if (w.resetsAt === null || now >= w.resetsAt) return { freeCredits: FREE_WEEKLY_IMAGE_CREDITS, resetsAt: now + FREE_PERIOD_MS };
  return w;
}

export type Charge = { status: 'reserved' | 'completed' | 'refunded' };
/** Mirrors refund_generation_charge(): only a still-reserved charge refunds, so a credit returns exactly once. */
export function refundCharge(c: Charge): { charge: Charge; refunded: boolean } {
  if (c.status !== 'reserved') return { charge: c, refunded: false };
  return { charge: { status: 'refunded' }, refunded: true };
}

export function canOpenPath(path: string, isPro: boolean): boolean {
  if (isPro) return true;
  if (path.startsWith('/tools/') || path === '/video') return false;
  return true;
}
export function canUseTool(toolId: string, isPro: boolean): boolean {
  return isPro || toolId === 'prompt-studio';
}
