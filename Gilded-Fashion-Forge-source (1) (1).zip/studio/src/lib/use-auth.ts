import { useSyncExternalStore } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { User } from '@supabase/supabase-js';

export type AuthState = { user: User | null; loading: boolean };

/**
 * One shared auth subscription for the whole app. Components read it via
 * useAuth(); repeated renders/mounts never add listeners. Supabase re-emits
 * SIGNED_IN on tab refocus — those are ignored when the user did not change,
 * so open forms are not re-rendered into a different branch.
 */
let state: AuthState = { user: null, loading: true };
const listeners = new Set<() => void>();
let started = false;
const serverState: AuthState = { user: null, loading: true };

function set(next: AuthState) {
  if (next.loading === state.loading && next.user?.id === state.user?.id && next.user?.email === state.user?.email) return;
  state = next; listeners.forEach(l => l());
}

function start() {
  if (started || typeof window === 'undefined') return;
  started = true;
  supabase.auth.getUser().then(({ data }) => set({ user: data.user, loading: false }), () => set({ user: null, loading: false }));
  supabase.auth.onAuthStateChange((event, session) => {
    if (event !== 'SIGNED_IN' && event !== 'SIGNED_OUT' && event !== 'USER_UPDATED') return;
    set({ user: session?.user ?? null, loading: false });
  });
}

function subscribe(l: () => void) { start(); listeners.add(l); return () => { listeners.delete(l); }; }

/** True when the signed-in user identity actually changed (used to avoid needless router invalidation). */
export function authIdentityChanged(prev: string | null | undefined, next: string | null | undefined) { return (prev ?? null) !== (next ?? null); }

export function useAuth(): AuthState {
  return useSyncExternalStore(subscribe, () => state, () => serverState);
}
