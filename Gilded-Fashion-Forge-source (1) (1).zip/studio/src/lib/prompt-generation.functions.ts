import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { promptProvider, runChargedPrompt, type ChargedOutcome } from './prompt-charge';

const TOOL_ID = 'prompt-studio';

/** Charges 1 credit server-side for a new prompt generation, idempotent per requestId. */
export const generatePrompt = createServerFn({ method: 'POST' })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ requestId: z.string().uuid(), prompt: z.string().trim().min(1).max(8000) }).parse(d))
  .handler(async ({ data, context }): Promise<ChargedOutcome> => {
    const { userId } = context;
    const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
    return runChargedPrompt(data.requestId, data.prompt, {
      async reserve(requestId) {
        const { data: rows, error } = await supabaseAdmin.rpc('reserve_request_credit', { _user_id: userId, _tool_id: TOOL_ID, _request_id: requestId });
        if (error) throw new Error(error.message);
        const r = rows?.[0];
        if (!r) throw new Error('Reservation failed');
        return { chargeId: r.charge_id, status: r.charge_status as 'reserved', source: r.charge_source as 'free', duplicate: r.duplicate };
      },
      async complete(id) { const { data: ok, error } = await supabaseAdmin.rpc('complete_generation_charge', { _charge_id: id }); if (error) throw new Error(error.message); return !!ok; },
      async refund(id) { const { data: ok, error } = await supabaseAdmin.rpc('refund_generation_charge', { _charge_id: id }); if (error) throw new Error(error.message); return !!ok; },
    }, promptProvider);
  });

export type LedgerRow = { id: string; kind: string; delta: number; reason: string; created_at: string };
export const getCreditHistory = createServerFn({ method: 'GET' })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<LedgerRow[]> => {
    const { data, error } = await context.supabase.from('credit_ledger').select('id, kind, delta, reason, created_at').eq('user_id', context.userId).order('created_at', { ascending: false }).limit(10);
    if (error) throw new Error('Could not load credit history');
    return data ?? [];
  });
