import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from '@tanstack/react-router';
import { getAccountState } from './account.functions';
import { useAuth } from './use-auth';
import { supabase } from '@/integrations/supabase/client';

/** Server-verified account state (plan, balances, free-credit reset). */
export function useAccount() {
  const { user } = useAuth();
  return useQuery({ queryKey: ['account', user?.id], queryFn: () => getAccountState(), enabled: !!user, staleTime: 15_000, refetchOnWindowFocus: true, refetchInterval: 60_000 });
}

/** Call after any generation, charge or refund so balances re-read from the server. */
export function useRefreshAccount() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries({ queryKey: ['account'] });
}

export function useSignOut() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  return async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: '/auth', replace: true });
  };
}
