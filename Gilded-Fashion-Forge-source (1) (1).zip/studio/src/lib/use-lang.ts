import { useCallback, useEffect, useSyncExternalStore } from 'react';
import { isLang, langInfo, matchBrowserLang, translate, type Key, type Lang, type Vars } from './i18n';

// One app-wide language store (works on sign-in pages too). The user's explicit choice is
// remembered on this device; until then English is used and the browser language is only *suggested*.
export const LANG_STORAGE_KEY = 'obitrend-lang-v1';
export const LANG_SUGGEST_DISMISSED_KEY = 'obitrend-lang-suggest-dismissed-v1';
let current: Lang = 'en';
let loaded = false;
const listeners = new Set<() => void>();

function apply(l: Lang) {
  if (typeof document === 'undefined') return;
  document.documentElement.lang = l;
  document.documentElement.dir = langInfo(l).dir;
}
function load() {
  if (loaded || typeof window === 'undefined') return;
  loaded = true;
  try { const s = localStorage.getItem(LANG_STORAGE_KEY); if (isLang(s)) current = s; } catch { /* storage blocked */ }
  apply(current);
}
export function getStoredChoice(): Lang | null {
  try { const s = localStorage.getItem(LANG_STORAGE_KEY); return isLang(s) ? s : null; } catch { return null; }
}
export function setLang(l: Lang) {
  current = l; loaded = true;
  try { localStorage.setItem(LANG_STORAGE_KEY, l); } catch { /* storage blocked */ }
  apply(l); listeners.forEach(f => f());
}
const subscribe = (f: () => void) => { listeners.add(f); return () => listeners.delete(f); };

export function useLang() {
  // Server render and first client render use English, so hydration always matches.
  const lang = useSyncExternalStore(subscribe, () => current, () => 'en' as Lang);
  useEffect(() => { const before = current; load(); if (current !== before) listeners.forEach(f => f()); }, []);
  const t = useCallback((k: Key, vars?: Vars) => translate(lang, k, vars), [lang]);
  return { lang, setLang, t, locale: langInfo(lang).locale, dir: langInfo(lang).dir };
}

/** Browser language to suggest on first visit (no stored choice, not dismissed), or null. */
export function browserSuggestion(): Lang | null {
  if (typeof navigator === 'undefined' || getStoredChoice()) return null;
  try { if (localStorage.getItem(LANG_SUGGEST_DISMISSED_KEY)) return null; } catch { /* ignore */ }
  const m = matchBrowserLang(navigator.languages?.length ? navigator.languages : [navigator.language]);
  return m && m !== 'en' ? m : null;
}
