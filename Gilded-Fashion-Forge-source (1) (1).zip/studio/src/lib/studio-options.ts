// Shared option lists, per-tool field config, camera defaults and the prompt builder.
export type ToolField = 'model' | 'pose' | 'expression' | 'background' | 'colour' | 'camera';

const fieldMap: Record<string, ToolField[]> = {
  'fashion-image': ['model', 'pose', 'background', 'camera'],
  'model-selection': ['model', 'pose', 'camera'],
  'pose-selection': ['model', 'pose', 'camera'],
  'background-selection': ['background', 'camera'],
  'colour-variations': ['colour'],
  'fashion-campaigns': ['model', 'background', 'camera'],
  'outfit-preview': ['model', 'pose', 'background', 'camera'],
  'virtual-try-on': ['model', 'pose', 'background', 'camera'],
  'sketch-to-fashion': ['model', 'colour'],
  'fabric-studio': ['colour'],
  'pattern-creator': ['colour'],
  'accessory-styling': ['model', 'camera'],
  'product-photography': ['background', 'camera'],
  'lookbook': ['model', 'pose', 'background', 'camera'],
  'social-content': ['model', 'pose', 'background', 'camera'],
  'editorial-studio': ['model', 'pose', 'background', 'camera'],
  'image-enhancer': [],
  'background-remover': ['background'],
  'fashion-moodboard': ['colour'],
  'collection-planner': ['model', 'colour'],
};
export function toolFields(id: string): ToolField[] {
  const fields = fieldMap[id] ?? [];
  return fields.includes('model') ? [...fields.filter(f => f !== 'camera'), 'expression', ...fields.filter(f => f === 'camera')] : fields;
}

export const modelOptions = ['Female model', 'Male model', 'Androgynous model', 'Plus-size model', 'Model duo'];
export const poseOptions = ['Standing front', 'Walking', 'Three-quarter turn', 'Seated', 'Hands in pockets', 'Dynamic movement'];
export const backgroundOptions = ['Seamless studio', 'Minimal architecture', 'City street', 'Luxury interior', 'Nature', 'Transparent'];
export const colourOptions = ['Keep original colour', 'Midnight black', 'Champagne gold', 'Emerald', 'Ivory', 'Burgundy'];
export const expressionOptions = ['Neutral', 'Confident', 'Soft smile', 'Thoughtful'];

export type CameraSettings = { preset: string; angle: string; distance: string; lens: string; aperture: string; shutter: string; iso: string; exposure: string; lightDir: string; lightSoft: string; framing: string; ratio: string; quality: string };
export const cameraOptions: Record<keyof CameraSettings, string[]> = {
  preset: ['Portrait', 'Editorial', 'Studio', 'Street-style', 'Campaign'],
  angle: ['Eye level', 'Low angle', 'High angle', 'Overhead'],
  distance: ['Close', 'Medium', 'Wide'],
  lens: ['35mm', '50mm', '85mm', '105mm', '135mm'],
  aperture: ['f/1.8', 'f/2.8', 'f/4', 'f/5.6', 'f/8'],
  shutter: ['1/60', '1/125', '1/250', '1/500'],
  iso: ['100', '200', '400', '800'],
  exposure: ['-1', '-0.5', '0', '+0.5', '+1'],
  lightDir: ['Front', 'Side', 'Rim', 'Top'],
  lightSoft: ['Soft', 'Medium', 'Hard'],
  framing: ['Close-up', 'Medium', 'Three-quarter', 'Full body'],
  ratio: ['Portrait 3:4', 'Landscape 4:3', 'Square 1:1', '4:5', '5:4', '9:16', '16:9'],
  quality: ['Standard', 'High', 'Ultra'],
};
export const defaultCamera: CameraSettings = { preset: 'Editorial', angle: 'Eye level', distance: 'Medium', lens: '85mm', aperture: 'f/2.8', shutter: '1/250', iso: '100', exposure: '0', lightDir: 'Side', lightSoft: 'Soft', framing: 'Full body', ratio: 'Portrait 3:4', quality: 'High' };
export const cameraPresets: Record<string, { hint: string; values: Partial<CameraSettings> }> = {
  Portrait: { hint: 'Shallow focus, flattering close framing', values: { lens: '85mm', aperture: 'f/1.8', framing: 'Close-up', distance: 'Close', lightSoft: 'Soft' } },
  Editorial: { hint: 'Magazine look, dramatic side light', values: { lens: '85mm', aperture: 'f/2.8', framing: 'Full body', lightDir: 'Side' } },
  Studio: { hint: 'Clean, even light, crisp detail', values: { lens: '50mm', aperture: 'f/8', lightDir: 'Front', lightSoft: 'Soft', framing: 'Full body' } },
  'Street-style': { hint: 'Natural, candid, wider view', values: { lens: '35mm', aperture: 'f/4', distance: 'Wide', framing: 'Three-quarter', shutter: '1/500' } },
  Campaign: { hint: 'Bold, polished hero image', values: { lens: '105mm', aperture: 'f/4', lightDir: 'Rim', lightSoft: 'Medium', quality: 'Ultra' } },
};
export function applyPreset(cam: CameraSettings, preset: string): CameraSettings {
  return { ...cam, ...(cameraPresets[preset]?.values ?? {}), preset };
}

export type PromptParts = { idea: string; garment: string; model: string; pose: string; background: string; lighting: string; composition: string; colour: string; negative: string };
export const emptyPrompt: PromptParts = { idea: '', garment: '', model: '', pose: '', background: '', lighting: '', composition: '', colour: '', negative: '' };
/** Garment fidelity always leads the prompt. */
export function buildPrompt(p: PromptParts): string {
  const lines = [
    `Reproduce the uploaded garment exactly${p.garment.trim() ? ` (${p.garment.trim()})` : ''}: keep its category, silhouette, colour, neckline, sleeves, seams, stitching, proportions, fabric texture, print, embroidery, buttons, zippers and logos. Do not redesign or recolour it${p.colour.trim() ? ` except: ${p.colour.trim()}` : ''}.`,
    p.idea.trim(),
    p.model.trim() && `Model: ${p.model.trim()}.`,
    p.pose.trim() && `Pose and expression: ${p.pose.trim()}.`,
    p.background.trim() && `Setting: ${p.background.trim()}.`,
    p.lighting.trim() && `Lighting and camera: ${p.lighting.trim()}.`,
    p.composition.trim() && `Composition: ${p.composition.trim()}${/full.?body/i.test(p.composition) ? ', show the entire model from head to feet' : ''}.`,
  ].filter(Boolean);
  const neg = p.negative.trim() ? `\nAvoid: ${p.negative.trim()}.` : '';
  return lines.join('\n') + neg;
}
/** Demo enhancement is a local template, not AI. */
export function demoEnhance(p: PromptParts): PromptParts {
  return { ...p, lighting: p.lighting || 'soft directional studio light, 85mm lens', composition: p.composition || 'full body, centred', negative: p.negative || 'distorted hands, altered garment details, extra limbs' };
}
