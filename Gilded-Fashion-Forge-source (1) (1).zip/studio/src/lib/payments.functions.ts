import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { isTestSecretKey, PAYSTACK_API, proPlanForCheckout, toKobo } from './paystack';
import { verifyAndSettle } from './payments.server';

/** Whether Paystack TEST checkout is configured. Never reveals the key. */
export const getCheckoutStatus = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async () => {
  return { testCheckoutReady: isTestSecretKey(process.env['PAYSTACK_SECRET_KEY']) };
});

export const startProCheckout = createServerFn({ method: 'POST' })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ planId: z.string().max(40), origin: z.string().url().max(200) }).parse(d))
  .handler(async ({ data, context }) => {
    const secret = process.env['PAYSTACK_SECRET_KEY'];
    if (!isTestSecretKey(secret)) return { error: 'not_configured' as const };
    const plan = proPlanForCheckout(data.planId);
    if (!plan) return { error: 'unknown_plan' as const };
    const email = (context.claims as { email?: string }).email;
    if (!email) return { error: 'no_email' as const };
    // The database trigger enforces the listed price and assigns the reference.
    const { data: intent, error } = await context.supabase.from('payment_intents')
      .insert({ user_id: context.userId, plan_id: plan.id, amount_ngn: plan.priceNgn, status: 'pending' })
      .select('reference').single();
    if (error || !intent?.reference) return { error: 'intent_failed' as const };
    const res = await fetch(`${PAYSTACK_API}/transaction/initialize`, {
      method: 'POST', headers: { Authorization: `Bearer ${secret}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, amount: toKobo(plan.priceNgn), currency: 'NGN', reference: intent.reference, callback_url: `${new URL(data.origin).origin}/pricing`, metadata: { plan_id: plan.id } }),
    });
    const body = await res.json().catch(() => null) as { status?: boolean; data?: { authorization_url?: string } } | null;
    if (!res.ok || !body?.status || !body.data?.authorization_url) return { error: 'provider_failed' as const };
    return { authorizationUrl: body.data.authorization_url, reference: intent.reference };
  });

/** Called after Paystack redirects back; the redirect itself grants nothing. */
export const confirmProPayment = createServerFn({ method: 'POST' })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ reference: z.string().min(6).max(80) }).parse(d))
  .handler(async ({ data, context }) => {
    const secret = process.env['PAYSTACK_SECRET_KEY'];
    if (!isTestSecretKey(secret)) return { outcome: 'not_configured' as const };
    const { data: own } = await context.supabase.from('payment_intents').select('id').eq('reference', data.reference).eq('user_id', context.userId).maybeSingle();
    if (!own) return { outcome: 'unknown_reference' as const };
    return { outcome: await verifyAndSettle(data.reference, secret) };
  });
