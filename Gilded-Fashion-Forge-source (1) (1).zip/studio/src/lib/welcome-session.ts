export const welcomeSessionKey = 'obitrend-hotel-entry-v2';
export function shouldShowWelcome(seen: string | null, reducedMotion: boolean): boolean {
  // Reduced motion uses the same optional campaign, without animation or auto-dismissal.
  void reducedMotion;
  return seen === null;
}