// Language registry + translation lookup. English (src/lib/locales/en.ts) is the source of
// every key; other languages live in src/lib/locales/<code>.json and are checked for
// completeness by src/test/i18n.test.ts. Missing keys fall back to English at runtime,
// but the test fails so untranslated text is never shipped as "translated".
import { en, type Key } from './locales/en';
import ig from './locales/ig.json';
import zh from './locales/zh.json';
import ha from './locales/ha.json';
import yo from './locales/yo.json';
import fr from './locales/fr.json';
import es from './locales/es.json';
import pt from './locales/pt.json';
import ar from './locales/ar.json';
import hi from './locales/hi.json';
import ja from './locales/ja.json';
import ko from './locales/ko.json';

export type { Key };
/** review: 'source' = original English; 'partial-human' = earlier hand-written strings kept, rest machine-drafted;
 *  'machine' = machine-drafted, needs native-speaker verification. */
export const languages = [
  { code: 'en', label: 'English', english: 'English', flag: '🇬🇧', locale: 'en-GB', dir: 'ltr', review: 'source' },
  { code: 'ig', label: 'Asụsụ Igbo', english: 'Igbo', flag: '🇳🇬', locale: 'ig-NG', dir: 'ltr', review: 'partial-human' },
  { code: 'ha', label: 'Harshen Hausa', english: 'Hausa', flag: '🇳🇬', locale: 'ha-NG', dir: 'ltr', review: 'machine' },
  { code: 'yo', label: 'Èdè Yorùbá', english: 'Yoruba', flag: '🇳🇬', locale: 'yo-NG', dir: 'ltr', review: 'machine' },
  { code: 'fr', label: 'Français', english: 'French', flag: '🇫🇷', locale: 'fr-FR', dir: 'ltr', review: 'machine' },
  { code: 'es', label: 'Español', english: 'Spanish', flag: '🇪🇸', locale: 'es-ES', dir: 'ltr', review: 'machine' },
  { code: 'pt', label: 'Português', english: 'Portuguese', flag: '🇧🇷', locale: 'pt-BR', dir: 'ltr', review: 'machine' },
  { code: 'ar', label: 'العربية', english: 'Arabic', flag: '🇸🇦', locale: 'ar', dir: 'rtl', review: 'machine' },
  { code: 'hi', label: 'हिन्दी', english: 'Hindi', flag: '🇮🇳', locale: 'hi-IN', dir: 'ltr', review: 'machine' },
  { code: 'zh', label: '简体中文', english: 'Simplified Chinese', flag: '🇨🇳', locale: 'zh-CN', dir: 'ltr', review: 'partial-human' },
  { code: 'ja', label: '日本語', english: 'Japanese', flag: '🇯🇵', locale: 'ja-JP', dir: 'ltr', review: 'machine' },
  { code: 'ko', label: '한국어', english: 'Korean', flag: '🇰🇷', locale: 'ko-KR', dir: 'ltr', review: 'machine' },
] as const;
export type Lang = (typeof languages)[number]['code'];
export const langCodes = languages.map(l => l.code) as Lang[];
export const isLang = (v: unknown): v is Lang => typeof v === 'string' && (langCodes as string[]).includes(v);
export const langInfo = (l: Lang) => languages.find(x => x.code === l) ?? languages[0];

export const dictionaries: Record<Lang, Partial<Record<string, string>>> = { en, ig, zh, ha, yo, fr, es, pt, ar, hi, ja, ko };

export type Vars = Record<string, string | number>;
export function translate(lang: Lang, key: Key, vars?: Vars): string {
  const s = dictionaries[lang]?.[key] || en[key] || key;
  return vars ? s.replace(/\{(\w+)\}/g, (m, k: string) => (k in vars ? String(vars[k]) : m)) : s;
}

/** Best supported match for the browser's preferred languages, or null. */
export function matchBrowserLang(prefs: readonly string[]): Lang | null {
  for (const p of prefs) { const base = p.toLowerCase().split('-')[0]; if (isLang(base)) return base; }
  return null;
}
