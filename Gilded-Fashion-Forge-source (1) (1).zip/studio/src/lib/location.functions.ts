import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';

export type MyLocation = { consentGivenAt: string | null; revokedAt: string | null; latitude: number | null; longitude: number | null; accuracyM: number | null; capturedAt: string | null } | null;

const sel = 'consent_given_at, revoked_at, latitude, longitude, accuracy_m, captured_at';
type Row = { consent_given_at: string | null; revoked_at: string | null; latitude: number | null; longitude: number | null; accuracy_m: number | null; captured_at: string | null };
const map = (r: Row | null): MyLocation => r ? { consentGivenAt: r.consent_given_at, revokedAt: r.revoked_at, latitude: r.latitude === null ? null : Number(r.latitude), longitude: r.longitude === null ? null : Number(r.longitude), accuracyM: r.accuracy_m, capturedAt: r.captured_at } : null;

export const getMyLocation = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { data, error } = await context.supabase.from('location_shares').select(sel).eq('user_id', context.userId).maybeSingle();
  if (error) throw new Error('Could not load location settings');
  return map(data as Row | null);
});

/** Records consent (and optionally a fresh browser reading). Rounding to ~1 km happens in the database. */
export const saveMyLocation = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ latitude: z.number().min(-90).max(90), longitude: z.number().min(-180).max(180), accuracyM: z.number().min(0).max(1_000_000).nullable() }).parse(d))
  .handler(async ({ data, context }) => {
    const now = new Date().toISOString();
    const { data: row, error } = await context.supabase.from('location_shares').upsert({ user_id: context.userId, consent_given_at: now, revoked_at: null, latitude: data.latitude, longitude: data.longitude, accuracy_m: data.accuracyM === null ? null : Math.round(data.accuracyM) }).select(sel).single();
    if (error) throw new Error('Could not save location');
    return map(row as Row);
  });

export const revokeMyLocation = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { error } = await context.supabase.from('location_shares').update({ revoked_at: new Date().toISOString() }).eq('user_id', context.userId);
  if (error) throw new Error('Could not revoke sharing');
  return true;
});

export const deleteMyLocation = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { error } = await context.supabase.from('location_shares').delete().eq('user_id', context.userId);
  if (error) throw new Error('Could not delete location');
  return true;
});

/** Admin-only list. The role is verified server-side; RLS additionally limits rows to active consent. */
export const adminListLocations = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { data: isAdmin, error } = await context.supabase.rpc('has_role', { _user_id: context.userId, _role: 'admin' });
  if (error || !isAdmin) return { authorized: false as const, rows: [] };
  const { data, error: e2 } = await context.supabase.from('location_shares').select(`user_id, ${sel}`).neq('user_id', context.userId).not('latitude', 'is', null).order('captured_at', { ascending: false }).limit(500);
  if (e2) throw new Error('Could not load locations');
  return { authorized: true as const, rows: (data ?? []).map(r => ({ userId: r.user_id, ...map(r as Row)! })) };
});
