import heroAsset from '@/assets/editorial/hero-denim-collage.jpg.asset.json';
const hero = heroAsset.url;
import entry from '@/assets/editorial/entry-gown.webp';
import entrySuit from '@/assets/editorial/entry-suit.webp';
import entryCasual from '@/assets/editorial/entry-casual.webp';
import entryRedCollage from '@/assets/editorial/entry-red-collage.jpg.asset.json';
import camera from '@/assets/editorial/editorial-studio.webp';
import video from '@/assets/editorial/social-content.webp';
import tailoring from '@/assets/editorial/fashion-image.webp';
import fitting from '@/assets/editorial/virtual-try-on.webp';
import colours from '@/assets/editorial/colour-variations.webp';
import campaign from '@/assets/editorial/fashion-campaigns.webp';

/** Illustrative photographs only, never evidence of garment fidelity or inference. */
export const workflowVisuals = { hero, entry, camera, video };
export const demoSamples = [
  { image: tailoring, title: 'Garment → styled model', category: 'Illustrative tailoring' },
  { image: fitting, title: 'Trench coat → model', category: 'Illustrative fitting' },
  { image: colours, title: 'One silhouette, three colours', category: 'Illustrative colourways' },
  { image: campaign, title: 'Coordinated campaign', category: 'Illustrative campaign' },
] as const;

export const entryCampaigns = [
  { image: entryRedCollage.url, alt: 'Campaign collage: model in a red top and black trousers in a luxury hotel lobby, with coordinated black, white and brown outfit scenes' },
] as const;
void entrySuit; void entryCasual;
