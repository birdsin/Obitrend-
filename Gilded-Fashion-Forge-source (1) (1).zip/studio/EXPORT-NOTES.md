# Gilded Fashion Forge source export (2026-10-14)
Exact source of Lovable project c3cd8ef9. Excluded: node_modules, .git, .env, build output.
- Two images were Lovable-hosted pointers; real copies are in hosted-images/. Outside Lovable, change src/lib/workflow-visuals.ts imports to these .jpg files.
- Demo mode, demo credits/auth/jobs and Paystack test wiring belong to this studio only. Do NOT wire to OBITREND production; connect controls later through src/lib/generation-request.ts provider adapter.
- Commit into birdsin/Obitrend- under studio/ on branch staging/lovable-source-integration-2026-10-14 only. Never push to main.
